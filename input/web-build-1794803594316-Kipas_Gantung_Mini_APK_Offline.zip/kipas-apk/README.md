# Kipas Gantung Mini: panduan build APK

Isi folder:
- `www/index.html` : aplikasi (sudah memakai pengenal suara bawaan Android)
- `capacitor.config.json`, `package.json` : konfigurasi proyek

## Syarat
- Node.js 18 atau lebih baru
- Android Studio (sudah termasuk JDK dan Android SDK)

## Langkah (di terminal, di dalam folder ini)
1. `npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor-community/speech-recognition`
2. `npx cap add android`
3. `npx cap sync android`
4. Buka file `android/app/src/main/AndroidManifest.xml`. Pastikan ada baris:
   `<uses-permission android:name="android.permission.RECORD_AUDIO" />`
   (biasanya sudah ditambahkan otomatis oleh plugin; jika belum, tambahkan di atas tag `<application>`).
   Jika muncul peringatan soal `<queries>`, tambahkan di dalam `<manifest>`:
   `<queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>`
5. `npx cap open android` lalu tunggu Gradle selesai.
6. Di Android Studio: menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. APK ada di `android/app/build/outputs/apk/debug/app-debug.apk`. Kirim ke HP dan pasang (izinkan "instal dari sumber tidak dikenal").

Untuk APK rilis bertanda tangan: **Build > Generate Signed Bundle / APK**.

## Catatan
- Saat pertama kali menekan tombol Baca Bismillah, Android akan meminta izin mikrofon. Pilih Izinkan.
- Tanpa paket suara offline, pengenalan suara Android memerlukan internet. Kalau pengenal suara tidak tersedia, tombol bantuan orang tua tetap tampil.
- Versi ini sudah offline penuh untuk tampilan: font Inter (teks) dan Poppins (judul) tertanam di dalam aplikasi, tidak ada yang diunduh dari internet.
- Huruf Arab memakai font Arab bawaan Android (Noto Naskh Arabic), tersedia di hampir semua HP Android.
- Pengenal suara offline: unduh paket bahasa Indonesia (dan Arab) di pengaturan layanan suara Google HP, lalu uji dengan mode pesawat.
- Suara contoh memakai suara sintetis bawaan HP. Untuk rekaman suara anak sungguhan, kirim berkas audionya agar dipasang.
- Pembuat APK online (tipe "website ke APK") tidak disarankan: WebView mereka umumnya tidak mendukung pengenal suara.
