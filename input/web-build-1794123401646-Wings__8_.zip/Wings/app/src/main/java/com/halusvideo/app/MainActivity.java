package com.halusvideo.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceContour;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private OutputStream out;
    private String outPath;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT < 29) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 7);
        }
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        web.setOnLongClickListener(new android.view.View.OnLongClickListener() { public boolean onLongClick(android.view.View v) { return true; } });
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                if (p.isCaptureEnabled()) {
                    try {
                        startActivityForResult(new Intent(MediaStore.ACTION_VIDEO_CAPTURE), 2);
                    } catch (Exception e) {
                        chooser = null;
                        return false;
                    }
                    return true;
                }
                try {
                    startActivityForResult(p.createIntent(), 1);
                } catch (Exception e) {
                    chooser = null;
                    return false;
                }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 2 && chooser != null) {
            Uri u = (res == RESULT_OK && data != null) ? data.getData() : null;
            chooser.onReceiveValue(u != null ? new Uri[]{u} : null);
            chooser = null;
        }
        if (req == 1 && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        }
    }

    private class Bridge {
        private FaceDetector det;
        private volatile boolean busy = false;

        private FaceDetector detector() {
            if (det == null) {
                FaceDetectorOptions o = new FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                    .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
                    .setMinFaceSize(0.1f)
                    .build();
                det = FaceDetection.getClient(o);
            }
            return det;
        }

        private void push(final String json) {
            runOnUiThread(new Runnable() {
                public void run() {
                    web.evaluateJavascript("window.onFace&&window.onFace(" + json + ")", null);
                }
            });
        }

        private JSONArray pts(Face f, int... types) throws Exception {
            JSONArray a = new JSONArray();
            for (int t : types) {
                FaceContour c = f.getContour(t);
                if (c == null) continue;
                for (PointF p : c.getPoints()) a.put(new JSONArray().put((double) p.x).put((double) p.y));
            }
            return a;
        }

        private void addHole(JSONArray hs, JSONArray a) {
            if (a.length() > 2) hs.put(a);
        }

        private Face largest(List<Face> faces) {
            Face best = faces.get(0);
            for (Face f : faces) {
                if (f.getBoundingBox().width() > best.getBoundingBox().width()) best = f;
            }
            return best;
        }

        @JavascriptInterface
        public void detect(String b64) {
            if (busy) return;
            busy = true;
            try {
                byte[] by = Base64.decode(b64, Base64.DEFAULT);
                final Bitmap bm = BitmapFactory.decodeByteArray(by, 0, by.length);
                if (bm == null) {
                    busy = false;
                    return;
                }
                detector().process(InputImage.fromBitmap(bm, 0))
                    .addOnSuccessListener(faces -> {
                        try {
                            JSONObject o = new JSONObject();
                            o.put("w", bm.getWidth());
                            o.put("h", bm.getHeight());
                            if (faces.isEmpty()) {
                                o.put("n", 0);
                            } else {
                                Face f = largest(faces);
                                o.put("n", 1);
                                o.put("face", pts(f, FaceContour.FACE));
                                JSONArray hs = new JSONArray();
                                addHole(hs, pts(f, FaceContour.LEFT_EYE));
                                addHole(hs, pts(f, FaceContour.RIGHT_EYE));
                                addHole(hs, pts(f, FaceContour.LEFT_EYEBROW_TOP, FaceContour.LEFT_EYEBROW_BOTTOM));
                                addHole(hs, pts(f, FaceContour.RIGHT_EYEBROW_TOP, FaceContour.RIGHT_EYEBROW_BOTTOM));
                                addHole(hs, pts(f, FaceContour.UPPER_LIP_TOP, FaceContour.UPPER_LIP_BOTTOM,
                                    FaceContour.LOWER_LIP_TOP, FaceContour.LOWER_LIP_BOTTOM));
                                o.put("holes", hs);
                            }
                            push(o.toString());
                        } catch (Exception e) {
                            push("{\"n\":-1}");
                        }
                        busy = false;
                    })
                    .addOnFailureListener(e -> {
                        busy = false;
                        push("{\"n\":-1}");
                    });
            } catch (Throwable th) {
                busy = false;
                push("{\"n\":-1}");
            }
        }

        @JavascriptInterface
        public void begin(String name, String mime) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime.split(";")[0]);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Wings");
                    Uri u = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
                    out = getContentResolver().openOutputStream(u);
                    outPath = null;
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Wings");
                    dir.mkdirs();
                    File f = new File(dir, name);
                    out = new FileOutputStream(f);
                    outPath = f.getAbsolutePath();
                }
            } catch (Exception e) {
                out = null;
            }
        }

        @JavascriptInterface
        public void chunk(String b64) {
            try {
                if (out != null) out.write(Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception e) { }
        }

        @JavascriptInterface
        public void end() {
            try {
                if (out != null) out.close();
            } catch (Exception e) { }
            final boolean ok = out != null;
            out = null;
            if (outPath != null) {
                MediaScannerConnection.scanFile(MainActivity.this, new String[]{outPath}, null, null);
            }
            runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(MainActivity.this,
                        ok ? "Video tersimpan di Movies/Wings" : "Gagal menyimpan video",
                        Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
