package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor
import com.example.pemutarmusik.audio.Presets
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(s / 60, s % 60)
}

@Composable
private fun rememberMeter(read: () -> Float): Float {
    var db by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            db = read()
            delay(100)
        }
    }
    return db
}

/** Lampu kecil berlabel: LED menyala/mati + teks. */
@Composable
private fun Lamp(label: String, color: Color, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Led(color, on, diameter = 7.dp)
        Text(
            label,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            color = if (on) WA_INK else WA_LAMP_OFF,
        )
    }
}

/** Tombol ikon bulat kecil + LED di sampingnya (menyala = aktif). */
@Composable
private fun LedToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    ledColor: Color,
    on: Boolean,
    onClick: () -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        WaIconButton(icon, description, onClick, buttonSize = 30.dp, iconSize = 16.dp)
        Led(ledColor, on, diameter = 8.dp)
    }
}

// ================================================================== JENDELA UTAMA

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainWindow(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val s by AudioEngine.settings.collectAsState()
    val guardDb = rememberMeter { AudioEngine.processor.guardReductionDb }
    val limDb = rememberMeter { AudioEngine.processor.limiterReductionDb }
    val pal = Skin.p

    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
    val shown = drag ?: fraction

    // Jendela tetap (tanpa minimize), mengisi 1/3 tinggi kolom kiri.
    WaWindow("MP3", modifier = modifier, fill = true) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // KIRI: layar LCD (waktu + spectrum), lampu status, bar seek
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(
                    Modifier.fillMaxWidth().weight(1f).bevel(false, WA_LCD).padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        formatTime((shown * ui.durationMs).toLong().takeIf { drag != null } ?: ui.positionMs),
                        color = WA_GREEN,
                        fontSize = 22.sp,
                        fontFamily = MONO,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterVertically),
                    )
                    SpectrumView(ui.isPlaying, Modifier.weight(1f).fillMaxHeight())
                }
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Lamp("GRD", pal.c1, guardDb > 0.5f)
                    Lamp("NSE", pal.c2, s.noiseFilter)
                    Lamp("EQ", pal.c3, s.enabled)
                    Lamp("LIM", pal.c4, limDb > 0.5f)
                }
                WaSlider(
                    value = shown,
                    onValueChange = { drag = it },
                    range = 0f..1f,
                    onDone = {
                        drag?.let { vm.seekTo((it * ui.durationMs).toLong()) }
                        drag = null
                    },
                    modifier = Modifier.fillMaxWidth().height(14.dp),
                )
            }

            // KANAN: judul berjalan, 5 tombol transport (di tengah), volume + acak + ulang
            Column(Modifier.weight(1.2f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                Box(
                    Modifier.fillMaxWidth().height(20.dp).bevel(false, WA_LCD).padding(horizontal = 4.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    val label = if (ui.title != null) "${ui.artist} - ${ui.title}  ***  " else "MP3  ***  "
                    Text(
                        label,
                        color = WA_GREEN,
                        fontSize = 11.sp,
                        fontFamily = MONO,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE),
                    )
                }

                // sebelumnya, jeda, PUTAR (tengah, lebih besar), henti, berikutnya.
                // Kelima tombol menyala biru tua OCEAN saat ditekan; tombol sesuai status tetap menyala.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
                ) {
                    WaIconButton(Icons.Filled.SkipPrevious, "Sebelumnya", vm::previous, buttonSize = 32.dp, iconSize = 18.dp, accent = pal.c3)
                    WaIconButton(Icons.Filled.Pause, "Jeda", vm::pause, buttonSize = 32.dp, iconSize = 18.dp, accent = pal.c3, active = ui.isPaused)
                    WaIconButton(Icons.Filled.PlayArrow, "Putar", vm::play, buttonSize = 40.dp, iconSize = 24.dp, accent = pal.c3, active = ui.isPlaying)
                    WaIconButton(Icons.Filled.Stop, "Henti", vm::stop, buttonSize = 32.dp, iconSize = 18.dp, accent = pal.c3, active = ui.isStopped)
                    WaIconButton(Icons.Filled.SkipNext, "Berikutnya", vm::next, buttonSize = 32.dp, iconSize = 18.dp, accent = pal.c3)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("VOL", color = WA_TEXT, fontSize = 9.sp, fontFamily = MONO, modifier = Modifier.padding(end = 4.dp))
                    WaSlider(
                        value = ui.volume,
                        onValueChange = vm::setVolume,
                        range = 0f..1f,
                        modifier = Modifier.weight(1f).height(14.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    // Acak (shuffle): LED menyala = aktif
                    LedToggle(Icons.Filled.Shuffle, "Acak", pal.c2, ui.shuffle, vm::toggleShuffle)
                    Spacer(Modifier.width(2.dp))
                    // Ulang: mati -> semua (LED cyan) -> 1 lagu (LED kuning)
                    LedToggle(
                        icon = if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        description = when (ui.repeatMode) {
                            Player.REPEAT_MODE_ONE -> "Ulang 1 lagu"
                            Player.REPEAT_MODE_ALL -> "Ulang semua"
                            else -> "Ulang mati"
                        },
                        ledColor = if (ui.repeatMode == Player.REPEAT_MODE_ONE) pal.c4 else pal.c1,
                        on = ui.repeatMode != Player.REPEAT_MODE_OFF,
                        onClick = vm::toggleRepeat,
                    )
                }
            }
        }
    }
}

// ================================================================== EQUALIZER 10 BAND + PREAMP

private val FREQ_LABELS = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

private fun fmtDb(v: Float): String = when {
    v == 0f -> "0"
    v % 1f == 0f -> "%+d".format(v.toInt())
    else -> "%+.1f".format(v)
}

@Composable
private fun EqColumn(
    label: String,
    value: Float,
    enabled: Boolean,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(fmtDb(value), color = if (enabled) WA_INK else WA_LAMP_OFF, fontSize = 8.sp, fontFamily = MONO, maxLines = 1)
        WaSlider(
            value = value,
            onValueChange = onChange,
            range = -EqAudioProcessor.MAX_GAIN_DB..EqAudioProcessor.MAX_GAIN_DB,
            vertical = true,
            centered = true,
            enabled = enabled,
            modifier = Modifier.width(24.dp).weight(1f),
        )
        Text(label, color = WA_TEXT, fontSize = 8.sp, fontFamily = MONO, maxLines = 1)
    }
}

@Composable
fun EqWindow(modifier: Modifier = Modifier) {
    val s by AudioEngine.settings.collectAsState()
    WaWindow("EQUALIZER 10 BAND", modifier = modifier, fill = true) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // kiri: ON + preset (2 kolom)
            Column(Modifier.width(124.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                val presets = Presets.all.toList()
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    WaButton("ON", { AudioEngine.update { it.copy(enabled = !it.enabled) } }, Modifier.weight(1f), active = s.enabled)
                    Led(Skin.p.c3, s.enabled)
                    presets.getOrNull(0)?.let { (name, g) ->
                        WaButton(name, { AudioEngine.update { it.copy(gains = g) } }, Modifier.weight(1.1f), active = s.gains == g)
                    }
                }
                presets.drop(1).chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        pair.forEach { (name, g) ->
                            WaButton(name, { AudioEngine.update { it.copy(gains = g) } }, Modifier.weight(1f), active = s.gains == g)
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            // kanan: 11 slider (PRE + 10 band) mengisi sisa lebar dan tinggi
            Row(Modifier.weight(1f).fillMaxHeight().bevel(false, Color(0xFFC2C9D9)).padding(vertical = 2.dp)) {
                Column(
                    Modifier.width(24.dp).fillMaxHeight().padding(top = 11.dp, bottom = 11.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.End,
                ) {
                    Text("+12", color = WA_TEXT, fontSize = 7.sp, fontFamily = MONO)
                    Text("0", color = WA_TEXT, fontSize = 7.sp, fontFamily = MONO)
                    Text("-12", color = WA_TEXT, fontSize = 7.sp, fontFamily = MONO)
                }
                EqColumn(
                    "PRE", s.preampDb, true,
                    { v -> AudioEngine.update { it.copy(preampDb = (v * 2f).roundToInt() / 2f) } },
                    Modifier.weight(1f),
                )
                Spacer(Modifier.width(4.dp))
                for (i in 0 until EqAudioProcessor.BAND_COUNT) {
                    EqColumn(
                        FREQ_LABELS[i], s.gains[i], s.enabled,
                        { v ->
                            AudioEngine.update { st ->
                                st.copy(gains = st.gains.toMutableList().also { it[i] = (v * 2f).roundToInt() / 2f })
                            }
                        },
                        Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

// ================================================================== DSP / AMP

@Composable
private fun DspRow(label: String, valueText: String, content: @Composable (Modifier) -> Unit) {
    Row(Modifier.fillMaxWidth().height(22.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = WA_TEXT, fontSize = 8.sp, fontFamily = MONO, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.width(68.dp))
        content(Modifier.weight(1f).height(16.dp))
        Text(valueText, color = WA_LAMP_ON, fontSize = 8.sp, fontFamily = MONO, textAlign = TextAlign.End, maxLines = 1, modifier = Modifier.width(48.dp))
    }
}

@Composable
fun DspWindow(modifier: Modifier = Modifier) {
    val s by AudioEngine.settings.collectAsState()
    val guardDb = rememberMeter { AudioEngine.processor.guardReductionDb }
    val limDb = rememberMeter { AudioEngine.processor.limiterReductionDb }
    val trimDb = rememberMeter { AudioEngine.processor.headroomTrimDb }

    WaWindow("DSP / POWER AMP", modifier = modifier, fill = true) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // kiri: noise filter + pengaturan yang bisa diatur
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                Row(Modifier.fillMaxWidth().height(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    WaButton("NOISE FILTER", { AudioEngine.update { it.copy(noiseFilter = !it.noiseFilter) } }, active = s.noiseFilter)
                    Spacer(Modifier.width(4.dp))
                    Led(Skin.p.c2, s.noiseFilter)
                }
                DspRow("BASS BOOST", "${(s.bassBoost * 100).roundToInt()}%") { m ->
                    WaSlider(s.bassBoost, { v -> AudioEngine.update { it.copy(bassBoost = v) } }, 0f..1f, m)
                }
                DspRow("STEREO WIDTH", "${(s.width * 100).roundToInt()}%") { m ->
                    WaSlider(s.width, { v -> AudioEngine.update { it.copy(width = if (kotlin.math.abs(v - 1f) < 0.05f) 1f else v) } }, 0f..2f, m, centered = true)
                }
                DspRow("POWER AMP", "+%.1fdB".format(s.ampDb)) { m ->
                    WaSlider(s.ampDb, { v -> AudioEngine.update { it.copy(ampDb = (v * 2f).roundToInt() / 2f) } }, 0f..12f, m)
                }
            }
            // kanan: meter otomatis (hanya tampilan)
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                DspRow("BASS GUARD", if (guardDb > 0.5f) "-%.1fdB".format(guardDb) else "AUTO") { m ->
                    MeterBar(guardDb / 12f, m)
                }
                DspRow("LIMITER", if (limDb > 0.5f) "-%.1fdB".format(limDb) else "OK") { m ->
                    MeterBar(limDb / 12f, m)
                }
                DspRow("HEADROOM", if (trimDb > 0.2f) "-%.1fdB".format(trimDb) else "AUTO") { m ->
                    MeterBar(trimDb / 12f, m)
                }
            }
        }
    }
}

@Composable
private fun MeterBar(frac: Float, modifier: Modifier) {
    val low = Skin.p.specLow
    Canvas(modifier.bevel(false, WA_LCD)) {
        val f = frac.coerceIn(0f, 1f)
        val segs = 24
        val w = size.width / segs
        val lit = (f * segs).toInt()
        for (i in 0 until segs) {
            val c = if (i < segs * 0.5f) low else if (i < segs * 0.8f) Color(0xFFF0B800) else Color(0xFFE82010)
            drawRect(if (i < lit) c else Color(0xFF123066), Offset(i * w + 1f, 3f), Size(w - 2f, size.height - 6f))
        }
    }
}
