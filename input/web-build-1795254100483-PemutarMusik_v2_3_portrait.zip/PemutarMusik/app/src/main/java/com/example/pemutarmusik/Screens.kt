package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(s / 60, s % 60)
}

@Composable
private fun rememberMeter(read: () -> Float): Float {
    var db by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            db = read()
            delay(100)
        }
    }
    return db
}

/** Lampu kecil berlabel: LED menyala/mati + teks. */
@Composable
fun Lamp(label: String, color: Color, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Led(color, on, diameter = 7.dp)
        Text(
            label,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            color = if (on) WA_INK else WA_LAMP_OFF,
        )
    }
}

/** Tombol ikon bulat kecil + LED di sampingnya (menyala = aktif). */
@Composable
private fun LedToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    ledColor: Color,
    on: Boolean,
    onClick: () -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        WaIconButton(icon, description, onClick, buttonSize = 26.dp, iconSize = 14.dp)
        Led(ledColor, on, diameter = 7.dp)
    }
}

// ================================================================== PLAYER MP3: DEK KASET

/** Nomor versi aplikasi, mis. "v.2.3". Diambil dari versionName di app/build.gradle.kts, jadi cukup ubah di satu tempat. */
@Composable
private fun appVersionLabel(context: android.content.Context): String = remember {
    try {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        "v.${info.versionName}"
    } catch (e: Exception) {
        ""
    }
}

/**
 * Kaset digambar dengan Canvas di dalam ruang kaset hitam. Dua roda gigi (hub) berputar selama [playing];
 * tumpukan pita di kiri menipis dan di kanan menebal mengikuti [progress] (0..1). [title] tertulis di label kaset.
 */
@Composable
private fun CassetteView(playing: Boolean, progress: Float, title: String, modifier: Modifier = Modifier) {
    var angle by remember { mutableFloatStateOf(0f) }
    // Sudut hanya bertambah saat playing = true; saat jeda/henti roda berhenti di posisi terakhirnya.
    LaunchedEffect(playing) {
        if (playing) {
            var last = 0L
            while (true) {
                val now = androidx.compose.runtime.withFrameNanos { it }
                if (last != 0L) angle = (angle + (now - last) / 1_000_000_000f * 240f) % 360f
                last = now
            }
        }
    }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
            textAlign = android.graphics.Paint.Align.LEFT
        }
    }

    Canvas(modifier) {
        val dp1 = 1.dp.toPx()
        val cw0 = size.width
        val ch0 = size.height

        // ---- ruang kaset (hitam, kaca berkilau)
        val bayR = CornerRadius(3.dp.toPx())
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFF040505), Color(0xFF17191C), Color(0xFF090A0B))),
            cornerRadius = bayR,
        )

        // ---- ukuran kaset: rasio 1,6 : 1, di tengah ruang
        val pad = 6.dp.toPx()
        val cw = minOf(cw0 - 2 * pad, (ch0 - 2 * pad) * 1.6f).coerceAtLeast(40f)
        val ch = cw / 1.6f
        val bx = (cw0 - cw) / 2f
        val by = (ch0 - ch) / 2f
        val bodyR = CornerRadius(ch * 0.06f)

        // bayangan + badan kaset
        drawRoundRect(Color(0x77000000), Offset(bx + dp1, by + 2 * dp1), Size(cw, ch), bodyR)
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFF5A5D63), Color(0xFF34363A), Color(0xFF212225)), by, by + ch),
            Offset(bx, by), Size(cw, ch), bodyR,
        )
        drawRoundRect(Color(0x55FFFFFF), Offset(bx, by), Size(cw, ch), bodyR, style = Stroke(dp1))

        // ---- label krem dengan pita merah di atas
        val lx = bx + cw * 0.07f
        val ly = by + ch * 0.08f
        val lw = cw * 0.86f
        val lh = ch * 0.56f
        val labelR = CornerRadius(ch * 0.03f)
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFFF7F1DD), Color(0xFFE2D9BE)), ly, ly + lh),
            Offset(lx, ly), Size(lw, lh), labelR,
        )
        drawRect(Color(0xFFD9471E), Offset(lx + dp1, ly + dp1), Size(lw - 2 * dp1, ch * 0.075f))

        // tulisan di label: huruf "A" di pita, judul lagu (dipotong "…" kalau kepanjangan)
        val nc = drawContext.canvas.nativeCanvas
        paint.color = android.graphics.Color.WHITE
        paint.textSize = ch * 0.062f
        nc.drawText("A", lx + lw * 0.04f, ly + ch * 0.062f, paint)
        paint.color = 0xFF2A2A2A.toInt()
        paint.textSize = ch * 0.085f
        val maxW = lw * 0.90f
        var t = title
        if (paint.measureText(t) > maxW) {
            while (t.length > 1 && paint.measureText("$t…") > maxW) t = t.dropLast(1)
            t = "$t…"
        }
        nc.drawText(t, lx + lw * 0.05f, by + ch * 0.255f, paint)
        drawLine(Color(0x66000000), Offset(lx + lw * 0.05f, by + ch * 0.285f), Offset(lx + lw * 0.95f, by + ch * 0.285f), 0.8.dp.toPx())

        // ---- jendela pita (celah gelap) dengan dua roda
        val wx = bx + cw * 0.17f
        val wy = by + ch * 0.32f
        val ww = cw * 0.66f
        val wh = ch * 0.28f
        val winR = CornerRadius(wh / 2f)
        drawRoundRect(Color(0xFF08090A), Offset(wx, wy), Size(ww, wh), winR)

        val cy = wy + wh / 2f
        val cxL = bx + cw * 0.32f
        val cxR = bx + cw * 0.68f
        val hubR = ch * 0.075f
        val minPack = ch * 0.092f
        val maxPack = wh / 2f - dp1
        val p = progress.coerceIn(0f, 1f)
        val rL = minPack + (maxPack - minPack) * (1f - p)
        val rR = minPack + (maxPack - minPack) * p

        // pita yang terbentang dari tumpukan ke kepala pita di bawah
        val tapeCol = Color(0xFF6B4A36)
        drawLine(tapeCol, Offset(cxL - rL * 0.55f, cy + rL * 0.85f), Offset(bx + cw * 0.38f, by + ch * 0.90f), 1.2.dp.toPx())
        drawLine(tapeCol, Offset(cxR + rR * 0.55f, cy + rR * 0.85f), Offset(bx + cw * 0.62f, by + ch * 0.90f), 1.2.dp.toPx())

        for ((cx, rp) in listOf(cxL to rL, cxR to rR)) {
            val c = Offset(cx, cy)
            // tumpukan pita cokelat
            drawCircle(Brush.radialGradient(listOf(Color(0xFF7A5740), Color(0xFF3B271B)), c, rp), rp, c)
            drawCircle(Color(0x55000000), rp, c, style = Stroke(dp1))
            // hub putih bergerigi yang berputar
            drawCircle(Color(0xFFEDEDED), hubR, c)
            drawCircle(Color(0xFF111214), hubR * 0.62f, c)
            for (k in 0 until 6) {
                val a = Math.toRadians((angle + k * 60f).toDouble())
                val ca = cos(a).toFloat()
                val sa = sin(a).toFloat()
                drawLine(
                    Color(0xFFEDEDED),
                    Offset(cx + hubR * 0.28f * ca, cy + hubR * 0.28f * sa),
                    Offset(cx + hubR * 0.66f * ca, cy + hubR * 0.66f * sa),
                    1.6.dp.toPx(),
                )
            }
        }
        // kaca jendela pita
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0x33FFFFFF), Color(0x00FFFFFF)), wy, wy + wh * 0.6f),
            Offset(wx, wy), Size(ww, wh * 0.6f), winR,
        )
        drawRoundRect(Color(0xFF000000), Offset(wx, wy), Size(ww, wh), winR, style = Stroke(dp1))

        // ---- bagian bawah kaset (trapesium gelap) + lubang kepala pita
        val tp = Path().apply {
            moveTo(bx + cw * 0.22f, by + ch)
            lineTo(bx + cw * 0.78f, by + ch)
            lineTo(bx + cw * 0.70f, by + ch * 0.72f)
            lineTo(bx + cw * 0.30f, by + ch * 0.72f)
            close()
        }
        drawPath(tp, Color(0xFF1A1B1E))
        drawPath(tp, Color(0x55FFFFFF), style = Stroke(0.8.dp.toPx()))
        drawCircle(Color(0xFF050506), ch * 0.035f, Offset(bx + cw * 0.35f, by + ch * 0.86f))
        drawCircle(Color(0xFF050506), ch * 0.035f, Offset(bx + cw * 0.65f, by + ch * 0.86f))
        drawRoundRect(Color(0xFF050506), Offset(bx + cw * 0.45f, by + ch * 0.80f), Size(cw * 0.10f, ch * 0.18f), CornerRadius(dp1))

        // ---- empat sekrup di sudut
        for ((sx, sy) in listOf(0.04f to 0.075f, 0.96f to 0.075f, 0.04f to 0.925f, 0.96f to 0.925f)) {
            val c = Offset(bx + cw * sx, by + ch * sy)
            drawCircle(Color(0xFF9A9CA0), ch * 0.024f, c)
            drawCircle(Color(0xFF111214), ch * 0.024f, c, style = Stroke(0.7.dp.toPx()))
        }

        // ---- pantulan kaca miring di atas ruang kaset
        val glare = Path().apply {
            moveTo(cw0 * 0.58f, 0f)
            lineTo(cw0 * 0.78f, 0f)
            lineTo(cw0 * 0.46f, ch0)
            lineTo(cw0 * 0.26f, ch0)
            close()
        }
        drawPath(glare, Color(0x0DFFFFFF))
        drawRoundRect(Color(0xFF000000), cornerRadius = bayR, style = Stroke(dp1))
        drawRoundRect(Color(0x44FFFFFF), Offset(dp1, dp1), Size(cw0 - 2 * dp1, ch0 - 2 * dp1), bayR, style = Stroke(0.7.dp.toPx()))
    }
}

/**
 * Panel player MP3 ala dek kaset Sony: layar judul berjalan, kaset berputar di tengah (counter waktu di kiri,
 * spectrum di kanan), bar seek, lalu deretan tombol piano di BAWAH kaset: REW, PLAY, PAUSE, STOP, FF.
 * Baris paling bawah: acak, ulang, dan tombol PLAYLIST untuk menampilkan / menyembunyikan daftar lagu.
 *
 * [ui] sudah disaring: kosong kalau yang aktif sedang radio. [active] = mode MP3 aktif (LED judul menyala).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Mp3DeckWindow(
    vm: PlayerViewModel,
    ui: PlayerUi,
    active: Boolean,
    listVisible: Boolean,
    onToggleList: () -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val s by AudioEngine.settings.collectAsState()
    val guardDb = rememberMeter { AudioEngine.processor.guardReductionDb }
    val limDb = rememberMeter { AudioEngine.processor.limiterReductionDb }
    val pal = Skin.p
    val titleH = rememberTitleBarHeight()

    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
    val shown = drag ?: fraction

    WaWindow(
        "CASSETTE DECK", modifier = modifier, fill = true,
        contentPadding = 4.dp,
        titleHeight = titleH,
        actions = {
            Led(pal.c3, active, diameter = 7.dp)
            SkinButton(titleH)
            WaTitleButton(false, "Kecilkan ke mini player", titleH, onMinimize)
            WaTitleButton(true, "Tutup aplikasi", titleH, onClose)
        },
    ) {
        // ---- layar judul berjalan
        Box(
            Modifier.fillMaxWidth().height(20.dp).bevel(false, WA_LCD).padding(horizontal = 4.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            val label = if (ui.title != null) "${ui.artist} - ${ui.title}  ***  " else "CASSETTE DECK  ***  "
            Text(
                label,
                color = WA_GREEN,
                fontSize = 11.sp,
                fontFamily = MONO,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE),
            )
        }
        Spacer(Modifier.height(4.dp))

        // ---- ruang kaset: counter (kiri) | kaset (tengah) | spectrum (kanan)
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Column(
                Modifier.width(74.dp).fillMaxHeight().bevel(false, WA_LCD).padding(4.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("COUNTER", color = WA_GREEN_DIM, fontSize = 7.sp, fontFamily = MONO, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(
                    formatTime(if (drag != null) (shown * ui.durationMs).toLong() else ui.positionMs),
                    color = WA_GREEN,
                    fontSize = 19.sp,
                    fontFamily = MONO,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                )
                Column(horizontalAlignment = Alignment.Start) {
                    Row {
                        Lamp("GRD", pal.c1, guardDb > 0.5f)
                        Lamp("NSE", pal.c2, s.noiseFilter)
                    }
                    Row {
                        Lamp("EQ", pal.c3, s.enabled)
                        Lamp("LIM", pal.c4, limDb > 0.5f)
                    }
                }
            }
            CassetteView(
                playing = ui.isPlaying,
                progress = shown,
                title = ui.title ?: "MUSIC",
                modifier = Modifier.weight(1f).fillMaxHeight(),
            )
            Box(Modifier.width(74.dp).fillMaxHeight().bevel(false, WA_LCD).padding(4.dp)) {
                SpectrumView(ui.isPlaying, Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(4.dp))

        // ---- bar seek
        WaSlider(
            value = shown,
            onValueChange = { drag = it },
            range = 0f..1f,
            onDone = {
                drag?.let { vm.seekTo((it * ui.durationMs).toLong()) }
                drag = null
            },
            modifier = Modifier.fillMaxWidth().height(14.dp),
        )
        Spacer(Modifier.height(4.dp))

        // ---- tombol di BAWAH kaset: REW, PLAY, PAUSE, STOP, FF
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            DeckKey(Icons.Filled.FastRewind, "REW", vm::previous, Modifier.weight(1f))
            DeckKey(Icons.Filled.PlayArrow, "PLAY", vm::play, Modifier.weight(1f), active = ui.isPlaying)
            DeckKey(Icons.Filled.Pause, "PAUSE", vm::pause, Modifier.weight(1f), active = ui.isPaused)
            DeckKey(Icons.Filled.Stop, "STOP", vm::stop, Modifier.weight(1f), active = ui.isStopped)
            DeckKey(Icons.Filled.FastForward, "FF", vm::next, Modifier.weight(1f))
        }
        Spacer(Modifier.height(4.dp))

        // ---- acak, ulang, PLAYLIST (tampil / sembunyi)
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            LedToggle(Icons.Filled.Shuffle, "Acak", pal.c2, ui.shuffle, vm::toggleShuffle)
            LedToggle(
                icon = if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                description = when (ui.repeatMode) {
                    Player.REPEAT_MODE_ONE -> "Ulang 1 lagu"
                    Player.REPEAT_MODE_ALL -> "Ulang semua"
                    else -> "Ulang mati"
                },
                ledColor = if (ui.repeatMode == Player.REPEAT_MODE_ONE) pal.c4 else pal.c1,
                on = ui.repeatMode != Player.REPEAT_MODE_OFF,
                onClick = vm::toggleRepeat,
            )
            Spacer(Modifier.weight(1f))
            Led(pal.c3, listVisible, diameter = 7.dp)
            WaButton(if (listVisible) "PLAYLIST ▲" else "PLAYLIST ▼", onToggleList, active = listVisible)
        }
    }
}

// ================================================================== RADIO (tuner FM)

/** Panel radio: layar digital, tombol prev / play / next, SCAN, SLEEP, knob TUNING. Tombol CHANNEL = tampil / sembunyi daftar channel. */
@Composable
fun RadioWindow(
    vm: PlayerViewModel,
    ui: PlayerUi,
    active: Boolean,
    listVisible: Boolean,
    onToggleList: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val titleH = rememberTitleBarHeight()
    WaWindow(
        "FM STEREO TUNER", modifier = modifier, fill = true,
        contentPadding = 3.dp,
        titleHeight = titleH,
        actions = {
            Led(Skin.p.c3, active, diameter = 7.dp)
            WaButton(if (listVisible) "CHANNEL ▲" else "CHANNEL ▼", onToggleList, active = listVisible)
            Spacer(Modifier.width(6.dp))
        },
    ) {
        RadioBody(vm, ui)
    }
}

// ================================================================== EQUALIZER 10 BAND + PREAMP

private val FREQ_LABELS = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

@Composable
private fun EqColumn(
    label: String,
    value: Float,
    enabled: Boolean,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
        WaSlider(
            value = value,
            onValueChange = onChange,
            range = -EqAudioProcessor.MAX_GAIN_DB..EqAudioProcessor.MAX_GAIN_DB,
            vertical = true,
            centered = true,
            enabled = enabled,
            thumb = 10.dp,
            modifier = Modifier.width(24.dp).weight(1f),
        )
        Text(label, color = WA_TEXT, fontSize = 8.sp, lineHeight = 9.sp, fontFamily = MONO, maxLines = 1)
    }
}

@Composable
fun EqWindow(modifier: Modifier = Modifier) {
    val s by AudioEngine.settings.collectAsState()
    WaWindow("EQUALIZER 10 BAND", modifier = modifier, fill = true, contentPadding = 3.dp, titleHeight = 20.dp) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // kiri: ON/OFF equalizer + noise filter, lalu bass boost, power amp, pre amp
            Column(Modifier.width(116.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                Row(
                    Modifier.fillMaxWidth().height(20.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    WaButton(if (s.enabled) "ON" else "OFF", { AudioEngine.update { it.copy(enabled = !it.enabled) } }, Modifier.weight(1f), active = s.enabled)
                    Led(Skin.p.c3, s.enabled)
                    WaButton("NOISE", { AudioEngine.update { it.copy(noiseFilter = !it.noiseFilter) } }, Modifier.weight(1f), active = s.noiseFilter)
                    Led(Skin.p.c2, s.noiseFilter)
                }
                ParamRow("BASS BOOST") { m ->
                    WaSlider(s.bassBoost, { v -> AudioEngine.update { it.copy(bassBoost = v) } }, 0f..1f, m)
                }
                ParamRow("POWER AMP") { m ->
                    WaSlider(s.ampDb, { v -> AudioEngine.update { it.copy(ampDb = (v * 2f).roundToInt() / 2f) } }, 0f..12f, m)
                }
                ParamRow("PRE AMP") { m ->
                    WaSlider(
                        s.preampDb,
                        { v -> AudioEngine.update { it.copy(preampDb = (v * 2f).roundToInt() / 2f) } },
                        -EqAudioProcessor.MAX_GAIN_DB..EqAudioProcessor.MAX_GAIN_DB, m, centered = true,
                    )
                }
            }
            // kanan: 10 slider band memakai seluruh sisa lebar dan tinggi
            Row(Modifier.weight(1f).fillMaxHeight().bevel(false, Skin.t.well).padding(vertical = 1.dp, horizontal = 2.dp)) {
                for (i in 0 until EqAudioProcessor.BAND_COUNT) {
                    EqColumn(
                        FREQ_LABELS[i], s.gains[i], s.enabled,
                        { v ->
                            AudioEngine.update { st ->
                                st.copy(gains = st.gains.toMutableList().also { it[i] = (v * 2f).roundToInt() / 2f })
                            }
                        },
                        Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

// ================================================================== PARAMETER (dipakai panel equalizer)

@Composable
private fun ParamRow(label: String, content: @Composable (Modifier) -> Unit) {
    Row(Modifier.fillMaxWidth().height(20.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            color = WA_TEXT,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.width(46.dp),
        )
        content(Modifier.weight(1f).height(15.dp))
    }
}

// ================================================================== AMPLIFIER: VU METER L/R + LED METER + KNOB VOLUME

private const val VU_DB_MIN = -36f
private const val VU_DB_MAX = 3f

/** Level linear (0..1) -> posisi 0..1 pada skala -36..+3 dB. */
private fun levelToFrac(lin: Float): Float {
    if (lin <= 0.00002f) return 0f
    return ((20f * log10(lin) - VU_DB_MIN) / (VU_DB_MAX - VU_DB_MIN)).coerceIn(0f, 1f)
}

/**
 * Level kiri/kanan (0..1) yang sudah dihaluskan: naik cepat, turun pelan.
 * Level dikalikan volume pemutar supaya meter ikut bergerak saat knob volume diputar.
 */
@Composable
private fun rememberStereoLevels(playing: Boolean, volume: Float): Pair<Float, Float> {
    val playingNow by rememberUpdatedState(playing)
    val volumeNow by rememberUpdatedState(volume)
    var levels by remember { mutableStateOf(0f to 0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 33_000_000L) continue
            last = now
            val (oldL, oldR) = levels
            if (!playingNow && oldL <= 0.002f && oldR <= 0.002f) {
                if (oldL != 0f || oldR != 0f) levels = 0f to 0f
                continue
            }
            val pr = AudioEngine.processor
            val targetL = if (playingNow) levelToFrac(pr.levelL * volumeNow) else 0f
            val targetR = if (playingNow) levelToFrac(pr.levelR * volumeNow) else 0f
            val newL = oldL + (targetL - oldL) * (if (targetL > oldL) 0.6f else 0.12f)
            val newR = oldR + (targetR - oldR) * (if (targetR > oldR) 0.6f else 0.12f)
            levels = newL to newR
        }
    }
    return levels
}

private fun dbToFrac(db: Float): Float = ((db - VU_DB_MIN) / (VU_DB_MAX - VU_DB_MIN)).coerceIn(0f, 1f)

/**
 * VU meter klasik: muka abu-abu polos tanpa sorot lampu, bingkai biru tua, skala 30..0..+3 (zona merah di ujung),
 * jarum hitam beralur bayangan dan kaca tipis. [label] = "L" atau "R".
 */
@Composable
private fun VuMeter(label: String, frac: Float, modifier: Modifier = Modifier) {
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
            textAlign = android.graphics.Paint.Align.CENTER
        }
    }
    val ink = Skin.t.vuInk
    val red = Color(0xFFD8321F)
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val f = frac.coerceIn(0f, 1f)

            // ---- bingkai biru tua (3D) + cekungan muka
            val outer = CornerRadius(6.dp.toPx())
            drawRoundRect(Brush.verticalGradient(Skin.t.vuBezel), cornerRadius = outer)
            drawRoundRect(Skin.t.vuBezelLine, cornerRadius = outer, style = Stroke(1.dp.toPx()))
            val bz = 3.5.dp.toPx()
            val fx = bz
            val fy = bz
            val fw = w - 2 * bz
            val fh = h - 2 * bz
            val faceR = CornerRadius(4.dp.toPx())
            val faceTL = Offset(fx, fy)
            val faceSz = Size(fw, fh)

            // ---- muka: abu-abu polos, tanpa sorot lampu
            drawRoundRect(
                Brush.verticalGradient(Skin.t.vuFace, fy, fy + fh),
                faceTL, faceSz, faceR,
            )
            // bayangan dalam di tepi atas (muka tampak masuk)
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0x88000000), Color(0x00000000)), fy, fy + 9.dp.toPx()),
                faceTL, faceSz, faceR,
            )

            // ---- geometri busur: pivot di bawah muka supaya busur lebar dan landai (klasik)
            val maxDeg = 42f
            val sinM = sin(Math.toRadians(maxDeg.toDouble())).toFloat()
            val cosM = cos(Math.toRadians(maxDeg.toDouble())).toFloat()
            val topMargin = 9.dp.toPx() + bz
            val rs = min(fw * 0.47f / sinM, (h - 19.dp.toPx() - bz) / (1f - cosM)).coerceAtLeast(20.dp.toPx())
            val pivot = Offset(w / 2f, topMargin + rs)
            fun ang(db: Float) = -maxDeg + dbToFrac(db) * maxDeg * 2f
            fun pt(deg: Float, rad: Float): Offset {
                val a = Math.toRadians(deg.toDouble())
                return Offset(pivot.x + rad * sin(a).toFloat(), pivot.y - rad * cos(a).toFloat())
            }

            clipRect(fx, fy, fx + fw, fy + fh) {
                // busur skala + zona merah (0..+3 dB)
                val arcTL = Offset(pivot.x - rs, pivot.y - rs)
                val arcSz = Size(rs * 2f, rs * 2f)
                drawArc(ink, -90f + ang(VU_DB_MIN), maxDeg * 2f, false, arcTL, arcSz, style = Stroke(2.2.dp.toPx()))
                val redStart = ang(0f)
                drawArc(red, -90f + redStart, maxDeg - redStart, false, arcTL, arcSz, style = Stroke(4.2.dp.toPx()))

                // garis skala: tiap 5 dB di bawah -10, tiap 1 dB dari -10 sampai +3
                val ticks = listOf(-35f, -30f, -25f, -20f, -15f) + (-10..3).map { it.toFloat() }
                val majors = setOf(-30f, -20f, -10f, -5f, 0f, 3f)
                for (db in ticks) {
                    val major = db in majors
                    val inRed = db >= 0f
                    drawLine(
                        if (inRed) red else ink,
                        pt(ang(db), rs * (if (major) 0.86f else 0.92f)), pt(ang(db), rs),
                        if (major) 1.6.dp.toPx() else 0.9.dp.toPx(),
                    )
                }

                // angka skala
                paint.textSize = 6.5.sp.toPx()
                for ((db, txt) in listOf(-30f to "30", -20f to "20", -10f to "10", -5f to "5", 0f to "0", 3f to "+3")) {
                    paint.color = (if (db >= 0f) red else ink).toArgb()
                    val p = pt(ang(db), rs * 0.74f)
                    drawContext.canvas.nativeCanvas.drawText(txt, p.x, p.y + 2.5.dp.toPx(), paint)
                }

                // jarum: bayangan, badan, lalu penutup poros di bawah
                val needleDeg = -maxDeg + f * maxDeg * 2f
                val tip = pt(needleDeg, rs * 0.99f)
                val base = pt(needleDeg, rs * 0.30f)
                val shadowOff = Offset(2.dp.toPx(), 1.8.dp.toPx())
                drawLine(Color(0x44000000), base + shadowOff, tip + shadowOff, 1.8.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFF070B1C), pivot, tip, 1.7.dp.toPx(), StrokeCap.Round)
                // bayangan lembut di dasar muka tempat jarum keluar
                drawRect(
                    Brush.verticalGradient(listOf(Color(0x00000000), Color(0x55000000)), fy + fh - 10.dp.toPx(), fy + fh),
                    Offset(fx, fy + fh - 10.dp.toPx()), Size(fw, 10.dp.toPx()),
                )
            }

            // ---- kaca berkilau
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0x22FFFFFF), Color(0x05FFFFFF)), fy, fy + fh * 0.5f),
                faceTL, Size(fw, fh * 0.5f), faceR,
            )
            drawRoundRect(Color(0x88000000), faceTL, faceSz, faceR, style = Stroke(1.dp.toPx()))
            drawRoundRect(Color(0x44FFFFFF), Offset(bz * 0.5f, bz * 0.5f), Size(w - bz, h - bz), CornerRadius(5.dp.toPx()), style = Stroke(0.8.dp.toPx()))
        }
        Text(
            label,
            color = ink,
            fontSize = 10.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            lineHeight = 11.sp,
            style = CenteredLine,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 7.dp, bottom = 5.dp),
        )
        Text(
            "VU",
            color = ink,
            fontSize = 9.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            lineHeight = 10.sp,
            style = CenteredLine,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 7.dp, bottom = 5.dp),
        )
    }
}

/**
 * LED meter modern berdiri (vertikal): segmen kapsul kaca berpendar, gradasi cyan -> hijau -> kuning -> merah,
 * menyala dari bawah ke atas, plus penanda puncak (peak hold).
 */
@Composable
private fun LedMeter(frac: Float, modifier: Modifier = Modifier) {
    val fracNow by rememberUpdatedState(frac)
    var peak by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 33_000_000L) continue
            last = now
            val f = fracNow
            val p = peak
            val np = if (f >= p) f else maxOf(f, p - 0.025f)
            if (np != p) peak = np
        }
    }
    val cLow = Skin.p.c1
    val cMid = Skin.p.c2
    val cAmber = Color(0xFFFFC21A)
    val cHot = Color(0xFFFF3B2A)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val dp = 1.dp.toPx()
        // rumah kaca gelap berkilau
        val hr = CornerRadius(w * 0.32f)
        drawRoundRect(Brush.horizontalGradient(Skin.t.vuLedHouse), cornerRadius = hr)
        drawRoundRect(Color(0x66FFFFFF), Offset(0.5f * dp, 0.5f * dp), Size(w - dp, h - dp), hr, style = Stroke(dp))
        drawRoundRect(Color(0xFF000000), cornerRadius = hr, style = Stroke(dp))

        val segs = 20
        val pad = 2.5.dp.toPx()
        val gap = 1.5.dp.toPx()
        val segH = ((h - 2 * pad - gap * (segs - 1)) / segs).coerceAtLeast(1f)
        val segW = (w - 2 * pad).coerceAtLeast(1f)
        val sr = CornerRadius(minOf(segW, segH) * 0.42f)
        val lit = (frac.coerceIn(0f, 1f) * segs + 0.5f).toInt()
        val pk = (peak.coerceIn(0f, 1f) * segs - 0.5f).toInt().coerceIn(0, segs - 1)

        fun segColor(i: Int): Color {
            val t = i / (segs - 1f)
            return when {
                t < 0.5f -> lerp(cLow, cMid, t / 0.5f)
                t < 0.8f -> lerp(cMid, cAmber, (t - 0.5f) / 0.3f)
                else -> lerp(cAmber, cHot, (t - 0.8f) / 0.2f)
            }
        }
        for (i in 0 until segs) {
            val y = h - pad - (i + 1) * segH - i * gap
            val col = segColor(i)
            val tl = Offset(pad, y)
            val sz = Size(segW, segH)
            if (i < lit) {
                drawRoundRect(col.copy(alpha = 0.30f), Offset(pad - dp, y - dp), Size(segW + 2 * dp, segH + 2 * dp), CornerRadius(sr.x + dp))
                drawRoundRect(
                    Brush.horizontalGradient(listOf(lerp(col, Color.White, 0.5f), col, lerp(col, Color.Black, 0.35f)), pad, pad + segW),
                    tl, sz, sr,
                )
                drawRoundRect(Color(0x55FFFFFF), Offset(pad + dp * 0.6f, y + dp * 0.6f), Size(segW * 0.38f, (segH - dp * 1.2f).coerceAtLeast(0f)), sr)
            } else {
                drawRoundRect(
                    Brush.horizontalGradient(Skin.t.vuLedSegOff, pad, pad + segW),
                    tl, sz, sr,
                )
                drawRoundRect(col.copy(alpha = 0.10f), tl, sz, sr)
                drawRoundRect(Color(0x22FFFFFF), Offset(pad + dp * 0.6f, y + dp * 0.6f), Size(segW * 0.30f, (segH - dp * 1.2f).coerceAtLeast(0f)), sr)
            }
        }
        // penanda puncak (peak hold)
        if (peak > 0.03f && pk >= lit) {
            val y = h - pad - (pk + 1) * segH - pk * gap
            drawRoundRect(Color.White.copy(alpha = 0.55f), Offset(pad - dp, y - dp), Size(segW + 2 * dp, segH + 2 * dp), CornerRadius(sr.x + dp))
            drawRoundRect(Color.White, Offset(pad, y), Size(segW, segH), sr)
        }
    }
}

@Composable
fun VuWindow(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val (levelL, levelR) = rememberStereoLevels(ui.isPlaying, ui.volume)
    val muted = ui.volume <= 0.001f

    val versionLabel = appVersionLabel(LocalContext.current)

    WaWindow(
        "AMPLIFIER VU", modifier = modifier, fill = true, contentPadding = 3.dp, titleHeight = 20.dp,
        actions = {
            Text(
                "mod by aries $versionLabel",
                color = Skin.t.accentText,
                fontSize = 9.sp,
                fontFamily = MONO,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                lineHeight = 11.sp,
                style = CenteredLine,
                maxLines = 1,
                modifier = Modifier.padding(end = 8.dp),
            )
        },
    ) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            // knob memakai tinggi panel, tapi dibatasi 30% lebar supaya dua VU meter tetap lebar di layar portrait
            val knobSize = minOf(maxHeight, maxWidth * 0.30f).coerceIn(52.dp, 150.dp)
            Row(
                Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // KIRI: VU meter L, LED meter L berdiri di sisi dalam (dekat knob)
                Row(Modifier.weight(1f).fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    VuMeter("L", levelL, Modifier.weight(1f).fillMaxHeight())
                    LedMeter(levelL, Modifier.width(20.dp).fillMaxHeight())
                }
                // TENGAH: knob volume besar (putar = volume, ketuk = bisu)
                RadioKnob(
                    frac = ui.volume,
                    label = if (muted) "BISU" else "VOLUME",
                    knobSize = knobSize,
                    onTurn = { d -> vm.setVolume(vm.ui.value.volume + d) },
                    onTap = vm::toggleMute,
                    showLabel = false,
                    tickLit = Skin.t.vuTickLit,
                    tickOff = Skin.t.vuTickOff,
                    accent = Skin.t.vuKnobAccent,
                    capVu = true,
                )
                // KANAN: LED meter R di sisi dalam, lalu VU meter R
                Row(Modifier.weight(1f).fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    LedMeter(levelR, Modifier.width(20.dp).fillMaxHeight())
                    VuMeter("R", levelR, Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
    }
}
