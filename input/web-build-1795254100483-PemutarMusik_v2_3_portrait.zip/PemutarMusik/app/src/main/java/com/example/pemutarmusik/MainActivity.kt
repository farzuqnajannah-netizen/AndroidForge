package com.example.pemutarmusik

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.view.WindowManager
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import com.example.pemutarmusik.audio.AudioEngine

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(applicationContext)
        Skin.init(applicationContext)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { PlayerApp() }
        }
        enterFullScreen()
    }

    /** Status bar (notifikasi) disembunyikan supaya layar lega; tombol navigasi tetap tampil dan tidak tertutup aplikasi. */
    private fun enterFullScreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.statusBars())
            show(WindowInsetsCompat.Type.navigationBars())
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterFullScreen()
    }

    override fun onResume() {
        super.onResume()
        // Kembali ke aplikasi = mini player melayang ditutup (seperti restore di Winamp)
        stopService(Intent(this, FloatingPlayerService::class.java))
    }
}

/** Minimize ala Winamp: app turun ke belakang, mini player melayang tampil di depan. */
private fun minimizeToFloating(context: Context) {
    if (!Settings.canDrawOverlays(context)) {
        Toast.makeText(
            context,
            "Aktifkan \"Tampil di atas aplikasi lain\" untuk MP3, lalu tekan minimize lagi.",
            Toast.LENGTH_LONG,
        ).show()
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
        )
        return
    }
    context.startService(Intent(context, FloatingPlayerService::class.java))
    (context as? Activity)?.moveTaskToBack(true)
}

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED

private fun requestedPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 33 -> arrayOf(audioPermission(), Manifest.permission.POST_NOTIFICATIONS)
    // Android 9 ke bawah: butuh izin tulis untuk menghapus file lagu
    Build.VERSION.SDK_INT <= 28 -> arrayOf(audioPermission(), Manifest.permission.WRITE_EXTERNAL_STORAGE)
    else -> arrayOf(audioPermission())
}

@Composable
fun PlayerApp(vm: PlayerViewModel = viewModel()) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission(context)
    }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(requestedPermissions())
    }
    LaunchedEffect(granted) {
        if (granted) vm.loadSongs()
    }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        vm.onDeleteResult(res.resultCode == Activity.RESULT_OK)
    }
    val onDeleteSong: (Song) -> Unit = { song ->
        when (val outcome = vm.requestDelete(song)) {
            is DeleteOutcome.NeedsUser -> deleteLauncher.launch(IntentSenderRequest.Builder(outcome.sender).build())
            DeleteOutcome.Done -> Toast.makeText(context, "Lagu dihapus", Toast.LENGTH_SHORT).show()
            DeleteOutcome.Failed -> Toast.makeText(context, "Gagal menghapus lagu", Toast.LENGTH_SHORT).show()
        }
    }

    val mode by vm.mode.collectAsState()
    val ui by vm.ui.collectAsState()

    // Playlist dan daftar channel masing-masing punya tombol sendiri: tampil / sembunyi (tidak bisa tampil bersamaan).
    var showPlaylist by rememberSaveable { mutableStateOf(false) }
    var showChannels by rememberSaveable { mutableStateOf(false) }
    BackHandler(enabled = showPlaylist || showChannels) {
        showPlaylist = false
        showChannels = false
    }

    // Panel MP3 dan radio tampil bersamaan, tetapi hanya satu yang aktif; status panel yang tidak aktif dikosongkan.
    val mp3Active = mode == AppMode.MP3
    val idleUi = ui.copy(
        mediaId = null, title = null, artist = null, isPlaying = false, positionMs = 0L, durationMs = 0L,
        playbackState = Player.STATE_IDLE, playWhenReady = false,
    )
    val mp3Ui = if (mp3Active) ui else idleUi
    val radioUi = if (mp3Active) idleUi else ui

    // Portrait, urutan dari atas: player MP3 (dek kaset) -> radio -> equalizer -> amplifier VU meter.
    // Tinggi panel mengikuti tinggi layar; kalau layar terlalu pendek, halaman bisa digulir.
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(WA_DESK)
            .displayCutoutPadding()
            .navigationBarsPadding()
            .padding(6.dp)
            .imePadding(),
    ) {
        val gap = 5.dp
        val avail = maxHeight
        val usable = avail - gap * 3
        val deckH = maxOf(236.dp, usable * 0.37f)
        val radioH = maxOf(124.dp, usable * 0.20f)
        val eqH = maxOf(130.dp, usable * 0.215f)
        val ampH = maxOf(130.dp, usable * 0.215f)

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(gap),
        ) {
            Mp3DeckWindow(
                vm = vm,
                ui = mp3Ui,
                active = mp3Active,
                listVisible = showPlaylist,
                onToggleList = { showPlaylist = !showPlaylist; if (showPlaylist) showChannels = false },
                onMinimize = { minimizeToFloating(context) },
                onClose = { closeApp(context, vm) },
                modifier = Modifier.height(deckH),
            )
            if (showPlaylist) {
                // Playlist menggantikan tiga panel di bawah player MP3; sembunyikan lewat tombol HIDE / PLAYLIST / tombol kembali.
                PlaylistWindow(
                    vm = vm,
                    granted = granted,
                    onRequestPermission = { launcher.launch(requestedPermissions()) },
                    onDeleteSong = onDeleteSong,
                    onHide = { showPlaylist = false },
                    modifier = Modifier.height(maxOf(300.dp, avail - deckH - gap)),
                )
            } else {
                RadioWindow(
                    vm = vm,
                    ui = radioUi,
                    active = !mp3Active,
                    listVisible = showChannels,
                    onToggleList = { showChannels = !showChannels },
                    modifier = Modifier.height(radioH),
                )
                if (showChannels) {
                    RadioListWindow(
                        vm = vm,
                        onHide = { showChannels = false },
                        modifier = Modifier.height(maxOf(240.dp, avail - deckH - radioH - gap * 2)),
                    )
                } else {
                    EqWindow(Modifier.height(eqH))
                    VuWindow(vm, Modifier.height(ampH))
                }
            }
        }
    }
}

/** Tutup: hentikan lagu, tutup mini player dan service pemutar, lalu keluar dari aplikasi. */
private fun closeApp(context: Context, vm: PlayerViewModel) {
    vm.stopAll()
    context.stopService(Intent(context, FloatingPlayerService::class.java))
    context.stopService(Intent(context, PlaybackService::class.java))
    (context as? Activity)?.finishAndRemoveTask()
}
