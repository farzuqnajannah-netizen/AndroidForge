
## Perubahan v2.0
- Slider volume di jendela player dihapus; volume sekarang lewat **knob besar** di tengah panel bawah (putar melingkar = volume, ketuk = bisu). Berlaku untuk mode musik dan radio.
- Equalizer: pilihan preset (FLAT/BASS/ROCK/VOKAL/POP) dihapus. Tinggal tombol **ON/OFF** dan slider manual. Tombol **NOISE** (noise filter) ikut dipindah ke panel ini.
- BASS BOOST, STEREO WIDTH, dan POWER AMP dipindah dari panel bawah ke panel equalizer.
- Panel bawah jadi **VU METER**: VU meter jarum L dan R, di bawahnya LED meter L dan R yang bergerak berlawanan (L menyala ke kiri, R ke kanan), knob volume besar di tengah.
- Radio: knob volume di kiri dihapus (sudah ada knob besar di panel bawah).
