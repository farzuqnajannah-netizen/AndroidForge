KIPAS GANTUNG MINI - paket untuk dibuat APK

Isi:
  www/index.html   Aplikasi lengkap dalam satu file (musik latar dan semua gambar sudah tertanam).

Cara membuat APK:
  Opsi A - Online (paling mudah): unggah folder "www" (atau zip-nya) ke layanan HTML-ke-APK
           seperti WebIntoApp, Appsgeyser, atau Median.co. Titik masuk: index.html.
  Opsi B - Capacitor:
           npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
           npx cap init "Kipas Gantung Mini" id.sejukjiwa.kipas --web-dir=www
           npx cap add android
           npx cap sync
           npx cap open android      (lalu Build > Build APK di Android Studio)

Catatan:
  - Pengaturan yang disarankan: orientasi potret, layar penuh.
  - File memuat font Google (Inter, Space Grotesk, Amiri) lewat internet. Bila perangkat offline,
    huruf otomatis memakai font bawaan sistem dan aplikasi tetap berjalan normal.
