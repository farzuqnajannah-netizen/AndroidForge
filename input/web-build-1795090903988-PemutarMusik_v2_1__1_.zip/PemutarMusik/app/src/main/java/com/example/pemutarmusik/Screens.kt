package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(s / 60, s % 60)
}

@Composable
private fun rememberMeter(read: () -> Float): Float {
    var db by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            db = read()
            delay(100)
        }
    }
    return db
}

/** Lampu kecil berlabel: LED menyala/mati + teks. */
@Composable
fun Lamp(label: String, color: Color, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Led(color, on, diameter = 7.dp)
        Text(
            label,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            color = if (on) WA_INK else WA_LAMP_OFF,
        )
    }
}

/** Tombol ikon bulat kecil + LED di sampingnya (menyala = aktif). */
@Composable
private fun LedToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    ledColor: Color,
    on: Boolean,
    onClick: () -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        WaIconButton(icon, description, onClick, buttonSize = 26.dp, iconSize = 14.dp)
        Led(ledColor, on, diameter = 7.dp)
    }
}

// ================================================================== JENDELA UTAMA

/** Nomor versi aplikasi, mis. "v.1.8". Diambil dari versionName di app/build.gradle.kts, jadi cukup ubah di satu tempat. */
@Composable
private fun appVersionLabel(context: android.content.Context): String = remember {
    try {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        "v.${info.versionName}"
    } catch (e: Exception) {
        ""
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainWindow(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val s by AudioEngine.settings.collectAsState()
    val guardDb = rememberMeter { AudioEngine.processor.guardReductionDb }
    val limDb = rememberMeter { AudioEngine.processor.limiterReductionDb }
    val pal = Skin.p
    val mode by vm.mode.collectAsState()
    val titleH = rememberTitleBarHeight()
    val versionLabel = appVersionLabel(LocalContext.current)

    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
    val shown = drag ?: fraction

    // Jendela tetap (tanpa minimize), mengisi 1/3 tinggi kolom kiri.
    WaWindow(
        if (mode == AppMode.RADIO) "RADIO DIGITAL" else "MUSIC PLAYER", modifier = modifier, fill = true,
        contentPadding = 3.dp,
        titleHeight = titleH,
        actions = {
            ModeButtons(mode, vm::setMode, titleH)
            Text(
                "mod by aries $versionLabel",
                color = Color(0xFF7FEBFF),
                fontSize = 9.sp,
                fontFamily = MONO,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                lineHeight = 11.sp,
                style = CenteredLine,
                maxLines = 1,
                modifier = Modifier.padding(end = 8.dp),
            )
        },
    ) {
        if (mode == AppMode.RADIO) {
            RadioBody(vm, ui)
            return@WaWindow
        }
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // KIRI: layar LCD (waktu + spectrum), lampu status, bar seek
            Column(Modifier.weight(0.85f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(
                    Modifier.fillMaxWidth().weight(1f).bevel(false, WA_LCD).padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        formatTime((shown * ui.durationMs).toLong().takeIf { drag != null } ?: ui.positionMs),
                        color = WA_GREEN,
                        fontSize = 22.sp,
                        fontFamily = MONO,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterVertically),
                    )
                    SpectrumView(ui.isPlaying, Modifier.weight(1f).fillMaxHeight())
                }
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Lamp("GRD", pal.c1, guardDb > 0.5f)
                    Lamp("NSE", pal.c2, s.noiseFilter)
                    Lamp("EQ", pal.c3, s.enabled)
                    Lamp("LIM", pal.c4, limDb > 0.5f)
                }
                WaSlider(
                    value = shown,
                    onValueChange = { drag = it },
                    range = 0f..1f,
                    onDone = {
                        drag?.let { vm.seekTo((it * ui.durationMs).toLong()) }
                        drag = null
                    },
                    modifier = Modifier.fillMaxWidth().height(14.dp),
                )
            }

            // KANAN: judul berjalan, 5 tombol transport (di tengah), acak + ulang
            Column(Modifier.weight(1.3f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                Box(
                    Modifier.fillMaxWidth().height(20.dp).bevel(false, WA_LCD).padding(horizontal = 4.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    val label = if (ui.title != null) "${ui.artist} - ${ui.title}  ***  " else "MUSIC PLAYER  ***  "
                    Text(
                        label,
                        color = WA_GREEN,
                        fontSize = 11.sp,
                        fontFamily = MONO,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE),
                    )
                }

                // sebelumnya, jeda, PUTAR (tengah, lebih besar), henti, berikutnya.
                // Kelima tombol menyala biru tua OCEAN saat ditekan; tombol sesuai status tetap menyala.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
                ) {
                    WaIconButton(Icons.Filled.SkipPrevious, "Sebelumnya", vm::previous, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3)
                    WaIconButton(Icons.Filled.Pause, "Jeda", vm::pause, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3, active = ui.isPaused)
                    WaIconButton(Icons.Filled.PlayArrow, "Putar", vm::play, buttonSize = 36.dp, iconSize = 22.dp, accent = pal.c3, active = ui.isPlaying)
                    WaIconButton(Icons.Filled.Stop, "Henti", vm::stop, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3, active = ui.isStopped)
                    WaIconButton(Icons.Filled.SkipNext, "Berikutnya", vm::next, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3)
                }

                // Volume ada di knob besar panel bawah; di sini tinggal acak + ulang, di tengah.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
                ) {
                    // Acak (shuffle): LED menyala = aktif
                    LedToggle(Icons.Filled.Shuffle, "Acak", pal.c2, ui.shuffle, vm::toggleShuffle)
                    // Ulang: mati -> semua (LED cyan) -> 1 lagu (LED kuning)
                    LedToggle(
                        icon = if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        description = when (ui.repeatMode) {
                            Player.REPEAT_MODE_ONE -> "Ulang 1 lagu"
                            Player.REPEAT_MODE_ALL -> "Ulang semua"
                            else -> "Ulang mati"
                        },
                        ledColor = if (ui.repeatMode == Player.REPEAT_MODE_ONE) pal.c4 else pal.c1,
                        on = ui.repeatMode != Player.REPEAT_MODE_OFF,
                        onClick = vm::toggleRepeat,
                    )
                }
            }
        }
    }
}

// ================================================================== EQUALIZER 10 BAND + PREAMP

private val FREQ_LABELS = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

@Composable
private fun EqColumn(
    label: String,
    value: Float,
    enabled: Boolean,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
        WaSlider(
            value = value,
            onValueChange = onChange,
            range = -EqAudioProcessor.MAX_GAIN_DB..EqAudioProcessor.MAX_GAIN_DB,
            vertical = true,
            centered = true,
            enabled = enabled,
            thumb = 10.dp,
            modifier = Modifier.width(24.dp).weight(1f),
        )
        Text(label, color = WA_TEXT, fontSize = 8.sp, lineHeight = 9.sp, fontFamily = MONO, maxLines = 1)
    }
}

@Composable
fun EqWindow(modifier: Modifier = Modifier) {
    val s by AudioEngine.settings.collectAsState()
    WaWindow("EQUALIZER 10 BAND", modifier = modifier, fill = true, contentPadding = 3.dp) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // kiri: ON/OFF equalizer + noise filter, lalu bass boost, power amp, pre amp
            Column(Modifier.width(140.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                Row(
                    Modifier.fillMaxWidth().height(20.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    WaButton(if (s.enabled) "ON" else "OFF", { AudioEngine.update { it.copy(enabled = !it.enabled) } }, Modifier.weight(1f), active = s.enabled)
                    Led(Skin.p.c3, s.enabled)
                    WaButton("NOISE", { AudioEngine.update { it.copy(noiseFilter = !it.noiseFilter) } }, Modifier.weight(1f), active = s.noiseFilter)
                    Led(Skin.p.c2, s.noiseFilter)
                }
                ParamRow("BASS BOOST") { m ->
                    WaSlider(s.bassBoost, { v -> AudioEngine.update { it.copy(bassBoost = v) } }, 0f..1f, m)
                }
                ParamRow("POWER AMP") { m ->
                    WaSlider(s.ampDb, { v -> AudioEngine.update { it.copy(ampDb = (v * 2f).roundToInt() / 2f) } }, 0f..12f, m)
                }
                ParamRow("PRE AMP") { m ->
                    WaSlider(
                        s.preampDb,
                        { v -> AudioEngine.update { it.copy(preampDb = (v * 2f).roundToInt() / 2f) } },
                        -EqAudioProcessor.MAX_GAIN_DB..EqAudioProcessor.MAX_GAIN_DB, m, centered = true,
                    )
                }
            }
            // kanan: 10 slider band memakai seluruh sisa lebar dan tinggi
            Row(Modifier.weight(1f).fillMaxHeight().bevel(false, Color(0xFFC2C9D9)).padding(vertical = 1.dp, horizontal = 2.dp)) {
                for (i in 0 until EqAudioProcessor.BAND_COUNT) {
                    EqColumn(
                        FREQ_LABELS[i], s.gains[i], s.enabled,
                        { v ->
                            AudioEngine.update { st ->
                                st.copy(gains = st.gains.toMutableList().also { it[i] = (v * 2f).roundToInt() / 2f })
                            }
                        },
                        Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

// ================================================================== PARAMETER (dipakai panel equalizer)

@Composable
private fun ParamRow(label: String, content: @Composable (Modifier) -> Unit) {
    Row(Modifier.fillMaxWidth().height(20.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            color = WA_TEXT,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.width(50.dp),
        )
        content(Modifier.weight(1f).height(15.dp))
    }
}

// ================================================================== VU METER L/R + LED METER + KNOB VOLUME

private const val VU_DB_MIN = -36f
private const val VU_DB_MAX = 3f

/** Level linear (0..1) -> posisi 0..1 pada skala -36..+3 dB. */
private fun levelToFrac(lin: Float): Float {
    if (lin <= 0.00002f) return 0f
    return ((20f * log10(lin) - VU_DB_MIN) / (VU_DB_MAX - VU_DB_MIN)).coerceIn(0f, 1f)
}

/**
 * Level kiri/kanan (0..1) yang sudah dihaluskan: naik cepat, turun pelan.
 * Level dikalikan volume pemutar supaya meter ikut bergerak saat knob volume diputar.
 */
@Composable
private fun rememberStereoLevels(playing: Boolean, volume: Float): Pair<Float, Float> {
    val playingNow by rememberUpdatedState(playing)
    val volumeNow by rememberUpdatedState(volume)
    var levels by remember { mutableStateOf(0f to 0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 33_000_000L) continue
            last = now
            val (oldL, oldR) = levels
            if (!playingNow && oldL <= 0.002f && oldR <= 0.002f) {
                if (oldL != 0f || oldR != 0f) levels = 0f to 0f
                continue
            }
            val pr = AudioEngine.processor
            val targetL = if (playingNow) levelToFrac(pr.levelL * volumeNow) else 0f
            val targetR = if (playingNow) levelToFrac(pr.levelR * volumeNow) else 0f
            val newL = oldL + (targetL - oldL) * (if (targetL > oldL) 0.6f else 0.12f)
            val newR = oldR + (targetR - oldR) * (if (targetR > oldR) 0.6f else 0.12f)
            levels = newL to newR
        }
    }
    return levels
}

private fun dbToFrac(db: Float): Float = ((db - VU_DB_MIN) / (VU_DB_MAX - VU_DB_MIN)).coerceIn(0f, 1f)

/**
 * VU meter klasik: muka krem dengan lampu belakang hangat (warm), skala 30..0..+3 (zona merah di ujung),
 * jarum hitam beralur bayangan, bingkai krom dan kaca berkilau. [label] = "L" atau "R".
 */
@Composable
private fun VuMeter(label: String, frac: Float, modifier: Modifier = Modifier) {
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
            textAlign = android.graphics.Paint.Align.CENTER
        }
    }
    val ink = Color(0xFF2B1A08)
    val red = Color(0xFFC4281A)
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val f = frac.coerceIn(0f, 1f)

            // ---- bingkai krom (3D) + cekungan muka
            val outer = CornerRadius(6.dp.toPx())
            drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFE9EDF6), Color(0xFF7D88A3), Color(0xFF1B2342))), cornerRadius = outer)
            drawRoundRect(Color(0xFF0A0F22), cornerRadius = outer, style = Stroke(1.dp.toPx()))
            val bz = 2.5.dp.toPx()
            val fx = bz
            val fy = bz
            val fw = w - 2 * bz
            val fh = h - 2 * bz
            val faceR = CornerRadius(4.dp.toPx())
            val faceTL = Offset(fx, fy)
            val faceSz = Size(fw, fh)

            // ---- muka: lampu hangat dari bawah-tengah (sedikit makin terang saat sinyal naik)
            val lamp = 0.86f + 0.14f * f
            drawRoundRect(
                Brush.radialGradient(
                    listOf(Color(0xFFFFF4CF), Color(0xFFFFDC8A), Color(0xFFF0AE48), Color(0xFFB66F1E)),
                    Offset(w / 2f, h * 0.95f), w * 0.62f,
                ),
                faceTL, faceSz, faceR,
            )
            drawRoundRect(Color(0xFF2A1400).copy(alpha = (1f - lamp) * 0.55f), faceTL, faceSz, faceR)
            // bayangan dalam di tepi atas (muka tampak masuk)
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0x88000000), Color(0x00000000)), fy, fy + 9.dp.toPx()),
                faceTL, faceSz, faceR,
            )

            // ---- geometri busur: pivot di bawah muka supaya busur lebar dan landai (klasik)
            val maxDeg = 42f
            val sinM = sin(Math.toRadians(maxDeg.toDouble())).toFloat()
            val cosM = cos(Math.toRadians(maxDeg.toDouble())).toFloat()
            val topMargin = 9.dp.toPx() + bz
            val rs = min(fw * 0.47f / sinM, (h - 19.dp.toPx() - bz) / (1f - cosM)).coerceAtLeast(20.dp.toPx())
            val pivot = Offset(w / 2f, topMargin + rs)
            fun ang(db: Float) = -maxDeg + dbToFrac(db) * maxDeg * 2f
            fun pt(deg: Float, rad: Float): Offset {
                val a = Math.toRadians(deg.toDouble())
                return Offset(pivot.x + rad * sin(a).toFloat(), pivot.y - rad * cos(a).toFloat())
            }

            clipRect(fx, fy, fx + fw, fy + fh) {
                // busur skala + zona merah (0..+3 dB)
                val arcTL = Offset(pivot.x - rs, pivot.y - rs)
                val arcSz = Size(rs * 2f, rs * 2f)
                drawArc(ink, -90f + ang(VU_DB_MIN), maxDeg * 2f, false, arcTL, arcSz, style = Stroke(1.dp.toPx()))
                val redStart = ang(0f)
                drawArc(red, -90f + redStart, maxDeg - redStart, false, arcTL, arcSz, style = Stroke(3.dp.toPx()))

                // garis skala: tiap 5 dB di bawah -10, tiap 1 dB dari -10 sampai +3
                val ticks = listOf(-35f, -30f, -25f, -20f, -15f) + (-10..3).map { it.toFloat() }
                val majors = setOf(-30f, -20f, -10f, -5f, 0f, 3f)
                for (db in ticks) {
                    val major = db in majors
                    val inRed = db >= 0f
                    drawLine(
                        if (inRed) red else ink,
                        pt(ang(db), rs * (if (major) 0.86f else 0.92f)), pt(ang(db), rs),
                        if (major) 1.6.dp.toPx() else 0.9.dp.toPx(),
                    )
                }

                // angka skala
                paint.textSize = 6.5.sp.toPx()
                for ((db, txt) in listOf(-30f to "30", -20f to "20", -10f to "10", -5f to "5", 0f to "0", 3f to "+3")) {
                    paint.color = (if (db >= 0f) red else ink).toArgb()
                    val p = pt(ang(db), rs * 0.74f)
                    drawContext.canvas.nativeCanvas.drawText(txt, p.x, p.y + 2.5.dp.toPx(), paint)
                }

                // jarum: bayangan, badan, lalu penutup poros di bawah
                val needleDeg = -maxDeg + f * maxDeg * 2f
                val tip = pt(needleDeg, rs * 0.99f)
                val base = pt(needleDeg, rs * 0.30f)
                val shadowOff = Offset(2.dp.toPx(), 1.8.dp.toPx())
                drawLine(Color(0x44000000), base + shadowOff, tip + shadowOff, 1.8.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFF14100A), pivot, tip, 1.7.dp.toPx(), StrokeCap.Round)
                // bayangan lembut di dasar muka tempat jarum keluar
                drawRect(
                    Brush.verticalGradient(listOf(Color(0x00000000), Color(0x55000000)), fy + fh - 10.dp.toPx(), fy + fh),
                    Offset(fx, fy + fh - 10.dp.toPx()), Size(fw, 10.dp.toPx()),
                )
            }

            // ---- kaca berkilau
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0x55FFFFFF), Color(0x0AFFFFFF)), fy, fy + fh * 0.5f),
                faceTL, Size(fw, fh * 0.5f), faceR,
            )
            drawRoundRect(Color(0x88000000), faceTL, faceSz, faceR, style = Stroke(1.dp.toPx()))
            drawRoundRect(Color(0x66FFFFFF), Offset(bz * 0.5f, bz * 0.5f), Size(w - bz, h - bz), CornerRadius(5.dp.toPx()), style = Stroke(0.8.dp.toPx()))
        }
        Text(
            label,
            color = Color(0xFF2B1A08),
            fontSize = 10.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            lineHeight = 11.sp,
            style = CenteredLine,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 7.dp, bottom = 5.dp),
        )
        Text(
            "VU",
            color = Color(0xFF2B1A08),
            fontSize = 9.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            lineHeight = 10.sp,
            style = CenteredLine,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 7.dp, bottom = 5.dp),
        )
    }
}

/**
 * LED meter modern: segmen kapsul kaca dengan cahaya (glow) dan gradasi cyan -> hijau -> kuning -> merah, plus penanda puncak.
 * Mulai dari tengah (dekat knob volume) lalu menyala ke luar:
 * [growLeft] = true -> ke kiri (kanal L), false -> ke kanan (kanal R). Jadi L dan R bergerak berlawanan.
 */
@Composable
private fun LedMeter(frac: Float, growLeft: Boolean, modifier: Modifier = Modifier) {
    val fracNow by rememberUpdatedState(frac)
    var peak by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 33_000_000L) continue
            last = now
            val f = fracNow
            val p = peak
            val np = if (f >= p) f else maxOf(f, p - 0.025f)
            if (np != p) peak = np
        }
    }
    val cLow = Skin.p.c1
    val cMid = Skin.p.c2
    val cAmber = Color(0xFFFFC21A)
    val cHot = Color(0xFFFF3B2A)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val dp = 1.dp.toPx()
        // rumah kaca gelap berkilau
        val hr = CornerRadius(h * 0.38f)
        drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF03081A), Color(0xFF0E1B40))), cornerRadius = hr)
        drawRoundRect(Color(0x66FFFFFF), Offset(0.5f * dp, 0.5f * dp), Size(w - dp, h - dp), hr, style = Stroke(dp))
        drawRoundRect(Color(0xFF000000), cornerRadius = hr, style = Stroke(dp))

        val segs = 24
        val pad = 2.dp.toPx()
        val gap = 1.4.dp.toPx()
        val segW = ((w - 2 * pad - gap * (segs - 1)) / segs).coerceAtLeast(1f)
        val segH = (h - 2 * pad).coerceAtLeast(1f)
        val sr = CornerRadius(minOf(segW, segH) * 0.42f)
        val lit = (frac.coerceIn(0f, 1f) * segs + 0.5f).toInt()
        val pk = (peak.coerceIn(0f, 1f) * segs - 0.5f).toInt().coerceIn(0, segs - 1)

        fun segColor(i: Int): Color {
            val t = i / (segs - 1f)
            return when {
                t < 0.5f -> lerp(cLow, cMid, t / 0.5f)
                t < 0.8f -> lerp(cMid, cAmber, (t - 0.5f) / 0.3f)
                else -> lerp(cAmber, cHot, (t - 0.8f) / 0.2f)
            }
        }
        for (i in 0 until segs) {
            val x = if (growLeft) w - pad - (i + 1) * segW - i * gap else pad + i * (segW + gap)
            val col = segColor(i)
            val tl = Offset(x, pad)
            val sz = Size(segW, segH)
            if (i < lit) {
                drawRoundRect(col.copy(alpha = 0.30f), Offset(x - dp, pad - dp), Size(segW + 2 * dp, segH + 2 * dp), CornerRadius(sr.x + dp))
                drawRoundRect(
                    Brush.verticalGradient(listOf(lerp(col, Color.White, 0.5f), col, lerp(col, Color.Black, 0.35f)), pad, pad + segH),
                    tl, sz, sr,
                )
                drawRoundRect(Color(0x55FFFFFF), Offset(x + dp * 0.6f, pad + dp * 0.6f), Size((segW - dp * 1.2f).coerceAtLeast(0f), segH * 0.38f), sr)
            } else {
                drawRoundRect(
                    Brush.verticalGradient(listOf(Color(0xFF22366B), Color(0xFF0C1735)), pad, pad + segH),
                    tl, sz, sr,
                )
                drawRoundRect(col.copy(alpha = 0.10f), tl, sz, sr)
                drawRoundRect(Color(0x22FFFFFF), Offset(x + dp * 0.6f, pad + dp * 0.6f), Size((segW - dp * 1.2f).coerceAtLeast(0f), segH * 0.30f), sr)
            }
        }
        // penanda puncak (peak hold)
        if (peak > 0.03f && pk >= lit) {
            val x = if (growLeft) w - pad - (pk + 1) * segW - pk * gap else pad + pk * (segW + gap)
            drawRoundRect(Color.White.copy(alpha = 0.55f), Offset(x - dp, pad - dp), Size(segW + 2 * dp, segH + 2 * dp), CornerRadius(sr.x + dp))
            drawRoundRect(Color.White, Offset(x, pad), Size(segW, segH), sr)
        }
    }
}

@Composable
fun VuWindow(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val (levelL, levelR) = rememberStereoLevels(ui.isPlaying, ui.volume)
    val muted = ui.volume <= 0.001f

    WaWindow("VU METER", modifier = modifier, fill = true, contentPadding = 3.dp) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            // knob memakai seluruh tinggi panel (tulisan ditaruh di celah bawah knob)
            val knobSize = maxHeight.coerceIn(56.dp, 150.dp)
            Row(
                Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // KIRI: VU meter L + LED meter L (menyala ke kiri)
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    VuMeter("L", levelL, Modifier.fillMaxWidth().weight(1f))
                    LedMeter(levelL, growLeft = true, modifier = Modifier.fillMaxWidth().height(13.dp))
                }
                // TENGAH: knob volume besar (putar = volume, ketuk = bisu)
                RadioKnob(
                    frac = ui.volume,
                    label = if (muted) "BISU" else "VOLUME",
                    knobSize = knobSize,
                    onTurn = { d -> vm.setVolume(vm.ui.value.volume + d) },
                    onTap = vm::toggleMute,
                    labelInside = true,
                )
                // KANAN: VU meter R + LED meter R (menyala ke kanan)
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    VuMeter("R", levelR, Modifier.fillMaxWidth().weight(1f))
                    LedMeter(levelR, growLeft = false, modifier = Modifier.fillMaxWidth().height(13.dp))
                }
            }
        }
    }
}
