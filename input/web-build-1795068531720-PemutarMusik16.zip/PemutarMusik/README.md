# MP3 (Android) - skin Ocean Blue

Jendela: PEMUTAR MUSIK (tombol minimize = mini player melayang), EQUALIZER 10 BAND, DSP / POWER AMP, PLAYLIST.

## Fitur
- Acak (shuffle) dan Ulang (mati / semua / 1 lagu), masing-masing dengan LED.
- Skin permanen OCEAN (tombol ganti skin dihapus).
- Playlist: tekan lama lagu -> Pindah ke album, Hapus lagu, Rincian (+ Naikkan/Turunkan urutan, Keluarkan dari album saat di dalam album).
- Album = playlist buatan sendiri: tombol "+" buat album, tekan lama nama album -> Ganti nama / Hapus album,
  tombol TAMBAH untuk memilih banyak lagu sesuai urutan ketukan.
- Suara: auto headroom, limiter look-ahead, bass guard otomatis, power amp 0..+12 dB.

## Cara pakai
1. Android Studio terbaru, File > Open > pilih folder ini, tunggu Gradle sync.
2. Colok HP (USB debugging), Run. Beri izin akses musik.
Min Android 7.0 (API 24).

## Catatan v6
- Nama aplikasi: MP3, ikon baru gradasi violet-magenta-coral (adaptive icon).
- Tombol utama: sebelumnya / jeda / putar (tengah, lebih besar) / henti / berikutnya (5 tombol, juga di mini player; tombol sesuai status tetap menyala, mini player selalu di tengah dan hanya digeser naik/turun, menyala biru tua OCEAN saat ditekan). Tombol acak dan ulang ada di baris bawah bersama EQ/DSP/PL; 5 tombol transport di tengah. Font playlist diperbesar.
- Playlist punya kolom cari di bagian bawah.
- Mini player melayang punya grafik spectrum warna.

## Instal tanpa peringatan Play Protect (sebisanya)
Peringatan Play Protect muncul untuk aplikasi di luar Play Store dari developer yang belum dikenal; tidak bisa dihilangkan 100% lewat kode.
1. Buat kunci tanda tangan sendiri (sekali saja, simpan baik-baik, jangan hilang):
   `keytool -genkeypair -v -keystore pemutarmusik.jks -alias pemutarmusik -keyalg RSA -keysize 2048 -validity 10000`
2. Salin `keystore.properties.example` jadi `keystore.properties`, isi password, taruh `.jks` di folder yang sama.
3. Build rilis: `./gradlew assembleRelease` (APK bertanda tangan tetap, bukan debug). Pakai kunci yang sama untuk semua versi.
4. Tanpa peringatan sama sekali: unggah ke Google Play Console (pengujian internal/tertutup), lalu instal dari tautan Play Store.
5. Hanya di HP sendiri: pilih "Instal saja" sekali, atau matikan "Pindai aplikasi dengan Play Protect", atau instal lewat `adb install`.

## Tampilan landscape
- Aplikasi dikunci landscape (`sensorLandscape`, boleh terbalik 180 derajat) dan layar penuh (status bar dan tombol navigasi disembunyikan; geser dari tepi layar untuk menampilkannya sebentar).
- Layar dibagi 2: kiri (player, EQ, DSP) sedikit lebih lebar dari kanan (playlist). Kiri: player, equalizer, DSP bertumpuk dengan tinggi sama (masing-masing 1/3), permanen tanpa minimize. Kanan: playlist, permanen.
- Tombol EQ / DSP / PL dihapus dari player.
- Pojok kanan atas (di baris judul playlist): "–" = minimize jadi mini player, "×" = tutup aplikasi (lagu dihentikan).
- Urutan lagu: terbaru (waktu ditambahkan) di atas, juga di dalam album.
- Judul jendela player: "MUSIC PLAYER", dengan tulisan "mod by aries" di pojok kanan atas jendela player.
- Tombol minimize (biru muda, "–") dan tutup (merah, "×") dibuat jelas; ukurannya mengikuti tinggi layar HP.
- Baris judul jendela player (kiri atas) dan playlist (kanan) sama tinggi; judul EQ/DSP tetap; teks judul rata tengah atas-bawah.
- Ikon aplikasi: gradasi biru OCEAN (biru laut dalam -> biru -> cyan), bar putih, titik aksen cyan muda.

## Mode radio (streaming)
- Saklar **MP3 | RADIO** ada di baris judul jendela player (kiri atas). Pindah mode menghentikan pemutaran yang sedang jalan.
- Mode RADIO: jendela player berubah jadi radio digital (frekuensi digital, skala tuner FM, lampu LIVE/BUF, nama stasiun berjalan, status ON AIR). Tombol: stasiun sebelumnya, jeda, putar, henti, stasiun berikutnya. EQ dan DSP tetap bekerja untuk radio.
- Jendela kanan berubah jadi **STASIUN RADIO**: ketuk stasiun = putar; ikon pensil = edit nama / frekuensi / alamat URL / hapus; tombol "+ STASIUN" = tambah stasiun (nama, frekuensi manual opsional, URL).
- Stasiun bawaan: Sebayu FM, Slawi FM, Sananta, Paramount FM, Elshinta (frekuensi kosong, isi manual lewat edit).
- Alamat harus langsung ke stream audio (MP3/AAC/HLS). Alamat berakhiran "/" yang gagal otomatis dicoba lagi dengan "/;" (server Shoutcast lama). File playlist .pls / .m3u belum didukung.
- Izin baru: INTERNET dan WAKE_LOCK; lalu lintas http (tanpa https) diizinkan agar stream lama tetap bisa dibuka.

## Nomor seri (versi)
- Tulisan di pojok kanan atas jendela player: "mod by aries v.16". Angkanya diambil otomatis dari `versionCode` di `app/build.gradle.kts`.
- Tiap selesai modif, naikkan `versionCode` (dan samakan `versionName`) di file itu: 16 -> 17 -> 18 dst. Tulisan di aplikasi ikut berubah.
- Nama file zip dari Claude mengikuti nomor yang sama (PemutarMusik16.zip dst.).
