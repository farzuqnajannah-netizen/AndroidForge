package com.example.pemutarmusik

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Mode aplikasi: pemutar file MP3 atau radio streaming. */
enum class AppMode { MP3, RADIO }

/** Stasiun radio. [freq] = frekuensi FM dalam MHz (boleh kosong), mis. "99.5". [url] = alamat stream audio. */
data class RadioStation(val id: Long, val name: String, val freq: String, val url: String)

/** Penyimpanan stasiun radio + mode terakhir di SharedPreferences. */
object RadioStore {
    private const val PREFS = "radio"
    private const val KEY_STATIONS = "stations"
    private const val KEY_RADIO_MODE = "radio_mode"
    private const val KEY_LAST = "last_station"

    /** Stasiun bawaan (lokal Tegal dan Elshinta). Frekuensi sengaja kosong: isi manual lewat tombol edit. */
    fun defaults(): List<RadioStation> = listOf(
        RadioStation(1, "Sebayu FM", "", "https://radio-streaming.tegalkota.go.id/stream/1/"),
        RadioStation(2, "Slawi FM", "", "https://slawifm.id/"),
        RadioStation(3, "Sananta", "", "https://streaming.sanantafm.com/"),
        RadioStation(4, "Paramount FM", "", "https://stream.pasopatiradio.com/paramountfm"),
        RadioStation(5, "Elshinta", "", "https://stream-ssl.arenastreaming.com:8000/jakarta"),
    )

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context): List<RadioStation> {
        val raw = prefs(context).getString(KEY_STATIONS, null) ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                RadioStation(o.getLong("id"), o.getString("name"), o.optString("freq", ""), o.getString("url"))
            }
        } catch (e: Exception) {
            defaults()
        }
    }

    fun save(context: Context, stations: List<RadioStation>) {
        val arr = JSONArray()
        for (s in stations) {
            arr.put(JSONObject().put("id", s.id).put("name", s.name).put("freq", s.freq).put("url", s.url))
        }
        prefs(context).edit().putString(KEY_STATIONS, arr.toString()).apply()
    }

    fun isRadioMode(context: Context): Boolean = prefs(context).getBoolean(KEY_RADIO_MODE, false)

    fun setRadioMode(context: Context, radio: Boolean) {
        prefs(context).edit().putBoolean(KEY_RADIO_MODE, radio).apply()
    }

    /** Stasiun terakhir dipilih, null kalau belum ada. */
    fun lastStation(context: Context): Long? =
        prefs(context).getLong(KEY_LAST, -1L).takeIf { it >= 0 }

    fun setLastStation(context: Context, id: Long?) {
        prefs(context).edit().putLong(KEY_LAST, id ?: -1L).apply()
    }
}
