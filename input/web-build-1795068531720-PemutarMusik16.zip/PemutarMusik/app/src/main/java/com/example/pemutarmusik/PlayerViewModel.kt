package com.example.pemutarmusik

import android.app.Application
import android.content.ComponentName
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PlayerUi(
    val mediaId: String? = null,
    val title: String? = null,
    val artist: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_ALL,   // OFF / ALL / ONE
    val volume: Float = 1f,
    val playbackState: Int = Player.STATE_IDLE,
    val playWhenReady: Boolean = false,
) {
    /** Status transport: main (isPlaying) / jeda (posisi > 0) / henti (posisi 0). Dipakai untuk menyalakan ikon tombol. */
    val isPaused: Boolean get() = !isPlaying && positionMs > 0L
    val isStopped: Boolean get() = !isPlaying && positionMs <= 0L
}

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    private val _albums = MutableStateFlow(AlbumStore.load(app))
    val albums: StateFlow<List<Album>> = _albums.asStateFlow()

    // ---- mode radio ----
    private val _mode = MutableStateFlow(if (RadioStore.isRadioMode(app)) AppMode.RADIO else AppMode.MP3)
    val mode: StateFlow<AppMode> = _mode.asStateFlow()

    private val _stations = MutableStateFlow(RadioStore.load(app))
    val stations: StateFlow<List<RadioStation>> = _stations.asStateFlow()

    private val _stationId = MutableStateFlow(RadioStore.lastStation(app))
    val stationId: StateFlow<Long?> = _stationId.asStateFlow()

    private val _radioError = MutableStateFlow<String?>(null)
    val radioError: StateFlow<String?> = _radioError.asStateFlow()

    private var fallbackTried = false

    private var controller: MediaController? = null
    private var pendingDelete: Song? = null

    init {
        connectToService()
        viewModelScope.launch {
            while (true) {
                delay(250)
                val c = controller ?: continue
                if (c.isPlaying) _ui.update { it.copy(positionMs = c.currentPosition) }
            }
        }
    }

    private fun connectToService() {
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = syncFromPlayer()
                    override fun onPlayerError(error: PlaybackException) = onRadioError(error)
                })
                syncFromPlayer()
            } catch (e: Exception) {
                // Gagal konek ke service: pemutar tidak tersedia
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun syncFromPlayer() {
        val c = controller ?: return
        val item = c.currentMediaItem
        _ui.value = PlayerUi(
            mediaId = item?.mediaId,
            title = item?.mediaMetadata?.title?.toString(),
            artist = item?.mediaMetadata?.artist?.toString(),
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = c.duration.takeIf { it != C.TIME_UNSET } ?: 0L,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            volume = c.volume,
            playbackState = c.playbackState,
            playWhenReady = c.playWhenReady,
        )
        if (c.playbackState == Player.STATE_READY) _radioError.value = null
    }

    // ------------------------------------------------------------------ lagu

    fun loadSongs() {
        viewModelScope.launch {
            val list = try {
                withContext(Dispatchers.IO) { MusicRepository.loadMp3(getApplication()) }
            } catch (e: SecurityException) {
                emptyList()
            }
            _songs.value = list
            _loaded.value = true
        }
    }

    /** Putar [song] dengan antrean = [list] (urutan album atau semua lagu). */
    fun playList(list: List<Song>, song: Song) {
        val c = controller ?: return
        val index = list.indexOfFirst { it.id == song.id }
        if (index < 0) return
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun play() {
        val c = controller ?: return
        if (c.currentMediaItem == null) {
            val all = _songs.value
            all.firstOrNull()?.let { playList(all, it) }
        } else {
            c.play()
        }
    }

    fun pause() {
        controller?.pause()
    }

    fun stop() {
        val c = controller ?: return
        c.pause()
        c.seekTo(0L)
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    /** Siklus: OFF -> ULANG SEMUA -> ULANG 1 LAGU -> OFF. */
    fun toggleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setVolume(v: Float) {
        val c = controller ?: return
        c.volume = v.coerceIn(0f, 1f)
        _ui.update { it.copy(volume = c.volume) }
    }

    // ------------------------------------------------------------------ radio

    /** Pindah mode MP3 <-> radio. Pemutaran yang sedang jalan dihentikan supaya tidak tercampur. */
    fun setMode(m: AppMode) {
        if (m == _mode.value) return
        controller?.let {
            it.stop()
            it.clearMediaItems()
        }
        _radioError.value = null
        _mode.value = m
        RadioStore.setRadioMode(getApplication(), m == AppMode.RADIO)
    }

    private fun stationItem(st: RadioStation, url: String): MediaItem =
        MediaItem.Builder()
            .setMediaId("radio:${st.id}")
            .setUri(url)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(st.name)
                    .setArtist(if (st.freq.isNotBlank()) "FM ${st.freq}" else "Radio")
                    .setIsPlayable(true)
                    .build()
            )
            .build()

    private fun currentStation(): RadioStation? = _stations.value.firstOrNull { it.id == _stationId.value }

    /** Putar stream [st] dari awal (menyambung ulang ke siaran langsung). */
    fun playStation(st: RadioStation) {
        val c = controller ?: return
        _stationId.value = st.id
        RadioStore.setLastStation(getApplication(), st.id)
        _radioError.value = null
        fallbackTried = false
        c.setMediaItem(stationItem(st, st.url))
        c.prepare()
        c.play()
    }

    fun radioPlay() {
        val c = controller ?: return
        val st = currentStation() ?: _stations.value.firstOrNull() ?: return
        val sameItem = c.currentMediaItem?.mediaId == "radio:${st.id}"
        if (!sameItem || c.playbackState == Player.STATE_IDLE || c.playbackState == Player.STATE_ENDED) {
            playStation(st)
        } else {
            c.seekToDefaultPosition()   // lompat ke siaran langsung, bukan lanjut dari sisa buffer lama
            c.play()
        }
    }

    fun radioPause() {
        controller?.pause()
    }

    fun radioStop() {
        _radioError.value = null
        controller?.stop()
    }

    /** Pindah ke stasiun berikutnya (+1) / sebelumnya (-1) dan langsung diputar. */
    fun stepStation(delta: Int) {
        val list = _stations.value
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.id == _stationId.value }
        val j = if (i < 0) 0 else (i + delta).mod(list.size)
        playStation(list[j])
    }

    private fun onRadioError(error: PlaybackException) {
        if (_mode.value != AppMode.RADIO) return
        val st = currentStation() ?: return
        val c = controller ?: return
        // Server Shoutcast lama: "http://host:port/" menampilkan halaman web, audionya ada di "/;"
        if (!fallbackTried && st.url.endsWith("/")) {
            fallbackTried = true
            c.setMediaItem(stationItem(st, st.url + ";"))
            c.prepare()
            c.play()
            return
        }
        _radioError.value = when (error.errorCode) {
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "Tidak bisa terhubung. Cek internet atau alamat server."
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "Server menolak. Alamat URL mungkin salah."
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED -> "Alamat ini bukan stream audio. Edit URL stasiun."
            else -> "Gagal memutar stream (kode ${error.errorCode})."
        }
    }

    private fun mutateStations(block: (List<RadioStation>) -> List<RadioStation>) {
        val next = block(_stations.value)
        _stations.value = next
        RadioStore.save(getApplication(), next)
    }

    fun addStation(name: String, freq: String, url: String) {
        val id = System.currentTimeMillis()
        mutateStations { it + RadioStation(id, name, freq, url) }
    }

    fun updateStation(id: Long, name: String, freq: String, url: String) {
        val updated = RadioStation(id, name, freq, url)
        mutateStations { list -> list.map { if (it.id == id) updated else it } }
        // Kalau yang diedit sedang disiarkan, sambungkan ulang dengan alamat baru
        val c = controller
        if (c != null && c.currentMediaItem?.mediaId == "radio:$id" && c.playbackState != Player.STATE_IDLE) {
            playStation(updated)
        }
    }

    fun deleteStation(id: Long) {
        if (_stationId.value == id) {
            controller?.stop()
            _stationId.value = null
            RadioStore.setLastStation(getApplication(), null)
        }
        mutateStations { list -> list.filter { it.id != id } }
    }

    // ------------------------------------------------------------------ album

    private fun mutateAlbums(block: (List<Album>) -> List<Album>) {
        val next = block(_albums.value)
        _albums.value = next
        AlbumStore.save(getApplication(), next)
    }

    fun createAlbum(name: String, songIds: List<Long>): Long {
        val id = System.currentTimeMillis()
        mutateAlbums { it + Album(id, name.trim().ifBlank { "Album" }, songIds.distinct()) }
        return id
    }

    fun renameAlbum(id: Long, name: String) = mutateAlbums { list ->
        list.map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }) else it }
    }

    fun deleteAlbum(id: Long) = mutateAlbums { list -> list.filter { it.id != id } }

    fun addToAlbum(id: Long, songIds: List<Long>) = mutateAlbums { list ->
        list.map { a ->
            if (a.id != id) a else a.copy(songIds = a.songIds + songIds.filter { it !in a.songIds }.distinct())
        }
    }

    fun removeFromAlbum(albumId: Long, songId: Long) = mutateAlbums { list ->
        list.map { a -> if (a.id == albumId) a.copy(songIds = a.songIds - songId) else a }
    }

    /** Geser lagu di dalam album: delta -1 = naik, +1 = turun. */
    fun moveInAlbum(albumId: Long, songId: Long, delta: Int) = mutateAlbums { list ->
        list.map { a ->
            if (a.id != albumId) return@map a
            val i = a.songIds.indexOf(songId)
            val j = i + delta
            if (i < 0 || j !in a.songIds.indices) return@map a
            val m = a.songIds.toMutableList()
            m[i] = m[j].also { m[j] = m[i] }
            a.copy(songIds = m)
        }
    }

    // ------------------------------------------------------------------ hapus lagu

    fun requestDelete(song: Song): DeleteOutcome {
        pendingDelete = song
        val outcome = MusicRepository.deleteSong(getApplication(), song)
        if (outcome is DeleteOutcome.Done) {
            pendingDelete = null
            finishDelete(song)
        }
        return outcome
    }

    fun onDeleteResult(ok: Boolean) {
        val song = pendingDelete
        pendingDelete = null
        if (!ok || song == null) return
        if (Build.VERSION.SDK_INT == 29) MusicRepository.deleteAgain(getApplication(), song)
        finishDelete(song)
    }

    private fun finishDelete(song: Song) {
        mutateAlbums { list -> list.map { it.copy(songIds = it.songIds - song.id) } }
        loadSongs()
    }

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}
