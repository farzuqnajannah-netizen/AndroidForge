package com.example.pemutarmusik

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.example.pemutarmusik.audio.AudioEngine
import java.util.Locale

// ================================================================== TAMPILAN RADIO DIGITAL (isi jendela player)

/** Isi jendela player saat mode RADIO: layar frekuensi digital + skala tuner di kiri, tombol dan volume di kanan. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RadioBody(vm: PlayerViewModel, ui: PlayerUi) {
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val error by vm.radioError.collectAsState()
    val s by AudioEngine.settings.collectAsState()
    val pal = Skin.p
    val station = stations.firstOrNull { it.id == stationId }

    val stopped = ui.playbackState == Player.STATE_IDLE || ui.playbackState == Player.STATE_ENDED
    val connecting = !stopped && ui.playWhenReady && ui.playbackState == Player.STATE_BUFFERING
    val playing = ui.isPlaying
    val paused = !stopped && !playing && !connecting

    val freq = station?.freq?.replace(',', '.')?.toFloatOrNull()
    val freqText = freq?.let { String.format(Locale.US, "%.1f", it) } ?: "--.-"
    // Judul lagu dari stream (ICY) kalau ada; kalau sama dengan nama stasiun, abaikan
    val onAir = if (station != null && ui.mediaId == "radio:${station.id}") ui.title?.takeIf { it != station.name } else null

    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        // KIRI: layar digital + lampu + skala tuner
        Column(Modifier.weight(0.85f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(
                Modifier.fillMaxWidth().weight(1f).bevel(false, WA_LCD).padding(horizontal = 6.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            freqText,
                            color = WA_GREEN,
                            fontSize = 24.sp,
                            fontFamily = MONO,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 26.sp,
                            style = CenteredLine,
                        )
                        Spacer(Modifier.width(3.dp))
                        Column(Modifier.padding(bottom = 2.dp)) {
                            Text("FM", color = pal.c1, fontSize = 9.sp, fontFamily = MONO, fontWeight = FontWeight.Bold, lineHeight = 10.sp, style = CenteredLine)
                            Text("MHz", color = WA_GREEN_DIM, fontSize = 8.sp, fontFamily = MONO, lineHeight = 9.sp, style = CenteredLine)
                        }
                    }
                    Text(
                        station?.name ?: "PILIH STASIUN",
                        color = pal.c1,
                        fontSize = 9.sp,
                        fontFamily = MONO,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                SpectrumView(playing, Modifier.weight(1f).fillMaxHeight())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                Lamp("LIVE", pal.c2, playing)
                Lamp("BUF", pal.c4, connecting)
                Lamp("NSE", pal.c2, s.noiseFilter)
                Lamp("EQ", pal.c3, s.enabled)
            }
            TunerDial(freq, Modifier.fillMaxWidth().height(14.dp))
        }

        // KANAN: nama stasiun berjalan, 5 tombol, volume + status
        Column(Modifier.weight(1.3f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
            Box(
                Modifier.fillMaxWidth().height(20.dp).bevel(false, WA_LCD).padding(horizontal = 4.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                val label = when {
                    error != null -> "! $error   "
                    station == null -> "PILIH STASIUN DI DAFTAR  ***  "
                    onAir != null -> "${station.name} - $onAir  ***  "
                    else -> "${station.name}  ***  "
                }
                Text(
                    label,
                    color = if (error != null) Color(0xFFFF9E94) else WA_GREEN,
                    fontSize = 11.sp,
                    fontFamily = MONO,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE),
                )
            }

            // stasiun sebelumnya, jeda, PUTAR (tengah), henti, stasiun berikutnya
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
            ) {
                WaIconButton(Icons.Filled.SkipPrevious, "Stasiun sebelumnya", { vm.stepStation(-1) }, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3)
                WaIconButton(Icons.Filled.Pause, "Jeda", vm::radioPause, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3, active = paused)
                WaIconButton(Icons.Filled.PlayArrow, "Putar", vm::radioPlay, buttonSize = 36.dp, iconSize = 22.dp, accent = pal.c3, active = playing || connecting)
                WaIconButton(Icons.Filled.Stop, "Henti", vm::radioStop, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3, active = stopped)
                WaIconButton(Icons.Filled.SkipNext, "Stasiun berikutnya", { vm.stepStation(+1) }, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("VOL", color = WA_TEXT, fontSize = 9.sp, fontFamily = MONO, modifier = Modifier.padding(end = 4.dp))
                WaSlider(
                    value = ui.volume,
                    onValueChange = vm::setVolume,
                    range = 0f..1f,
                    modifier = Modifier.weight(1f).height(14.dp),
                )
                val (statusText, statusColor) = when {
                    error != null -> "ERROR" to Color(0xFFD62B2B)
                    connecting -> "MENYAMBUNG" to Color(0xFFB7791F)
                    playing -> "ON AIR" to WA_LAMP_ON
                    paused -> "JEDA" to WA_INK
                    else -> "STOP" to WA_LAMP_OFF
                }
                Text(
                    statusText,
                    color = statusColor,
                    fontSize = 8.sp,
                    fontFamily = MONO,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    textAlign = TextAlign.End,
                    modifier = Modifier.width(62.dp).padding(start = 4.dp),
                )
            }
        }
    }
}

/** Skala tuner FM 87.5-108 MHz dengan jarum di posisi frekuensi stasiun (tanpa jarum kalau frekuensi belum diisi). */
@Composable
private fun TunerDial(freq: Float?, modifier: Modifier = Modifier) {
    val needle = Skin.p.c1
    Canvas(modifier.bevel(false, WA_LCD_DARK)) {
        val padX = 6.dp.toPx()
        val w = size.width - padX * 2
        val minF = 87.5f
        val maxF = 108f
        val steps = 41                      // garis tiap 0,5 MHz
        val base = size.height - 2.dp.toPx()
        for (i in 0..steps) {
            val x = padX + w * i / steps
            val major = i % 10 == 0         // garis panjang tiap 5 MHz
            val len = size.height * if (major) 0.55f else 0.3f
            drawLine(Color(0xFF6F8CC8), Offset(x, base), Offset(x, base - len), 1.dp.toPx())
        }
        if (freq != null) {
            val frac = ((freq - minF) / (maxF - minF)).coerceIn(0f, 1f)
            val x = padX + w * frac
            drawLine(needle, Offset(x, 1.dp.toPx()), Offset(x, size.height - 1.dp.toPx()), 2.dp.toPx())
        }
    }
}

// ================================================================== DAFTAR STASIUN (jendela kanan)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RadioListWindow(
    vm: PlayerViewModel,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val titleH = rememberTitleBarHeight()
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val ui by vm.ui.collectAsState()
    val pal = Skin.p

    var editing by remember { mutableStateOf<RadioStation?>(null) }
    var adding by remember { mutableStateOf(false) }

    WaWindow(
        "STASIUN RADIO", modifier, fill = true,
        titleHeight = titleH,
        actions = {
            WaTitleButton(false, "Kecilkan ke mini player", titleH, onMinimize)
            WaTitleButton(true, "Tutup aplikasi", titleH, onClose)
        },
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().bevel(false, WA_LCD)) {
            if (stations.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Belum ada stasiun.\nTekan + STASIUN untuk menambah.",
                        color = WA_GREEN, fontSize = 11.sp, fontFamily = MONO, textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(stations, key = { it.id }) { st ->
                        val isCurrent = st.id == stationId
                        val live = isCurrent && ui.isPlaying
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(if (isCurrent) WA_SEL else Color.Transparent)
                                .clickable { vm.playStation(st) }
                                .padding(start = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                if (live) "▶" else " ",
                                color = if (isCurrent) Color.White else pal.c1,
                                fontSize = 11.sp, fontFamily = MONO,
                                modifier = Modifier.width(14.dp),
                            )
                            Text(
                                st.freq.ifBlank { "--.-" },
                                color = if (isCurrent) Color.White else pal.c1,
                                fontSize = 13.sp, fontFamily = MONO, fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(52.dp),
                            )
                            Text(
                                st.name,
                                color = if (isCurrent) Color.White else WA_GREEN,
                                fontSize = 13.sp, fontFamily = MONO,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            Box(
                                Modifier.size(38.dp).clickable { editing = st },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    Icons.Filled.Edit, "Edit stasiun",
                                    tint = if (isCurrent) Color.White else WA_GREEN_DIM,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "${stations.size} STASIUN  -  ketuk = putar",
                color = WA_INK, fontSize = 9.sp, fontFamily = MONO, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            WaButton("+ STASIUN", { adding = true })
        }
    }

    if (adding) {
        StationDialog(
            initial = null,
            onSave = { name, freq, url -> vm.addStation(name, freq, url); adding = false },
            onDelete = null,
            onDismiss = { adding = false },
        )
    }
    editing?.let { st ->
        StationDialog(
            initial = st,
            onSave = { name, freq, url -> vm.updateStation(st.id, name, freq, url); editing = null },
            onDelete = { vm.deleteStation(st.id); editing = null },
            onDismiss = { editing = null },
        )
    }
}

/** Rapikan alamat: tambahkan https:// kalau belum ada. Mengembalikan null kalau bukan alamat yang valid. */
private fun normalizeUrl(raw: String): String? {
    val t = raw.trim()
    if (t.isEmpty()) return null
    val full = if (t.startsWith("http://", true) || t.startsWith("https://", true)) t else "https://$t"
    val host = try { Uri.parse(full).host } catch (e: Exception) { null }
    return if (!host.isNullOrBlank() && host.contains('.')) full else null
}

@Composable
private fun StationDialog(
    initial: RadioStation?,
    onSave: (name: String, freq: String, url: String) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var freq by remember { mutableStateOf(initial?.freq ?: "") }
    var url by remember { mutableStateOf(initial?.url ?: "") }
    var problem by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val fieldStyle = TextStyle(color = Color.White, fontFamily = MONO, fontSize = 14.sp)

    fun trySave() {
        val cleanUrl = normalizeUrl(url)
        val f = freq.trim().replace(',', '.')
        val fNum = f.toFloatOrNull()
        when {
            name.isBlank() -> problem = "Nama stasiun belum diisi."
            cleanUrl == null -> problem = "Alamat URL tidak valid."
            f.isNotEmpty() && (fNum == null || fNum !in 76f..108f) -> problem = "Frekuensi FM harus 76 - 108 MHz (contoh 99.5)."
            else -> onSave(
                name.trim(),
                if (fNum != null) String.format(Locale.US, "%.1f", fNum) else "",
                cleanUrl.orEmpty(),
            )
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1B2F66),
        titleContentColor = Color.White,
        textContentColor = WA_GREEN,
        title = {
            Text(
                if (initial == null) "Tambah stasiun" else "Edit stasiun",
                fontFamily = MONO, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it.take(40); problem = null },
                        singleLine = true,
                        label = { Text("Nama stasiun") },
                        textStyle = fieldStyle,
                        modifier = Modifier.weight(1.6f),
                    )
                    OutlinedTextField(
                        value = freq,
                        onValueChange = { v -> freq = v.filter { it.isDigit() || it == '.' || it == ',' }.take(6); problem = null },
                        singleLine = true,
                        label = { Text("Frekuensi") },
                        placeholder = { Text("99.5") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = fieldStyle,
                        modifier = Modifier.weight(1f),
                    )
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; problem = null },
                    singleLine = true,
                    label = { Text("Alamat URL stream") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    textStyle = fieldStyle,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Frekuensi boleh dikosongkan. Alamat harus langsung ke stream audio (MP3/AAC), bukan halaman web.",
                    color = WA_GREEN_DIM, fontFamily = MONO, fontSize = 10.sp,
                )
                problem?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = Color(0xFFFF9E94), fontFamily = MONO, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { trySave() }) {
                Text("SIMPAN", color = Skin.p.c1, fontFamily = MONO, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = { if (confirmDelete) onDelete() else confirmDelete = true }) {
                        Text(
                            if (confirmDelete) "YAKIN HAPUS?" else "HAPUS",
                            color = Color(0xFFFF9E94), fontFamily = MONO, fontWeight = FontWeight.Bold,
                        )
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text("BATAL", color = WA_GREEN_DIM, fontFamily = MONO, fontWeight = FontWeight.Bold)
                }
            }
        },
    )
}
