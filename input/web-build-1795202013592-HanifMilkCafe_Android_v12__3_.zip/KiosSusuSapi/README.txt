HANIF MILK CAFE - proyek Android (Gradle)

Proyek WebView sederhana. Aplikasinya ada di app/src/main/assets/index.html (satu file).

Build:  gradle assembleDebug   atau   gradle assembleRelease   atau   gradle bundleDebug
Persyaratan: JDK 17, Android SDK platform 34, Gradle 8.7 atau lebih baru.
APK release memakai kunci debug agar bisa langsung dipasang.
