package com.classic.amplifier;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RecoverableSecurityException;
import android.content.ContentResolver;
import android.content.BroadcastReceiver;
import android.content.ContentUris;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1001;
    private static final int REQ_PERM = 2001;
    private static final int REQ_DEL = 3001;
    private static final int REQ_DEL_LEGACY = 3002;
    private final ArrayList<Long> pendingIds = new ArrayList<>();
    private final ArrayDeque<Long> delQueue = new ArrayDeque<>();
    private final ArrayList<Long> delDone = new ArrayList<>();
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private volatile boolean scanning = false;
    private static final String CH_ID = "now_playing";
    private static final int NTF_ID = 77;
    private static final String ACT = "com.classic.amplifier.REMOTE";
    private final BroadcastReceiver remote = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String a = i.getStringExtra("a");
            if (a != null && webView != null) {
                webView.evaluateJavascript("window.__remote&&window.__remote('" + a + "')", null);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain("appassets.androidplatform.net")
                .setHttpAllowed(true)
                .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#050505")); // tidak ada kilat putih saat memuat
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccess(false);
        // renderer WebView tetap berprioritas tinggi walau aplikasi di latar belakang -> audio tidak putus
        if (Build.VERSION.SDK_INT >= 26) webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH_ID, "Sedang diputar",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        IntentFilter f = new IntentFilter(ACT);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(remote, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(remote, f);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String path = u.getPath();
                if (path != null && path.startsWith("/media/")
                        && "appassets.androidplatform.net".equals(u.getHost())) {
                    return serveMedia(path.substring(7), request.getRequestHeaders());
                }
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                startScan(); // pindai otomatis lagu di memori saat aplikasi dibuka
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        // Isi folder www/ menjadi root assets -> http://appassets.androidplatform.net/
        webView.loadUrl("http://appassets.androidplatform.net/index.html");
    }

    /* ---------- jembatan JS <-> native ---------- */
    private class Bridge {
        @JavascriptInterface
        public void scan() {
            runOnUiThread(MainActivity.this::startScan);
        }

        @JavascriptInterface
        public void nowPlaying(String title, boolean playing, boolean radio) {
            final String t = title;
            final boolean p = playing, rd = radio;
            runOnUiThread(() -> showNowPlaying(t, p, rd));
        }

        @JavascriptInterface
        public void deleteTracks(String json) {
            final String j = json;
            runOnUiThread(() -> deleteIds(j));
        }
    }

    private String audioPermission() {
        return Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private void startScan() {
        String perm = audioPermission();
        boolean legacy = Build.VERSION.SDK_INT <= 28;
        boolean ok = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
                && (!legacy || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED);
        if (!ok) {
            if (legacy) requestPermissions(new String[]{perm, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
            else if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(new String[]{perm, Manifest.permission.POST_NOTIFICATIONS}, REQ_PERM);
            else requestPermissions(new String[]{perm}, REQ_PERM);
            return;
        }
        doScan();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERM && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            doScan();
        }
    }

    private void doScan() {
        if (scanning) return;
        scanning = true;
        new Thread(() -> {
            JSONArray arr = new JSONArray();
            String[] proj = {
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.DATE_ADDED
            };
            try (Cursor c = getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                    MediaStore.Audio.Media.IS_MUSIC + " != 0", null,
                    MediaStore.Audio.Media.DATE_ADDED + " DESC")) {
                if (c != null) {
                    while (c.moveToNext()) {
                        JSONObject o = new JSONObject();
                        o.put("id", c.getLong(0));
                        o.put("title", c.getString(1));
                        o.put("dur", c.getLong(2) / 1000.0);
                        o.put("added", c.getLong(3));
                        arr.put(o);
                    }
                }
            } catch (Exception ignored) {
            }
            final String js = "window.__nativeTracks&&window.__nativeTracks(" + arr.toString() + ")";
            runOnUiThread(() -> {
                scanning = false;
                if (webView != null) webView.evaluateJavascript(js, null);
            });
        }).start();
    }

    /* ---------- notifikasi sedang diputar ---------- */
    private PendingIntent actionIntent(String a, int code) {
        Intent i = new Intent(ACT).setPackage(getPackageName()).putExtra("a", a);
        return PendingIntent.getBroadcast(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private void showNowPlaying(String title, boolean playing, boolean radio) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (title == null || title.isEmpty()) {
            nm.cancel(NTF_ID);
            try { stopService(new Intent(this, PlaybackService.class)); } catch (Exception ignored) { }
            abandonFocus();
            return;
        }
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_ID) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText((playing ? "Sedang diputar" : "Dijeda") + (radio ? " · Radio" : " · Classic Amplifier"))
                .setContentIntent(content)
                .setOngoing(playing)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (!radio) b.addAction(android.R.drawable.ic_media_previous, "Sebelumnya", actionIntent("prev", 1));
        b.addAction(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                playing ? "Jeda" : "Putar", actionIntent("toggle", 2));
        b.addAction(android.R.drawable.ic_media_next, "Berikutnya", actionIntent("next", 3));
        b.setStyle(new Notification.MediaStyle().setShowActionsInCompactView(radio ? new int[]{0, 1} : new int[]{0, 1, 2}));
        Notification ntf = b.build();
        boolean canNotify = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        if (canNotify) nm.notify(NTF_ID, ntf);
        updateService(ntf, playing, radio);
        if (playing) requestFocus();
        else if (!lostTransient) abandonFocus();
    }

    /* ---------- layanan latar depan agar audio stabil di belakang layar ---------- */
    private void updateService(Notification n, boolean playing, boolean radio) {
        try {
            if (PlaybackService.instance != null) {
                PlaybackService.instance.update(n, playing, radio);
            } else if (playing) {
                Intent i = new Intent(this, PlaybackService.class)
                        .putExtra("n", n).putExtra("playing", true).putExtra("radio", radio);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                else startService(i);
            }
        } catch (Exception ignored) {
        }
    }

    /* ---------- fokus audio: jeda/lanjut/kecilkan saat aplikasi lain memutar suara ---------- */
    private AudioFocusRequest focusReq;
    private boolean hasFocus = false, lostTransient = false;

    private void js(String code) {
        if (webView != null) webView.evaluateJavascript(code, null);
    }

    private final AudioManager.OnAudioFocusChangeListener focusL = change -> {
        switch (change) {
            case AudioManager.AUDIOFOCUS_LOSS:
                lostTransient = false;
                hasFocus = false;
                js("window.nativePause&&window.nativePause()");
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                lostTransient = true;
                js("window.nativePause&&window.nativePause()");
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                js("window.nativeDuck&&window.nativeDuck(true)");
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                hasFocus = true;
                js("window.nativeDuck&&window.nativeDuck(false)");
                if (lostTransient) {
                    lostTransient = false;
                    js("window.nativeResume&&window.nativeResume()");
                }
                break;
            default:
                break;
        }
    };

    private void requestFocus() {
        if (hasFocus) return;
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                if (focusReq == null) {
                    focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                            .setOnAudioFocusChangeListener(focusL)
                            .build();
                }
                hasFocus = am.requestAudioFocus(focusReq) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            }
        } catch (Exception ignored) {
        }
    }

    private void abandonFocus() {
        if (!hasFocus) return;
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (Build.VERSION.SDK_INT >= 26 && focusReq != null) am.abandonAudioFocusRequest(focusReq);
        } catch (Exception ignored) {
        }
        hasFocus = false;
    }

    /* ---------- hapus permanen ---------- */
    private Uri audioUri(long id) {
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
    }

    private void reportDeleted(ArrayList<Long> ids) {
        JSONArray a = new JSONArray();
        for (Long id : ids) a.put(id.longValue());
        if (webView != null) {
            webView.evaluateJavascript("window.__nativeDeleted&&window.__nativeDeleted(" + a + ")", null);
        }
    }

    private void deleteIds(String json) {
        try {
            JSONArray a = new JSONArray(json);
            ArrayList<Long> ids = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) ids.add(a.getLong(i));
            if (ids.isEmpty()) return;
            if (Build.VERSION.SDK_INT >= 30) {
                ArrayList<Uri> uris = new ArrayList<>();
                for (Long id : ids) uris.add(audioUri(id));
                PendingIntent pi = MediaStore.createDeleteRequest(getContentResolver(), uris);
                pendingIds.clear();
                pendingIds.addAll(ids);
                startIntentSenderForResult(pi.getIntentSender(), REQ_DEL, null, 0, 0, 0);
            } else {
                delQueue.clear();
                delQueue.addAll(ids);
                delDone.clear();
                processDeleteQueue();
            }
        } catch (Exception ignored) {
        }
    }

    private void processDeleteQueue() {
        while (!delQueue.isEmpty()) {
            long id = delQueue.peek();
            try {
                getContentResolver().delete(audioUri(id), null, null);
                delDone.add(id);
                delQueue.poll();
            } catch (SecurityException e) {
                if (Build.VERSION.SDK_INT >= 29 && e instanceof RecoverableSecurityException) {
                    try {
                        startIntentSenderForResult(((RecoverableSecurityException) e).getUserAction()
                                .getActionIntent().getIntentSender(), REQ_DEL_LEGACY, null, 0, 0, 0);
                        return; // lanjut di onActivityResult
                    } catch (Exception ex) {
                        delQueue.poll();
                    }
                } else {
                    delQueue.poll();
                }
            } catch (Exception e) {
                delQueue.poll();
            }
        }
        reportDeleted(new ArrayList<>(delDone));
        delDone.clear();
    }

    /* ---------- menyajikan file audio dengan dukungan Range (agar bisa seek) ---------- */
    private WebResourceResponse serveMedia(String idStr, Map<String, String> reqHeaders) {
        try {
            long id = Long.parseLong(idStr);
            Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
            ContentResolver cr = getContentResolver();
            ParcelFileDescriptor pfd = cr.openFileDescriptor(uri, "r");
            if (pfd == null) return notFound();
            long size = pfd.getStatSize();
            String mime = cr.getType(uri);
            if (mime == null || !mime.startsWith("audio/")) mime = "audio/mpeg";

            long start = 0, end = size - 1;
            boolean partial = false;
            String range = null;
            for (Map.Entry<String, String> e : reqHeaders.entrySet()) {
                if ("range".equalsIgnoreCase(e.getKey())) range = e.getValue();
            }
            if (range != null && range.startsWith("bytes=") && size > 0) {
                String[] p = range.substring(6).split("-", 2);
                try {
                    if (!p[0].isEmpty()) {
                        start = Long.parseLong(p[0].trim());
                        if (p.length > 1 && !p[1].trim().isEmpty()) end = Long.parseLong(p[1].trim());
                    } else if (p.length > 1 && !p[1].trim().isEmpty()) {
                        start = Math.max(0, size - Long.parseLong(p[1].trim()));
                    }
                    if (end >= size) end = size - 1;
                    if (start > end) { start = 0; end = size - 1; } else partial = true;
                } catch (NumberFormatException ignored) {
                    start = 0; end = size - 1;
                }
            }
            long length = end - start + 1;

            FileInputStream fis = new ParcelFileDescriptor.AutoCloseInputStream(pfd);
            if (start > 0) fis.getChannel().position(start);
            InputStream body = new LimitedStream(fis, length);

            Map<String, String> h = new HashMap<>();
            h.put("Accept-Ranges", "bytes");
            h.put("Content-Length", String.valueOf(length));
            if (partial) h.put("Content-Range", "bytes " + start + "-" + end + "/" + size);
            return new WebResourceResponse(mime, null, partial ? 206 : 200,
                    partial ? "Partial Content" : "OK", h, body);
        } catch (Exception e) {
            return notFound();
        }
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<>(), new java.io.ByteArrayInputStream(new byte[0]));
    }

    private static class LimitedStream extends FilterInputStream {
        private long left;
        LimitedStream(InputStream in, long limit) { super(in); left = limit; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int r = super.read();
            if (r >= 0) left--;
            return r;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int r = super.read(b, off, (int) Math.min(len, left));
            if (r > 0) left -= r;
            return r;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_DEL) {
            if (resultCode == RESULT_OK) reportDeleted(new ArrayList<>(pendingIds));
            pendingIds.clear();
            return;
        }
        if (requestCode == REQ_DEL_LEGACY) {
            if (resultCode != RESULT_OK && !delQueue.isEmpty()) delQueue.poll();
            processDeleteQueue();
            return;
        }
        if (requestCode == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        try { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(NTF_ID); } catch (Exception ignored) { }
        try { unregisterReceiver(remote); } catch (Exception ignored) { }
        try { stopService(new Intent(this, PlaybackService.class)); } catch (Exception ignored) { }
        abandonFocus();
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
