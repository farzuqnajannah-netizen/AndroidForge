package com.classic.amplifier;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.RecoverableSecurityException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1001;
    private static final int REQ_PERM = 2001;
    private static final int REQ_DEL = 3001;
    private static final int REQ_DEL_LEGACY = 3002;
    private final ArrayList<Long> pendingIds = new ArrayList<>();
    private final ArrayDeque<Long> delQueue = new ArrayDeque<>();
    private final ArrayList<Long> delDone = new ArrayList<>();
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private volatile boolean scanning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain("appassets.androidplatform.net")
                .setHttpAllowed(true)
                .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccess(false);

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String path = u.getPath();
                if (path != null && path.startsWith("/media/")
                        && "appassets.androidplatform.net".equals(u.getHost())) {
                    return serveMedia(path.substring(7), request.getRequestHeaders());
                }
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                startScan(); // pindai otomatis lagu di memori saat aplikasi dibuka
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        // Isi folder www/ menjadi root assets -> http://appassets.androidplatform.net/
        webView.loadUrl("http://appassets.androidplatform.net/index.html");
    }

    /* ---------- jembatan JS <-> native ---------- */
    private class Bridge {
        @JavascriptInterface
        public void scan() {
            runOnUiThread(MainActivity.this::startScan);
        }

        @JavascriptInterface
        public void deleteTracks(String json) {
            final String j = json;
            runOnUiThread(() -> deleteIds(j));
        }
    }

    private String audioPermission() {
        return Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    private void startScan() {
        String perm = audioPermission();
        boolean legacy = Build.VERSION.SDK_INT <= 28;
        boolean ok = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
                && (!legacy || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED);
        if (!ok) {
            if (legacy) requestPermissions(new String[]{perm, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
            else requestPermissions(new String[]{perm}, REQ_PERM);
            return;
        }
        doScan();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERM && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            doScan();
        }
    }

    private void doScan() {
        if (scanning) return;
        scanning = true;
        new Thread(() -> {
            JSONArray arr = new JSONArray();
            String[] proj = {
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.DATE_ADDED
            };
            try (Cursor c = getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                    MediaStore.Audio.Media.IS_MUSIC + " != 0", null,
                    MediaStore.Audio.Media.DATE_ADDED + " DESC")) {
                if (c != null) {
                    while (c.moveToNext()) {
                        JSONObject o = new JSONObject();
                        o.put("id", c.getLong(0));
                        o.put("title", c.getString(1));
                        o.put("dur", c.getLong(2) / 1000.0);
                        o.put("added", c.getLong(3));
                        arr.put(o);
                    }
                }
            } catch (Exception ignored) {
            }
            final String js = "window.__nativeTracks&&window.__nativeTracks(" + arr.toString() + ")";
            runOnUiThread(() -> {
                scanning = false;
                if (webView != null) webView.evaluateJavascript(js, null);
            });
        }).start();
    }

    /* ---------- hapus permanen ---------- */
    private Uri audioUri(long id) {
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
    }

    private void reportDeleted(ArrayList<Long> ids) {
        JSONArray a = new JSONArray();
        for (Long id : ids) a.put(id.longValue());
        if (webView != null) {
            webView.evaluateJavascript("window.__nativeDeleted&&window.__nativeDeleted(" + a + ")", null);
        }
    }

    private void deleteIds(String json) {
        try {
            JSONArray a = new JSONArray(json);
            ArrayList<Long> ids = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) ids.add(a.getLong(i));
            if (ids.isEmpty()) return;
            if (Build.VERSION.SDK_INT >= 30) {
                ArrayList<Uri> uris = new ArrayList<>();
                for (Long id : ids) uris.add(audioUri(id));
                PendingIntent pi = MediaStore.createDeleteRequest(getContentResolver(), uris);
                pendingIds.clear();
                pendingIds.addAll(ids);
                startIntentSenderForResult(pi.getIntentSender(), REQ_DEL, null, 0, 0, 0);
            } else {
                delQueue.clear();
                delQueue.addAll(ids);
                delDone.clear();
                processDeleteQueue();
            }
        } catch (Exception ignored) {
        }
    }

    private void processDeleteQueue() {
        while (!delQueue.isEmpty()) {
            long id = delQueue.peek();
            try {
                getContentResolver().delete(audioUri(id), null, null);
                delDone.add(id);
                delQueue.poll();
            } catch (SecurityException e) {
                if (Build.VERSION.SDK_INT >= 29 && e instanceof RecoverableSecurityException) {
                    try {
                        startIntentSenderForResult(((RecoverableSecurityException) e).getUserAction()
                                .getActionIntent().getIntentSender(), REQ_DEL_LEGACY, null, 0, 0, 0);
                        return; // lanjut di onActivityResult
                    } catch (Exception ex) {
                        delQueue.poll();
                    }
                } else {
                    delQueue.poll();
                }
            } catch (Exception e) {
                delQueue.poll();
            }
        }
        reportDeleted(new ArrayList<>(delDone));
        delDone.clear();
    }

    /* ---------- menyajikan file audio dengan dukungan Range (agar bisa seek) ---------- */
    private WebResourceResponse serveMedia(String idStr, Map<String, String> reqHeaders) {
        try {
            long id = Long.parseLong(idStr);
            Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
            ContentResolver cr = getContentResolver();
            ParcelFileDescriptor pfd = cr.openFileDescriptor(uri, "r");
            if (pfd == null) return notFound();
            long size = pfd.getStatSize();
            String mime = cr.getType(uri);
            if (mime == null || !mime.startsWith("audio/")) mime = "audio/mpeg";

            long start = 0, end = size - 1;
            boolean partial = false;
            String range = null;
            for (Map.Entry<String, String> e : reqHeaders.entrySet()) {
                if ("range".equalsIgnoreCase(e.getKey())) range = e.getValue();
            }
            if (range != null && range.startsWith("bytes=") && size > 0) {
                String[] p = range.substring(6).split("-", 2);
                try {
                    if (!p[0].isEmpty()) {
                        start = Long.parseLong(p[0].trim());
                        if (p.length > 1 && !p[1].trim().isEmpty()) end = Long.parseLong(p[1].trim());
                    } else if (p.length > 1 && !p[1].trim().isEmpty()) {
                        start = Math.max(0, size - Long.parseLong(p[1].trim()));
                    }
                    if (end >= size) end = size - 1;
                    if (start > end) { start = 0; end = size - 1; } else partial = true;
                } catch (NumberFormatException ignored) {
                    start = 0; end = size - 1;
                }
            }
            long length = end - start + 1;

            FileInputStream fis = new ParcelFileDescriptor.AutoCloseInputStream(pfd);
            if (start > 0) fis.getChannel().position(start);
            InputStream body = new LimitedStream(fis, length);

            Map<String, String> h = new HashMap<>();
            h.put("Accept-Ranges", "bytes");
            h.put("Content-Length", String.valueOf(length));
            if (partial) h.put("Content-Range", "bytes " + start + "-" + end + "/" + size);
            return new WebResourceResponse(mime, null, partial ? 206 : 200,
                    partial ? "Partial Content" : "OK", h, body);
        } catch (Exception e) {
            return notFound();
        }
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<>(), new java.io.ByteArrayInputStream(new byte[0]));
    }

    private static class LimitedStream extends FilterInputStream {
        private long left;
        LimitedStream(InputStream in, long limit) { super(in); left = limit; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int r = super.read();
            if (r >= 0) left--;
            return r;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int r = super.read(b, off, (int) Math.min(len, left));
            if (r > 0) left -= r;
            return r;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_DEL) {
            if (resultCode == RESULT_OK) reportDeleted(new ArrayList<>(pendingIds));
            pendingIds.clear();
            return;
        }
        if (requestCode == REQ_DEL_LEGACY) {
            if (resultCode != RESULT_OK && !delQueue.isEmpty()) delQueue.poll();
            processDeleteQueue();
            return;
        }
        if (requestCode == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
