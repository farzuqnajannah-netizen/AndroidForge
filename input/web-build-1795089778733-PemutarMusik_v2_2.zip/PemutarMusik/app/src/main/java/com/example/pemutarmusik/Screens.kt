package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(s / 60, s % 60)
}

@Composable
private fun rememberMeter(read: () -> Float): Float {
    var db by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            db = read()
            delay(100)
        }
    }
    return db
}

/** Lampu kecil berlabel: LED menyala/mati + teks. */
@Composable
fun Lamp(label: String, color: Color, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Led(color, on, diameter = 7.dp)
        Text(
            label,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            color = if (on) WA_INK else WA_LAMP_OFF,
        )
    }
}

/** Tombol ikon bulat kecil + LED di sampingnya (menyala = aktif). */
@Composable
private fun LedToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    ledColor: Color,
    on: Boolean,
    onClick: () -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        WaIconButton(icon, description, onClick, buttonSize = 26.dp, iconSize = 14.dp)
        Led(ledColor, on, diameter = 7.dp)
    }
}

// ================================================================== JENDELA UTAMA

/** Nomor versi aplikasi, mis. "v.1.8". Diambil dari versionName di app/build.gradle.kts, jadi cukup ubah di satu tempat. */
@Composable
private fun appVersionLabel(context: android.content.Context): String = remember {
    try {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        "v.${info.versionName}"
    } catch (e: Exception) {
        ""
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainWindow(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val s by AudioEngine.settings.collectAsState()
    val guardDb = rememberMeter { AudioEngine.processor.guardReductionDb }
    val limDb = rememberMeter { AudioEngine.processor.limiterReductionDb }
    val pal = Skin.p
    val mode by vm.mode.collectAsState()
    val titleH = rememberTitleBarHeight()
    val versionLabel = appVersionLabel(LocalContext.current)

    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
    val shown = drag ?: fraction

    // Jendela tetap (tanpa minimize), mengisi 1/3 tinggi kolom kiri.
    WaWindow(
        if (mode == AppMode.RADIO) "RADIO DIGITAL" else "MUSIC PLAYER", modifier = modifier, fill = true,
        contentPadding = 3.dp,
        titleHeight = titleH,
        actions = {
            SkinButton(titleH)
            ModeButtons(mode, vm::setMode, titleH)
            Text(
                "mod by aries $versionLabel",
                color = Skin.p.accentText,
                fontSize = 9.sp,
                fontFamily = MONO,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                lineHeight = 11.sp,
                style = CenteredLine,
                maxLines = 1,
                modifier = Modifier.padding(end = 8.dp),
            )
        },
    ) {
        if (mode == AppMode.RADIO) {
            RadioBody(vm, ui)
            return@WaWindow
        }
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // KIRI: layar LCD (waktu + spectrum), lampu status, bar seek
            Column(Modifier.weight(0.85f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(
                    Modifier.fillMaxWidth().weight(1f).bevel(false, WA_LCD).padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        formatTime((shown * ui.durationMs).toLong().takeIf { drag != null } ?: ui.positionMs),
                        color = WA_GREEN,
                        fontSize = 22.sp,
                        fontFamily = MONO,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterVertically),
                    )
                    SpectrumView(ui.isPlaying, Modifier.weight(1f).fillMaxHeight())
                }
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Lamp("GRD", pal.c1, guardDb > 0.5f)
                    Lamp("NSE", pal.c2, s.noiseFilter)
                    Lamp("EQ", pal.c3, s.enabled)
                    Lamp("LIM", pal.c4, limDb > 0.5f)
                }
                WaSlider(
                    value = shown,
                    onValueChange = { drag = it },
                    range = 0f..1f,
                    onDone = {
                        drag?.let { vm.seekTo((it * ui.durationMs).toLong()) }
                        drag = null
                    },
                    modifier = Modifier.fillMaxWidth().height(14.dp),
                )
            }

            // KANAN: judul berjalan, 5 tombol transport (di tengah), acak + ulang
            Column(Modifier.weight(1.3f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                Box(
                    Modifier.fillMaxWidth().height(20.dp).bevel(false, WA_LCD).padding(horizontal = 4.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    val label = if (ui.title != null) "${ui.artist} - ${ui.title}  ***  " else "MUSIC PLAYER  ***  "
                    Text(
                        label,
                        color = WA_GREEN,
                        fontSize = 11.sp,
                        fontFamily = MONO,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE),
                    )
                }

                // sebelumnya, jeda, PUTAR (tengah, lebih besar), henti, berikutnya.
                // Kelima tombol menyala biru tua OCEAN saat ditekan; tombol sesuai status tetap menyala.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
                ) {
                    WaIconButton(Icons.Filled.SkipPrevious, "Sebelumnya", vm::previous, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3)
                    WaIconButton(Icons.Filled.Pause, "Jeda", vm::pause, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3, active = ui.isPaused)
                    WaIconButton(Icons.Filled.PlayArrow, "Putar", vm::play, buttonSize = 36.dp, iconSize = 22.dp, accent = pal.c3, active = ui.isPlaying)
                    WaIconButton(Icons.Filled.Stop, "Henti", vm::stop, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3, active = ui.isStopped)
                    WaIconButton(Icons.Filled.SkipNext, "Berikutnya", vm::next, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3)
                }

                // Volume ada di knob besar panel bawah; di sini tinggal acak + ulang, di tengah.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
                ) {
                    // Acak (shuffle): LED menyala = aktif
                    LedToggle(Icons.Filled.Shuffle, "Acak", pal.c2, ui.shuffle, vm::toggleShuffle)
                    // Ulang: mati -> semua (LED cyan) -> 1 lagu (LED kuning)
                    LedToggle(
                        icon = if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        description = when (ui.repeatMode) {
                            Player.REPEAT_MODE_ONE -> "Ulang 1 lagu"
                            Player.REPEAT_MODE_ALL -> "Ulang semua"
                            else -> "Ulang mati"
                        },
                        ledColor = if (ui.repeatMode == Player.REPEAT_MODE_ONE) pal.c4 else pal.c1,
                        on = ui.repeatMode != Player.REPEAT_MODE_OFF,
                        onClick = vm::toggleRepeat,
                    )
                }
            }
        }
    }
}

// ================================================================== EQUALIZER 10 BAND + PREAMP

private val FREQ_LABELS = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

@Composable
private fun EqColumn(
    label: String,
    value: Float,
    enabled: Boolean,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
        WaSlider(
            value = value,
            onValueChange = onChange,
            range = -EqAudioProcessor.MAX_GAIN_DB..EqAudioProcessor.MAX_GAIN_DB,
            vertical = true,
            centered = true,
            enabled = enabled,
            thumb = 10.dp,
            modifier = Modifier.width(28.dp).weight(1f),
        )
        Text(label, color = WA_TEXT, fontSize = 8.sp, lineHeight = 9.sp, fontFamily = MONO, maxLines = 1)
    }
}

@Composable
fun EqWindow(modifier: Modifier = Modifier) {
    val s by AudioEngine.settings.collectAsState()
    WaWindow("EQUALIZER 10 BAND", modifier = modifier, fill = true, contentPadding = 3.dp) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // kiri: ON/OFF equalizer + noise filter, lalu bass boost, power amp, preamp
            Column(Modifier.width(146.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                Row(
                    Modifier.fillMaxWidth().height(22.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    WaButton(if (s.enabled) "ON" else "OFF", { AudioEngine.update { it.copy(enabled = !it.enabled) } }, Modifier.weight(1f), active = s.enabled)
                    Led(Skin.p.c3, s.enabled)
                    WaButton("NOISE", { AudioEngine.update { it.copy(noiseFilter = !it.noiseFilter) } }, Modifier.weight(1f), active = s.noiseFilter)
                    Led(Skin.p.c2, s.noiseFilter)
                }
                ParamRow("BASS BOOST") { m ->
                    WaSlider(s.bassBoost, { v -> AudioEngine.update { it.copy(bassBoost = v) } }, 0f..1f, m)
                }
                ParamRow("POWER AMP") { m ->
                    WaSlider(s.ampDb, { v -> AudioEngine.update { it.copy(ampDb = (v * 2f).roundToInt() / 2f) } }, 0f..12f, m)
                }
                ParamRow("PREAMP") { m ->
                    WaSlider(
                        s.preampDb,
                        { v -> AudioEngine.update { it.copy(preampDb = (v * 2f).roundToInt() / 2f) } },
                        -EqAudioProcessor.MAX_GAIN_DB..EqAudioProcessor.MAX_GAIN_DB,
                        m,
                        centered = true,
                    )
                }
            }
            // kanan: 10 slider band mengisi sisa lebar dan tinggi
            Row(Modifier.weight(1f).fillMaxHeight().bevel(false, Skin.p.eqBg).padding(vertical = 1.dp, horizontal = 2.dp)) {
                for (i in 0 until EqAudioProcessor.BAND_COUNT) {
                    EqColumn(
                        FREQ_LABELS[i], s.gains[i], s.enabled,
                        { v ->
                            AudioEngine.update { st ->
                                st.copy(gains = st.gains.toMutableList().also { it[i] = (v * 2f).roundToInt() / 2f })
                            }
                        },
                        Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

// ================================================================== PARAMETER (dipakai panel equalizer)

@Composable
private fun ParamRow(label: String, content: @Composable (Modifier) -> Unit) {
    Row(Modifier.fillMaxWidth().height(22.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            color = WA_TEXT,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.width(54.dp),
        )
        content(Modifier.weight(1f).height(16.dp))
    }
}
