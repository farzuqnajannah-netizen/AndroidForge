package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.SpectrumAnalyzer
import android.content.Context
import kotlin.math.max

// ------------------------------------------------------------------ skin (tema warna): OCEAN dan EMBER

val MONO = FontFamily.Monospace

// Nama-nama lama dipertahankan, tetapi isinya sekarang mengikuti skin yang sedang dipakai.
val WA_DESK: Color get() = Skin.p.desk                 // latar aplikasi
val WA_SILVER_HI: Color get() = Skin.p.silverHi        // logam terang (atas)
val WA_SILVER_LO: Color get() = Skin.p.silverLo        // logam gelap (bawah)
val WA_PANEL: Color get() = Skin.p.panel               // penanda panel logam (dipakai bevel)
val WA_BORDER: Color get() = Skin.p.border
val WA_HI: Color get() = Skin.p.hi
val WA_LO: Color get() = Skin.p.lo
val WA_INK: Color get() = Skin.p.ink                   // teks di atas panel logam
val WA_TEXT: Color get() = Skin.p.ink
val WA_LCD: Color get() = Skin.p.lcd                   // layar LCD / playlist
val WA_LCD_DARK: Color get() = Skin.p.lcdDark
val WA_GREEN: Color get() = Skin.p.lcdText             // teks terang di layar (nama lama dipertahankan)
val WA_GREEN_DIM: Color get() = Skin.p.lcdTextDim      // teks redup di layar
val WA_LAMP_ON: Color get() = Skin.p.lampOn
val WA_LAMP_OFF: Color get() = Skin.p.lampOff
val WA_BLUE: Color get() = Skin.p.active               // tombol aktif
val WA_GROOVE: Color get() = Skin.p.groove
val WA_SEL: Color get() = Skin.p.sel                   // baris playlist terpilih

class LedPalette(
    val name: String,
    // lampu LED / aksen
    val c1: Color, val c2: Color, val c3: Color, val c4: Color,
    val specLow: Color, val specHigh: Color,
    // logam, tepi, teks
    val desk: Color, val silverHi: Color, val silverLo: Color, val panel: Color,
    val border: Color, val hi: Color, val lo: Color, val ink: Color,
    // layar
    val lcd: Color, val lcdDark: Color, val lcdText: Color, val lcdTextDim: Color,
    val lampOn: Color, val lampOff: Color, val active: Color, val groove: Color, val sel: Color,
    // baris judul + tombol
    val titleTop: Color, val titleBot: Color, val titleText: Color, val stripe: Color,
    val accentTop: Color, val accentBot: Color, val minTop: Color, val minBot: Color,
    val iconInk: Color, val accentText: Color, val ledOff: Color,
    // gagang slider
    val thumbHi: Color, val thumbLo: Color, val thumbMark: Color, val eqBg: Color,
    // badan radio + knob
    val bodyTop: Color, val bodyMid: Color, val bodyBot: Color, val bodyBorder: Color,
    val dispTop: Color, val dispBot: Color, val dispBorder: Color,
    val radioText: Color, val radioTextDim: Color, val radioAccent: Color, val radioScaleOff: Color,
    val knobHi: Color, val knobLo: Color,
    // dialog + menu
    val dialog: Color, val menu: Color,
)

/** OCEAN: logam perak + LCD biru (skin asli). */
private val OCEAN_SKIN = LedPalette(
    name = "OCEAN",
    c1 = Color(0xFF35E0FF), c2 = Color(0xFF4DFF9A), c3 = Color(0xFF4D8DFF), c4 = Color(0xFFFFC24D),
    specLow = Color(0xFF5E9BFF), specHigh = Color(0xFFFFFFFF),
    desk = Color(0xFF0A1530), silverHi = Color(0xFFE6EAF2), silverLo = Color(0xFF9AA4BA), panel = Color(0xFFB5BDCC),
    border = Color(0xFF16244A), hi = Color(0xFFF4F7FC), lo = Color(0xFF16244A), ink = Color(0xFF1B2A55),
    lcd = Color(0xFF173E86), lcdDark = Color(0xFF0F2C66), lcdText = Color(0xFFEAF2FF), lcdTextDim = Color(0xFF6F8CC8),
    lampOn = Color(0xFF1F5BE0), lampOff = Color(0xFF7B879F), active = Color(0xFF2C5FC8), groove = Color(0xFF26314F), sel = Color(0xFF6F8FD0),
    titleTop = Color(0xFF3F61A8), titleBot = Color(0xFF1A2A5E), titleText = Color(0xFFC9D3EA), stripe = Color(0x66C9D3EA),
    accentTop = Color(0xFF5B93F0), accentBot = Color(0xFF2C5FC8), minTop = Color(0xFF7FEBFF), minBot = Color(0xFF1C86FF),
    iconInk = Color(0xFF0B1330), accentText = Color(0xFF7FEBFF), ledOff = Color(0xFF152046),
    thumbHi = Color(0xFFF1F4FA), thumbLo = Color(0xFFA9B3C9), thumbMark = Skin.p.thumbMark, eqBg = Color(0xFFC2C9D9),
    bodyTop = Color(0xFF2A56B0), bodyMid = Color(0xFF16356F), bodyBot = Color(0xFF0E2250), bodyBorder = Color(0xFF9AA4BA),
    dispTop = Color(0xFF071A4A), dispBot = Color(0xFF0B2159), dispBorder = Color(0xFF6F8FD0),
    radioText = Color(0xFFD6E2FA), radioTextDim = Color(0xFF7F9BD6), radioAccent = Color(0xFF35E0FF), radioScaleOff = Color(0xFF3F5A9A),
    knobHi = Color(0xFF8C9BC0), knobLo = Color(0xFF2A3A68),
    dialog = Color(0xFF1B2F66), menu = Color(0xFFD5DBE8),
)

/** EMBER: dominan hitam dengan oranye tua yang bergradasi. */
private val EMBER_SKIN = LedPalette(
    name = "EMBER",
    c1 = Color(0xFFFFA040), c2 = Color(0xFFFFD04D), c3 = Color(0xFFFF6A00), c4 = Color(0xFFFF3B1F),
    specLow = Color(0xFFB84A00), specHigh = Color(0xFFFFE0A0),
    desk = Color(0xFF050403), silverHi = Color(0xFF454240), silverLo = Color(0xFF121110), panel = Color(0xFF2A2725),
    border = Color(0xFF000000), hi = Color(0xFF8A8480), lo = Color(0xFF000000), ink = Color(0xFFFFB877),
    lcd = Color(0xFF1C0F07), lcdDark = Color(0xFF0F0704), lcdText = Color(0xFFFFD9A8), lcdTextDim = Color(0xFFB8733A),
    lampOn = Color(0xFFFF7A1A), lampOff = Color(0xFF5C4B3F), active = Color(0xFFD9560A), groove = Color(0xFF140B05), sel = Color(0xFF8F3F0B),
    titleTop = Color(0xFFD2600E), titleBot = Color(0xFF3A1706), titleText = Color(0xFFFFE9D0), stripe = Color(0x66FFD9A8),
    accentTop = Color(0xFFFF9A3D), accentBot = Color(0xFFC24A06), minTop = Color(0xFFFFB45E), minBot = Color(0xFFD2600E),
    iconInk = Color(0xFFFFC38A), accentText = Color(0xFFFFB45E), ledOff = Color(0xFF2A1608),
    thumbHi = Color(0xFFFFAA5C), thumbLo = Color(0xFFB5500A), thumbMark = Color(0xFF4A1E04), eqBg = Color(0xFF0C0704),
    bodyTop = Color(0xFF8F3F0B), bodyMid = Color(0xFF3F1A07), bodyBot = Color(0xFF0E0603), bodyBorder = Color(0xFFB5733A),
    dispTop = Color(0xFF050302), dispBot = Color(0xFF1A0D05), dispBorder = Color(0xFFB5551A),
    radioText = Color(0xFFFFD9A8), radioTextDim = Color(0xFFB8733A), radioAccent = Color(0xFFFF9A2E), radioScaleOff = Color(0xFF5C3A20),
    knobHi = Color(0xFFC98A5A), knobLo = Color(0xFF3A1A08),
    dialog = Color(0xFF241208), menu = Color(0xFF3A2414),
)

/** Skin aktif disimpan di SharedPreferences; berupa state Compose, jadi tampilan langsung berganti saat skin diganti. */
object Skin {
    val palettes = listOf(OCEAN_SKIN, EMBER_SKIN)
    private var index by mutableIntStateOf(0)
    val p: LedPalette get() = palettes[index]

    fun init(context: Context) {
        index = try {
            context.applicationContext.getSharedPreferences("skin_v2", Context.MODE_PRIVATE)
                .getInt("idx", 0).coerceIn(0, palettes.size - 1)
        } catch (e: Exception) {
            0
        }
    }

    fun next(context: Context) {
        index = (index + 1) % palettes.size
        try {
            context.applicationContext.getSharedPreferences("skin_v2", Context.MODE_PRIVATE)
                .edit().putInt("idx", index).apply()
        } catch (e: Exception) {
            // gagal menyimpan: skin tetap berganti untuk sesi ini
        }
    }
}

/** Lampu LED bulat dengan efek cahaya (glow) saat menyala. */
@Composable
fun Led(color: Color, on: Boolean, modifier: Modifier = Modifier, diameter: Dp = 9.dp) {
    Canvas(modifier.size(diameter + 6.dp)) {
        val c = center
        val r = diameter.toPx() / 2f
        if (on) {
            drawCircle(
                Brush.radialGradient(listOf(color.copy(alpha = 0.55f), Color.Transparent), c, r * 2.3f),
                radius = r * 2.3f,
                center = c,
            )
            drawCircle(
                Brush.radialGradient(listOf(Color.White, color, color.copy(alpha = 0.75f)), c - Offset(r * 0.25f, r * 0.25f), r * 1.2f),
                radius = r,
                center = c,
            )
        } else {
            drawCircle(
                Brush.radialGradient(listOf(color.copy(alpha = 0.35f), Skin.p.ledOff), c, r),
                radius = r,
                center = c,
            )
        }
        drawCircle(WA_BORDER, radius = r, center = c, style = Stroke(1.dp.toPx()))
    }
}

/** Panel logam timbul (raised) atau cekung (inset), sudut membulat, dengan sorot cahaya dari atas supaya terlihat 3D. */
fun Modifier.bevel(raised: Boolean = true, fill: Color = WA_PANEL, radius: Dp = 3.dp): Modifier = this.drawBehind {
    val p = Skin.p
    val r = CornerRadius(radius.toPx())
    val t = 1.dp.toPx()
    if (raised) {
        val top = if (fill == p.panel) p.silverHi else lerp(fill, Color.White, 0.25f)
        val bottom = if (fill == p.panel) p.silverLo else lerp(fill, Color.Black, 0.3f)
        drawRoundRect(Brush.verticalGradient(listOf(top, bottom)), cornerRadius = r)
        drawRoundRect(
            color = p.border,
            topLeft = Offset(t / 2, t / 2),
            size = Size(size.width - t, size.height - t),
            cornerRadius = r,
            style = Stroke(t),
        )
        // sorot tepi dalam: terang di atas, gelap di bawah
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xB3FFFFFF), Color(0x00FFFFFF), Color(0x40000000))),
            topLeft = Offset(t * 1.5f, t * 1.5f),
            size = Size(size.width - t * 3f, size.height - t * 3f),
            cornerRadius = r,
            style = Stroke(t),
        )
    } else {
        drawRoundRect(fill, cornerRadius = r)
        // bayangan dalam di bagian atas = efek cekung
        val sh = minOf(size.height * 0.45f, 7.dp.toPx())
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0x77000000), Color(0x00000000)), startY = 0f, endY = sh),
            size = Size(size.width, sh),
            cornerRadius = r,
        )
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0x22FFFFFF), Color(0x66FFFFFF))),
            topLeft = Offset(t / 2, t / 2),
            size = Size(size.width - t, size.height - t),
            cornerRadius = r,
            style = Stroke(t),
        )
    }
}

// ------------------------------------------------------------------ jendela

/** Teks satu baris yang tepat di tengah secara vertikal (tanpa ruang kosong ekstra di atas/bawah huruf). Pakai bersama lineHeight. */
val CenteredLine = TextStyle(
    lineHeightStyle = LineHeightStyle(
        alignment = LineHeightStyle.Alignment.Center,
        trim = LineHeightStyle.Trim.Both,
    )
)

/** Tinggi baris judul jendela yang dipakai player (kiri atas) dan playlist (kanan) supaya sama; menyesuaikan tinggi layar HP (22..30 dp). */
@Composable
fun rememberTitleBarHeight(): Dp {
    val screenH = LocalConfiguration.current.screenHeightDp
    return maxOf(22f, minOf(30f, screenH * 0.065f)).dp
}

@Composable
fun WaWindow(
    title: String,
    modifier: Modifier = Modifier,
    fill: Boolean = false,
    contentPadding: Dp = 5.dp,
    titleHeight: Dp = 17.dp,
    actions: (@Composable androidx.compose.foundation.layout.RowScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .bevel(true, WA_PANEL, 8.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(titleHeight)
                .background(Brush.verticalGradient(listOf(Skin.p.titleTop, Skin.p.titleBot)))
                .padding(start = 4.dp, end = if (actions != null) 0.dp else 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Stripes(Modifier.weight(1f))
            Text(
                title,
                color = Skin.p.titleText,
                fontSize = 10.sp,
                fontFamily = MONO,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                lineHeight = 12.sp,
                style = CenteredLine,
                modifier = Modifier.padding(horizontal = 7.dp),
            )
            Stripes(Modifier.weight(1f))
            actions?.invoke(this)
        }
        val inner = if (fill) Modifier.weight(1f) else Modifier
        Column(inner.padding(contentPadding), content = content)
    }
}

/**
 * Tombol di baris judul: minimize (biru muda, tanda "–") atau tutup (merah, tanda "×").
 * Digambar dengan garis putih tebal di atas warna solid supaya jelas terlihat; ukuran mengikuti tinggi baris judul
 * (barHeight), sehingga menyesuaikan layar HP yang berbeda.
 */
@Composable
fun WaTitleButton(close: Boolean, description: String, barHeight: Dp, onClick: () -> Unit) {
    val h = barHeight - 6.dp
    Box(
        Modifier
            .width(barHeight * 1.8f)
            .fillMaxHeight()
            .semantics { contentDescription = description }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(width = h * 1.5f, height = h)) {
            val r = CornerRadius(5.dp.toPx())
            val colors = if (close) listOf(Color(0xFFFF7A6B), Color(0xFFD62B2B)) else listOf(Skin.p.minTop, Skin.p.minBot)
            drawRoundRect(Brush.verticalGradient(colors), cornerRadius = r)
            drawRoundRect(Color(0xFF0B1330), cornerRadius = r, style = Stroke(1.5.dp.toPx()))
            drawRoundRect(Brush.verticalGradient(listOf(Color(0x99FFFFFF), Color(0x00FFFFFF))), topLeft = Offset(1.5.dp.toPx(), 1.5.dp.toPx()), size = Size(size.width - 3.dp.toPx(), size.height * 0.5f), cornerRadius = r)
            val cx = size.width / 2f
            val cy = size.height / 2f
            val a = size.height * 0.2f
            val w = 2.6.dp.toPx()
            val cap = androidx.compose.ui.graphics.StrokeCap.Round
            if (close) {
                drawLine(Color.White, Offset(cx - a, cy - a), Offset(cx + a, cy + a), w, cap)
                drawLine(Color.White, Offset(cx - a, cy + a), Offset(cx + a, cy - a), w, cap)
            } else {
                drawLine(Color.White, Offset(cx - a * 1.3f, cy), Offset(cx + a * 1.3f, cy), w, cap)
            }
        }
    }
}

/**
 * Dua tombol mode di baris judul player: [MP3] dan [RADIO], masing-masing dengan LED biru di sampingnya.
 * Tombol yang sedang aktif berwarna biru dan LED-nya menyala.
 */
@Composable
fun ModeButtons(mode: AppMode, onChange: (AppMode) -> Unit, barHeight: Dp) {
    val h = barHeight - 8.dp
    val shape = RoundedCornerShape(h / 2)
    Row(
        Modifier.fillMaxHeight().padding(end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        listOf(AppMode.MP3 to "MP3", AppMode.RADIO to "RADIO").forEach { (m, label) ->
            val on = mode == m
            Row(
                Modifier
                    .fillMaxHeight()
                    .semantics { contentDescription = "Mode $label" }
                    .clickable { onChange(m) },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .height(h)
                        .clip(shape)
                        .background(
                            Brush.verticalGradient(
                                if (on) listOf(Skin.p.accentTop, Skin.p.accentBot)
                                else listOf(WA_SILVER_HI, WA_SILVER_LO)
                            )
                        )
                        .border(1.dp, WA_BORDER, shape)
                        .padding(horizontal = 9.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label,
                        color = if (on) Color.White else WA_INK,
                        fontSize = 9.sp,
                        fontFamily = MONO,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 10.sp,
                        style = CenteredLine,
                    )
                }
                Spacer(Modifier.width(3.dp))
                Led(Skin.p.c3, on, diameter = 7.dp)
            }
        }
    }
}

/** Tombol ganti skin (OCEAN <-> EMBER) di baris judul player. Pilihan skin disimpan. */
@Composable
fun SkinButton(barHeight: Dp) {
    val context = LocalContext.current
    val h = barHeight - 8.dp
    val shape = RoundedCornerShape(h / 2)
    Row(
        Modifier.fillMaxHeight().padding(end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .height(h)
                .semantics { contentDescription = "Ganti skin" }
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Skin.p.accentTop, Skin.p.accentBot)))
                .border(1.dp, WA_BORDER, shape)
                .clickable { Skin.next(context) }
                .padding(horizontal = 9.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "SKIN",
                color = Color.White,
                fontSize = 9.sp,
                fontFamily = MONO,
                fontWeight = FontWeight.Bold,
                lineHeight = 10.sp,
                style = CenteredLine,
            )
        }
    }
}

@Composable
private fun Stripes(modifier: Modifier) {
    Canvas(modifier.height(11.dp)) {
        for (y in listOf(2.5.dp, 5.5.dp, 8.5.dp)) {
            val py = y.toPx()
            drawLine(Skin.p.stripe, Offset(0f, py), Offset(size.width, py), strokeWidth = 1.dp.toPx())
        }
    }
}

// ------------------------------------------------------------------ tombol

/** Tombol pil: biru + teks putih saat aktif, perak + teks biru tua saat tidak. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WaButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    onLongClick: (() -> Unit)? = null,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val lit = active || pressed
    Box(
        modifier
            .height(22.dp)
            .bevel(!lit, if (pressed) Skin.p.c3 else if (active) WA_BLUE else WA_PANEL, 11.dp)
            .combinedClickable(interactionSource = source, indication = null, onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontSize = 9.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            color = if (lit) Color.White else WA_INK,
        )
    }
}

/** Tombol transport bulat perak dengan ikon hitam. */
@Composable
fun WaIconButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    buttonSize: Dp = 34.dp,
    iconSize: Dp = 18.dp,
    accent: Color = Skin.p.c3,
    active: Boolean = false,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val c = accent
    val lit = pressed || active
    val fill = if (lit) listOf(lerp(c, Color.White, 0.45f), c, lerp(c, Color.Black, 0.35f))
    else listOf(WA_SILVER_HI, lerp(WA_SILVER_HI, WA_SILVER_LO, 0.5f), WA_SILVER_LO)
    Box(
        modifier
            .size(buttonSize)
            .drawBehind {
                // bayangan jatuh di bawah tombol
                drawCircle(Color(0x66000000), size.minDimension / 2f, center + Offset(0f, 1.6.dp.toPx()))
            }
            .background(Brush.verticalGradient(fill), CircleShape)
            .border(1.5.dp, Brush.verticalGradient(listOf(Skin.p.hi, WA_BORDER)), CircleShape)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = description,
            tint = if (lit) Color.White else Skin.p.iconInk,
            modifier = Modifier.size(iconSize),
        )
    }
}

// ------------------------------------------------------------------ slider

/**
 * Slider gaya perak: alur gelap, gagang perak membulat.
 * centered = true: isi warna dari titik tengah (dipakai untuk EQ +/- dB).
 */
@Composable
fun WaSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    vertical: Boolean = false,
    centered: Boolean = false,
    enabled: Boolean = true,
    onDone: () -> Unit = {},
    thumb: Dp = 14.dp,
) {
    val change by rememberUpdatedState(onValueChange)
    val done by rememberUpdatedState(onDone)

    Canvas(
        modifier.pointerInput(enabled, vertical, range) {
            if (!enabled) return@pointerInput
            val pad = thumb.toPx() / 2f
            fun update(p: Offset) {
                val len = (if (vertical) size.height else size.width).toFloat()
                val pos = if (vertical) p.y else p.x
                var frac = ((pos - pad) / max(len - 2 * pad, 1f)).coerceIn(0f, 1f)
                if (vertical) frac = 1f - frac
                change(range.start + frac * (range.endInclusive - range.start))
            }
            awaitEachGesture {
                val down = awaitFirstDown()
                update(down.position)
                down.consume()
                drag(down.id) {
                    update(it.position)
                    it.consume()
                }
                done()
            }
        }
    ) {
        val pad = thumb.toPx() / 2f
        val grooveW = 5.dp.toPx()
        val frac = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
        val len = if (vertical) size.height else size.width
        val cross = if (vertical) size.width else size.height
        val track = len - 2 * pad
        val pos = pad + (if (vertical) (1f - frac) else frac) * track
        val centerPos = pad + track / 2f
        val gTop = (cross - grooveW) / 2f
        val rad = CornerRadius(grooveW / 2f)

        // alur gelap (cekung: tepi bawah/kanan diberi garis terang tipis)
        if (vertical) {
            drawRoundRect(Color(0x33FFFFFF), Offset(gTop + 1.dp.toPx(), pad + 1.dp.toPx()), Size(grooveW, track), rad)
            drawRoundRect(WA_GROOVE, Offset(gTop, pad), Size(grooveW, track), rad)
        } else {
            drawRoundRect(Color(0x33FFFFFF), Offset(pad + 1.dp.toPx(), gTop + 1.dp.toPx()), Size(track, grooveW), rad)
            drawRoundRect(WA_GROOVE, Offset(pad, gTop), Size(track, grooveW), rad)
        }

        // isi warna (biru; mendekati ujung berubah kuning/merah sebagai peringatan clipping)
        val a = if (centered) centerPos else (if (vertical) pad + track else pad)
        val lo = minOf(a, pos)
        val hi = maxOf(a, pos)
        val dev = if (centered) kotlin.math.abs(frac - 0.5f) * 2f else frac * 0.6f
        var fillColor = if (!enabled) Color(0xFF3A4766) else Skin.p.c3
        if (enabled && dev > 0.6f) fillColor = lerp(fillColor, Color(0xFFFFB020), ((dev - 0.6f) * 2.5f).coerceIn(0f, 1f))
        if (enabled && dev > 0.85f) fillColor = lerp(fillColor, Color(0xFFFF4020), ((dev - 0.85f) * 6.6f).coerceIn(0f, 1f))
        if (vertical) drawRoundRect(fillColor, Offset(gTop, lo), Size(grooveW, hi - lo), rad)
        else drawRoundRect(fillColor, Offset(lo, gTop), Size(hi - lo, grooveW), rad)

        // garis tengah
        if (centered) {
            val tick = Color(0x99FFFFFF)
            if (vertical) drawLine(tick, Offset(0f, centerPos), Offset(size.width, centerPos), 1.dp.toPx())
            else drawLine(tick, Offset(centerPos, 0f), Offset(centerPos, size.height), 1.dp.toPx())
        }

        // gagang perak membulat
        val tw = thumb.toPx()
        val topLeft = if (vertical) Offset(1.dp.toPx(), pos - tw / 2f) else Offset(pos - tw / 2f, 1.dp.toPx())
        val sz = if (vertical) Size(size.width - 2.dp.toPx(), tw) else Size(tw, size.height - 2.dp.toPx())
        val corner = CornerRadius(4.dp.toPx())
        val body = if (enabled) listOf(Skin.p.thumbHi, lerp(Skin.p.thumbHi, Skin.p.thumbLo, 0.55f), Skin.p.thumbLo)
        else listOf(Color(0xFF8D97AB), Color(0xFF778098), Color(0xFF677189))
        // bayangan gagang
        drawRoundRect(Color(0x66000000), topLeft + Offset(0f, 1.5.dp.toPx()), sz, corner)
        drawRoundRect(Brush.verticalGradient(body, startY = topLeft.y, endY = topLeft.y + sz.height), topLeft, sz, corner)
        // kilau di sisi atas gagang
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0x88FFFFFF), Color(0x00FFFFFF)), startY = topLeft.y, endY = topLeft.y + sz.height * 0.55f),
            topLeft + Offset(1.dp.toPx(), 1.dp.toPx()), Size(sz.width - 2.dp.toPx(), sz.height * 0.5f), corner,
        )
        drawRoundRect(WA_BORDER, topLeft, sz, corner, style = Stroke(1.dp.toPx()))
        if (vertical) {
            drawLine(Skin.p.thumbMark, Offset(topLeft.x + 3.dp.toPx(), pos), Offset(topLeft.x + sz.width - 3.dp.toPx(), pos), 1.dp.toPx())
        } else {
            drawLine(Skin.p.thumbMark, Offset(pos, topLeft.y + 3.dp.toPx()), Offset(pos, topLeft.y + sz.height - 3.dp.toPx()), 1.dp.toPx())
        }
    }
}

// ------------------------------------------------------------------ spectrum analyzer

@Composable
fun SpectrumView(playing: Boolean, modifier: Modifier = Modifier) {
    val analyzer = remember { SpectrumAnalyzer(AudioEngine.processor) }
    val bars0 = SpectrumAnalyzer.BARS
    var bars by remember { mutableStateOf(FloatArray(bars0)) }
    val peaks = remember { FloatArray(bars0) }
    val playingNow by rememberUpdatedState(playing)

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 30_000_000L) continue
            last = now
            val old = bars
            val idle = !playingNow && old.all { it <= 0f } && peaks.all { it <= 0f }
            if (idle) continue
            val fresh = if (playingNow) analyzer.compute() else FloatArray(bars0)
            val next = FloatArray(bars0) { i -> max(fresh[i], old[i] - 0.07f) }
            for (i in 0 until bars0) peaks[i] = max(next[i], max(peaks[i] - 0.015f, 0f))
            bars = next
        }
    }

    Canvas(modifier) {
        val b = bars
        val n = b.size
        val gap = 1.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        val segs = 14
        val segH = size.height / segs
        for (i in 0 until n) {
            val x = i * (w + gap)
            val lit = (b[i] * segs).toInt()
            for (s in 0 until lit) {
                val t = s / (segs - 1f)
                val color = lerp(Skin.p.specLow, Skin.p.specHigh, t)
                val y = size.height - (s + 1) * segH
                drawRect(color, Offset(x, y + 0.5f), Size(w, segH - 1f))
            }
            val pk = (peaks[i] * segs).toInt().coerceIn(0, segs - 1)
            if (peaks[i] > 0.02f) {
                val y = size.height - (pk + 1) * segH
                drawRect(Skin.p.specHigh, Offset(x, y + 0.5f), Size(w, segH - 1f))
            }
        }
    }
}
