CLASSIC AMPLIFIER - proyek APK (Capacitor)

Kebutuhan: Node.js 20+, Android Studio (sudah termasuk Android SDK dan JDK).

Langkah build:
1. Buka terminal di folder ini, lalu jalankan:
     npm install
     npx cap add android
     npx cap sync android
2. Buka di Android Studio:
     npx cap open android
3. Tunggu Gradle selesai, lalu pilih menu:
     Build > Build Bundle(s) / APK(s) > Build APK(s)
   File APK ada di: android/app/build/outputs/apk/debug/app-debug.apk

Catatan:
- Aplikasi ada di www/index.html. Jika diubah, jalankan "npx cap sync android" lagi.
- capacitor.config.json memakai androidScheme "http" dan cleartext true,
  supaya alamat radio http:// (misalnya Sananta FM) tidak diblokir.
- Perlu internet untuk radio dan font Google. Tanpa internet, font memakai cadangan.
- Musik berhenti saat layar mati atau aplikasi ditutup (batasan WebView).
- Untuk APK rilis (Play Store) perlu tanda tangan (keystore): Build > Generate Signed Bundle / APK.
