package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ================================================================== LEVEL KIRI / KANAN

/** Level linear (0..1) -> posisi 0..1 pada skala -30 dB .. +3 dB (0 dB berada di sekitar 91%). */
private fun levelToFrac(lin: Float): Float {
    if (lin <= 0.00002f) return 0f
    return ((20f * log10(lin) + 30f) / 33f).coerceIn(0f, 1f)
}

/** Posisi pada skala untuk label dB (-30..+3). */
private fun dbToFrac(db: Float): Float = ((db + 30f) / 33f).coerceIn(0f, 1f)

/**
 * Level kiri/kanan (0..1) yang sudah dihaluskan: naik cepat, turun pelan.
 * Level dikalikan volume pemutar supaya meter ikut bergerak saat knob volume diputar.
 */
@Composable
private fun rememberStereoLevels(playing: Boolean, volume: Float): Pair<Float, Float> {
    val playingNow by rememberUpdatedState(playing)
    val volumeNow by rememberUpdatedState(volume)
    var levels by remember { mutableStateOf(0f to 0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 33_000_000L) continue
            last = now
            val (oldL, oldR) = levels
            if (!playingNow && oldL <= 0.002f && oldR <= 0.002f) {
                if (oldL != 0f || oldR != 0f) levels = 0f to 0f
                continue
            }
            val pr = AudioEngine.processor
            val targetL = if (playingNow) levelToFrac(pr.levelL * volumeNow) else 0f
            val targetR = if (playingNow) levelToFrac(pr.levelR * volumeNow) else 0f
            val newL = oldL + (targetL - oldL) * (if (targetL > oldL) 0.6f else 0.12f)
            val newR = oldR + (targetR - oldR) * (if (targetR > oldR) 0.6f else 0.12f)
            levels = newL to newR
        }
    }
    return levels
}

// ================================================================== VU METER KLASIK (muka krem, lampu hangat)

private val VuInk = Color(0xFF3A2A12)

@Composable
private fun VuMeter(label: String, frac: Float, modifier: Modifier = Modifier) {
    val measurer = rememberTextMeasurer()
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val bz = 3.dp.toPx()
        val fx = bz
        val fy = bz
        val fw = w - bz * 2f
        val fh = h - bz * 2f
        val faceCorner = CornerRadius(4.dp.toPx())

        // bingkai logam (timbul)
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFF8A8A90), Color(0xFF26262A), Color(0xFF55555A))),
            cornerRadius = CornerRadius(6.dp.toPx()),
        )
        drawRoundRect(
            Color(0xFF000000), cornerRadius = CornerRadius(6.dp.toPx()), style = Stroke(1.dp.toPx()),
        )

        // geometri skala
        val maxDeg = 48f
        val pivot = Offset(w / 2f, fy + fh + 2.dp.toPx())
        val rsX = (w / 2f - bz - 8.dp.toPx()) / sin(Math.toRadians(maxDeg.toDouble())).toFloat()
        val rsY = pivot.y - fy - 15.dp.toPx()
        val rs = min(rsX, rsY)
        fun pt(deg: Float, rad: Float): Offset {
            val a = Math.toRadians(deg.toDouble())
            return Offset(pivot.x + rad * sin(a).toFloat(), pivot.y - rad * cos(a).toFloat())
        }
        fun degOf(f: Float) = -maxDeg + f * maxDeg * 2f

        clipRect(fx, fy, fx + fw, fy + fh) {
            // muka meter krem + cahaya lampu hangat dari atas
            drawRoundRect(
                Brush.radialGradient(
                    listOf(Color(0xFFFFF4C8), Color(0xFFF7DC8E), Color(0xFFC9953C)),
                    center = Offset(w / 2f, fy + fh * 0.30f),
                    radius = w * 0.65f,
                ),
                Offset(fx, fy), Size(fw, fh), faceCorner,
            )
            // dua lampu kecil di sudut atas
            for (side in 0..1) {
                val cx = if (side == 0) fx + 8.dp.toPx() else fx + fw - 8.dp.toPx()
                val cy = fy + 7.dp.toPx()
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xCCFFE08A), Color(0x00FFE08A)), Offset(cx, cy), 20.dp.toPx()),
                    20.dp.toPx(), Offset(cx, cy),
                )
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xFFFFFBE0), Color(0xFFFFB629)), Offset(cx, cy), 3.dp.toPx()),
                    3.dp.toPx(), Offset(cx, cy),
                )
            }

            // busur skala + zona merah (0 .. +3 dB)
            val arcTL = Offset(pivot.x - rs, pivot.y - rs)
            val arcSz = Size(rs * 2f, rs * 2f)
            drawArc(VuInk, -90f - maxDeg, maxDeg * 2f, false, arcTL, arcSz, style = Stroke(1.dp.toPx()))
            val redStart = dbToFrac(0f)
            val rr = rs - 2.5.dp.toPx()
            drawArc(
                Color(0xFFC8321E),
                -90f + degOf(redStart), maxDeg * 2f * (1f - redStart), false,
                Offset(pivot.x - rr, pivot.y - rr), Size(rr * 2f, rr * 2f),
                style = Stroke(4.dp.toPx()),
            )
            // garis skala kecil + besar
            for (i in 0..33) {
                val f = i / 33f
                val major = i % 5 == 0
                val red = f >= redStart - 0.001f
                drawLine(
                    if (red) Color(0xFFC8321E) else VuInk,
                    pt(degOf(f), rs * (if (major) 0.84f else 0.91f)), pt(degOf(f), rs),
                    if (major) 1.2.dp.toPx() else 0.7.dp.toPx(),
                )
            }
            // angka skala
            val numStyle = TextStyle(color = VuInk, fontSize = 7.sp, fontFamily = MONO, fontWeight = FontWeight.Bold)
            for ((db, text) in listOf(-20f to "20", -10f to "10", -5f to "5", 0f to "0", 3f to "+3")) {
                val res = measurer.measure(text, numStyle)
                val pos = pt(degOf(dbToFrac(db)), rs * 0.70f)
                drawText(res, topLeft = Offset(pos.x - res.size.width / 2f, pos.y - res.size.height / 2f))
            }
            val vuRes = measurer.measure("VU", TextStyle(color = VuInk, fontSize = 11.sp, fontFamily = MONO, fontWeight = FontWeight.Bold))
            drawText(vuRes, topLeft = Offset(w / 2f - vuRes.size.width / 2f, pivot.y - rs * 0.40f - vuRes.size.height / 2f))
            val chRes = measurer.measure(label, TextStyle(color = VuInk, fontSize = 9.sp, fontFamily = MONO, fontWeight = FontWeight.Bold))
            drawText(chRes, topLeft = Offset(fx + 6.dp.toPx(), fy + fh - chRes.size.height - 3.dp.toPx()))

            // jarum: bayangan lalu jarum hitam tipis
            val needleDeg = degOf(frac.coerceIn(0f, 1f))
            val tip = pt(needleDeg, rs * 1.02f)
            drawLine(Color(0x55000000), pivot + Offset(1.5.dp.toPx(), 1.5.dp.toPx()), tip + Offset(1.5.dp.toPx(), 1.5.dp.toPx()), 1.4.dp.toPx(), StrokeCap.Round)
            drawLine(Color(0xFF141414), pivot, tip, 1.4.dp.toPx(), StrokeCap.Round)
            // tutup poros (setengah lingkaran logam di dasar muka)
            drawCircle(
                Brush.verticalGradient(listOf(Color(0xFF6A6A70), Color(0xFF111113)), startY = pivot.y - 11.dp.toPx(), endY = pivot.y + 11.dp.toPx()),
                11.dp.toPx(), pivot,
            )

            // bayangan dalam di tepi atas (kaca cekung) + pantulan kaca
            drawRect(
                Brush.verticalGradient(listOf(Color(0x66000000), Color(0x00000000)), startY = fy, endY = fy + 7.dp.toPx()),
                Offset(fx, fy), Size(fw, 7.dp.toPx()),
            )
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0x55FFFFFF), Color(0x08FFFFFF)), startY = fy, endY = fy + fh * 0.5f),
                Offset(fx + 1.dp.toPx(), fy + 1.dp.toPx()), Size(fw - 2.dp.toPx(), fh * 0.45f), faceCorner,
            )
        }
        // garis tepi muka (cekung)
        drawRoundRect(Color(0xAA000000), Offset(fx, fy), Size(fw, fh), faceCorner, style = Stroke(1.dp.toPx()))
    }
}

// ================================================================== LED METER MODERN

private fun meterColor(t: Float): Color = when {
    t < 0.60f -> lerp(Color(0xFF22E87A), Color(0xFF9BF03C), t / 0.60f)
    t < 0.85f -> lerp(Color(0xFFFFD23D), Color(0xFFFF8A1F), (t - 0.60f) / 0.25f)
    else -> lerp(Color(0xFFFF5A2A), Color(0xFFFF1F3D), ((t - 0.85f) / 0.15f).coerceIn(0f, 1f))
}

/**
 * LED meter datar modern: segmen bulat bergradasi, cahaya (glow), kilau kaca, dan penanda puncak (peak hold).
 * Mulai dari tengah (dekat knob volume) lalu menyala ke luar:
 * [growLeft] = true -> ke kiri (kanal L), false -> ke kanan (kanal R). Jadi L dan R bergerak berlawanan.
 */
@Composable
private fun LedMeter(frac: Float, growLeft: Boolean, modifier: Modifier = Modifier) {
    var peak by remember { mutableFloatStateOf(0f) }
    val fracNow by rememberUpdatedState(frac)
    LaunchedEffect(Unit) {
        while (true) {
            delay(40)
            peak = max(fracNow, peak - 0.02f)
        }
    }
    Canvas(modifier) {
        val segs = 24
        val g = 1.6.dp.toPx()
        val pad = 3.dp.toPx()
        val segW = (size.width - pad * 2f - g * (segs - 1)) / segs
        val top = pad
        val hh = size.height - pad * 2f
        val lit = (frac.coerceIn(0f, 1f) * segs + 0.5f).toInt()
        val pk = (peak * segs).toInt().coerceIn(0, segs - 1)
        val corner = CornerRadius(size.height / 2f)

        // dasar kaca gelap
        drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF03060F), Color(0xFF121B36))), cornerRadius = corner)
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0x22FFFFFF), Color(0x66FFFFFF))),
            cornerRadius = corner, style = Stroke(1.dp.toPx()),
        )

        for (i in 0 until segs) {
            val x = if (growLeft) size.width - pad - (i + 1) * segW - i * g else pad + i * (segW + g)
            val c = meterColor(i / (segs - 1f))
            val cr = CornerRadius(segW * 0.45f)
            if (i < lit) {
                // cahaya di sekeliling segmen
                drawRoundRect(
                    c.copy(alpha = 0.30f),
                    Offset(x - 1.2.dp.toPx(), top - 1.2.dp.toPx()), Size(segW + 2.4.dp.toPx(), hh + 2.4.dp.toPx()), cr,
                )
                drawRoundRect(
                    Brush.verticalGradient(
                        listOf(lerp(c, Color.White, 0.55f), c, lerp(c, Color.Black, 0.35f)),
                        startY = top, endY = top + hh,
                    ),
                    Offset(x, top), Size(segW, hh), cr,
                )
            } else {
                drawRoundRect(c.copy(alpha = 0.14f), Offset(x, top), Size(segW, hh), cr)
                if (i == pk && peak > 0.03f) {
                    drawRoundRect(lerp(c, Color.White, 0.6f), Offset(x, top), Size(segW, hh), cr)
                }
            }
        }
        // kilau kaca di separuh atas
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0x33FFFFFF), Color(0x00FFFFFF)), startY = 0f, endY = size.height * 0.5f),
            Offset(2.dp.toPx(), 1.dp.toPx()), Size(size.width - 4.dp.toPx(), size.height * 0.45f), corner,
        )
    }
}

// ================================================================== KNOB VOLUME 3D

/**
 * Knob volume besar bergaya logam 3D: cincin titik LED yang menyala sampai posisi knob, badan logam bergerigi
 * dengan kilau berputar, tutup cekung dengan sorot cahaya, dan penunjuk bercahaya.
 * Putar melingkar searah jarum jam = volume naik. Ketuk = bisu.
 */
@Composable
private fun VolumeKnob(
    frac: Float,
    label: String,
    knobSize: Dp,
    onTurn: (Float) -> Unit,
    onTap: () -> Unit,
) {
    val turn by rememberUpdatedState(onTurn)
    val tap by rememberUpdatedState(onTap)
    val sweep = 270f * PI.toFloat() / 180f

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier
                .size(knobSize)
                .semantics { contentDescription = label }
                .pointerInput(Unit) { detectTapGestures(onTap = { tap() }) }
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val a = change.previousPosition - c
                        val b = change.position - c
                        if (a.getDistance() > 4f && b.getDistance() > 4f) {
                            val cross = a.x * b.y - a.y * b.x
                            val dot = a.x * b.x + a.y * b.y
                            turn(atan2(cross, dot) / sweep)
                        }
                    }
                }
        ) {
            val p = Skin.p
            val cx = size.width / 2f
            val cy = size.height / 2f
            val c = Offset(cx, cy)
            val r = size.minDimension / 2f
            val f = frac.coerceIn(0f, 1f)
            val knobDeg = -135f + f * 270f
            fun pt(deg: Float, rad: Float): Offset {
                val a = Math.toRadians((deg - 90f).toDouble())
                return Offset(cx + (rad * cos(a)).toFloat(), cy + (rad * sin(a)).toFloat())
            }

            // cincin titik LED
            val dots = 21
            for (i in 0 until dots) {
                val t = i / (dots - 1f)
                val deg = -135f + t * 270f
                val on = t <= f + 0.001f
                val pos = pt(deg, r * 0.92f)
                if (on) {
                    drawCircle(p.c3.copy(alpha = 0.35f), 3.6.dp.toPx(), pos)
                    drawCircle(lerp(p.c3, Color.White, 0.35f), 1.7.dp.toPx(), pos)
                } else {
                    drawCircle(p.ledOff, 1.5.dp.toPx(), pos)
                }
            }

            val rb = r * 0.78f
            // bayangan jatuh
            drawCircle(Color(0x88000000), rb + 2.dp.toPx(), c + Offset(0f, 3.dp.toPx()))
            // cincin luar gelap (lekuk dasar)
            drawCircle(Brush.verticalGradient(listOf(Color(0xFF000000), Color(0xFF3A3A3E)), cy - rb, cy + rb), rb + 1.5.dp.toPx(), c)
            // badan logam: kilau kerucut (conic) seperti logam gosok
            drawCircle(
                Brush.sweepGradient(
                    listOf(p.knobHi, p.knobLo, p.knobHi, p.knobLo, p.knobHi),
                    center = c,
                ),
                rb, c,
            )
            // gerigi yang ikut berputar
            val teeth = 36
            for (i in 0 until teeth) {
                val deg = knobDeg + i * (360f / teeth)
                drawLine(Color(0x99000000), pt(deg, rb * 0.88f), pt(deg, rb), 1.4.dp.toPx())
            }
            // sorot tepi badan
            drawCircle(
                Brush.verticalGradient(listOf(Color(0xCCFFFFFF), Color(0x00FFFFFF), Color(0x88000000)), cy - rb, cy + rb),
                rb, c, style = Stroke(1.6.dp.toPx()),
            )

            // tutup: tepi cembung -> permukaan cekung
            val rc = rb * 0.70f
            drawCircle(
                Brush.linearGradient(
                    listOf(p.thumbHi, p.thumbLo, Color(0xFF15151A)),
                    start = Offset(cx - rc, cy - rc), end = Offset(cx + rc, cy + rc),
                ),
                rc, c,
            )
            val rd = rc * 0.84f
            drawCircle(
                Brush.linearGradient(
                    listOf(Color(0xFF15151A), p.thumbLo, p.thumbHi),
                    start = Offset(cx - rd, cy - rd), end = Offset(cx + rd, cy + rd),
                ),
                rd, c,
            )
            drawCircle(Color(0x33000000), rd * 0.62f, c, style = Stroke(0.8.dp.toPx()))
            // sorot cahaya (specular) di kiri atas
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x99FFFFFF), Color(0x00FFFFFF)),
                    center = c + Offset(-rd * 0.35f, -rd * 0.45f), radius = rd * 0.75f,
                ),
                rd, c,
            )
            drawCircle(Color(0xFF000000), rc, c, style = Stroke(1.dp.toPx()))

            // penunjuk bercahaya
            val a0 = pt(knobDeg, rd * 0.30f)
            val a1 = pt(knobDeg, rd * 0.92f)
            drawLine(p.c3.copy(alpha = 0.40f), a0, a1, 5.dp.toPx(), StrokeCap.Round)
            drawLine(lerp(p.c3, Color.White, 0.6f), a0, a1, 2.2.dp.toPx(), StrokeCap.Round)
        }
        Text(
            label,
            color = WA_INK,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            lineHeight = 9.sp,
            maxLines = 1,
            style = CenteredLine,
            modifier = Modifier.padding(top = 2.dp),
        )
    }
}

// ================================================================== JENDELA VU METER (panel bawah)

@Composable
fun VuWindow(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val (levelL, levelR) = rememberStereoLevels(ui.isPlaying, ui.volume)
    val muted = ui.volume <= 0.001f

    WaWindow("VU METER", modifier = modifier, fill = true, contentPadding = 3.dp) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            // tinggi knob = tinggi panel dikurangi tulisan label di bawahnya
            val knobSize = (maxHeight - 12.dp).coerceIn(34.dp, 84.dp)
            Row(
                Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // KIRI: VU meter L + LED meter L (menyala ke kiri)
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    VuMeter("L", levelL, Modifier.fillMaxWidth().weight(1f))
                    LedMeter(levelL, growLeft = true, modifier = Modifier.fillMaxWidth().height(14.dp))
                }
                // TENGAH: knob volume besar (putar = volume, ketuk = bisu)
                VolumeKnob(
                    frac = ui.volume,
                    label = if (muted) "BISU" else "VOLUME",
                    knobSize = knobSize,
                    onTurn = { d -> vm.setVolume(vm.ui.value.volume + d) },
                    onTap = vm::toggleMute,
                )
                // KANAN: VU meter R + LED meter R (menyala ke kanan)
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    VuMeter("R", levelR, Modifier.fillMaxWidth().weight(1f))
                    LedMeter(levelR, growLeft = false, modifier = Modifier.fillMaxWidth().height(14.dp))
                }
            }
        }
    }
}
