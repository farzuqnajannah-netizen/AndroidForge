# Kipas Gantung Mini – Proyek Build APK (Capacitor)

Isi proyek:
- `www/index.html`  → game (satu file, sudah lengkap)
- `capacitor.config.json` → nama aplikasi & package ID (`com.kipasgantung.mini`)
- `package.json` → dependensi Capacitor

## Syarat
- Node.js 18+ (disarankan 20)
- Android Studio (sudah termasuk JDK & Android SDK)

## Langkah build
```bash
npm install
npx cap add android      # hanya sekali, membuat folder android/
npx cap sync android     # jalankan lagi setiap www/index.html diubah
npx cap open android     # membuka Android Studio
```

Di Android Studio:
- **APK untuk dicoba/dibagikan:** menu `Build > Build Bundle(s) / APK(s) > Build APK(s)`
  Hasil: `android/app/build/outputs/apk/debug/app-debug.apk`
  Kirim file ini ke HP lain, lalu izinkan "Instal dari sumber tidak dikenal".
- **Untuk Play Store:** `Build > Generate Signed Bundle / APK`.

## Catatan
- Font (Inter, Space Grotesk, Amiri) dimuat dari Google Fonts, jadi butuh internet.
  Tanpa internet, aplikasi tetap jalan dengan font bawaan HP.
  Supaya sepenuhnya offline, unduh file font dan taruh di `www/fonts/`,
  lalu ganti tag `<link>` Google Fonts dengan `@font-face` lokal.
- Ganti ikon: gunakan Android Studio `File > New > Image Asset`.
- Ganti nama/package ID: edit `capacitor.config.json` sebelum `npx cap add android`.

## Alternatif tanpa Android Studio
Bisa juga dengan layanan online seperti PWABuilder atau Appilix/WebIntoApp:
unggah `www/index.html` (atau hosting-kan dulu) lalu unduh APK-nya.
