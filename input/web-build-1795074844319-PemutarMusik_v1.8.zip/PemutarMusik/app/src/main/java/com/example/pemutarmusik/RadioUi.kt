package com.example.pemutarmusik

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import kotlin.math.roundToInt
import com.example.pemutarmusik.audio.AudioEngine
import java.util.Locale
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

// ================================================================== RADIO VINTAGE (isi jendela player)

private const val RADIO_MIN_F = 87.5f
private const val RADIO_MAX_F = 108f
private val RadioText = Color(0xFFD6E2FA)      // teks terang di atas biru tua
private val RadioTextDim = Color(0xFF7F9BD6)   // teks redup
private val RadioCyan = Color(0xFF35E0FF)      // skala / penanda aktif

/**
 * Isi jendela player saat mode RADIO, bergaya radio vintage (badan biru, trim perak):
 *  - kiri  : knob VOLUME (putar = volume, ketuk = bisu)
 *  - tengah: ATAS = nama stasiun + frekuensi, TENGAH = kaca skala + jarum, BAWAH = prev / play / next
 *  - kanan : knob TUNING (putar = geser jarum, lepas = menyetel ke stasiun terdekat)
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RadioBody(vm: PlayerViewModel, ui: PlayerUi) {
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val error by vm.radioError.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val pal = Skin.p
    val station = stations.firstOrNull { it.id == stationId }

    val stopped = ui.playbackState == Player.STATE_IDLE || ui.playbackState == Player.STATE_ENDED
    val connecting = !stopped && ui.playWhenReady && ui.playbackState == Player.STATE_BUFFERING
    val playing = ui.isPlaying
    val paused = !stopped && !playing && !connecting
    val muted = ui.volume <= 0.001f

    // Frekuensi sementara saat knob TUNING sedang diputar (null = tidak sedang menyetel)
    var tuneF by remember { mutableStateOf<Float?>(null) }
    val freq = station?.freqValue
    val shownF = tuneF ?: freq
    val freqText = shownF?.let { String.format(Locale.US, "%.1f", it) } ?: "--.-"
    val preview = tuneF?.let { f ->
        stations.filter { it.freqValue != null }
            .minByOrNull { abs(it.freqValue!! - f) }
            ?.takeIf { abs(it.freqValue!! - f) <= 0.3f }
    }
    // Judul lagu dari stream (ICY) kalau ada; kalau sama dengan nama stasiun, abaikan
    val onAir = if (station != null && ui.mediaId == "radio:${station.id}") ui.title?.takeIf { it != station.name } else null

    val bodyShape = RoundedCornerShape(10.dp)
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .clip(bodyShape)
            .background(Brush.verticalGradient(listOf(Color(0xFF2A56B0), Color(0xFF16356F), Color(0xFF0E2250))))
            .border(1.5.dp, Color(0xFF9AA4BA), bodyShape)
    ) {
        val knobSize = (maxHeight - 8.dp - 11.dp).coerceIn(34.dp, 70.dp)

        Row(
            Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // ---------------- KIRI: knob VOLUME
            RadioKnob(
                frac = ui.volume.coerceIn(0f, 1f),
                label = if (muted) "BISU" else "VOLUME",
                knobSize = knobSize,
                onTurn = { d -> vm.setVolume(vm.ui.value.volume + d) },
                onTap = vm::toggleMute,
            )

            // ---------------- TENGAH: layar nama+frekuensi, skala, tombol
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                // ATAS: nama stasiun + frekuensi (latar kisi seperti kain speaker)
                val dispShape = RoundedCornerShape(5.dp)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .weight(1.15f)
                        .clip(dispShape)
                        .background(Color(0xFF0B2159))
                        .border(1.dp, Color(0xFF6F8FD0), dispShape)
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val step = 3.dp.toPx()
                        val line = Color(0x1A8FB4FF)
                        var x = 0f
                        while (x < size.width) { drawLine(line, Offset(x, 0f), Offset(x, size.height), 0.8.dp.toPx()); x += step }
                        var y = 0f
                        while (y < size.height) { drawLine(line, Offset(0f, y), Offset(size.width, y), 0.8.dp.toPx()); y += step }
                    }
                    Row(
                        Modifier.fillMaxSize().padding(horizontal = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        val label = when {
                            tuneF != null -> "${preview?.name ?: "MENYETEL..."}  ***  "
                            error != null -> "! $error   "
                            station == null -> "PILIH STASIUN  ***  "
                            onAir != null -> "${station.name} - $onAir  ***  "
                            else -> "${station.name}  ***  "
                        }
                        val (statusText, statusColor) = when {
                            tuneF != null -> "MENYETEL" to RadioTextDim
                            error != null -> "ERROR" to Color(0xFFFF9E94)
                            scanning -> "SCAN..." to RadioCyan
                            connecting -> "MENYAMBUNG" to RadioCyan
                            playing -> "ON AIR" to pal.c2
                            paused -> "JEDA" to RadioTextDim
                            else -> "STOP" to RadioTextDim
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                            Text(
                                label,
                                color = if (error != null && tuneF == null) Color(0xFFFF9E94) else Color.White,
                                fontSize = 11.sp,
                                fontFamily = MONO,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 13.sp,
                                maxLines = 1,
                                softWrap = false,
                                style = CenteredLine,
                                modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE),
                            )
                            Text(
                                statusText,
                                color = statusColor,
                                fontSize = 8.sp,
                                fontFamily = MONO,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 9.sp,
                                maxLines = 1,
                                style = CenteredLine,
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(
                            freqText,
                            color = RadioCyan,
                            fontSize = 19.sp,
                            fontFamily = MONO,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 20.sp,
                            maxLines = 1,
                            style = CenteredLine,
                        )
                        Spacer(Modifier.width(3.dp))
                        Column(verticalArrangement = Arrangement.Center) {
                            Text("FM", color = Color.White, fontSize = 8.sp, fontFamily = MONO, fontWeight = FontWeight.Bold, lineHeight = 9.sp, style = CenteredLine)
                            Text("MHz", color = RadioTextDim, fontSize = 7.sp, fontFamily = MONO, lineHeight = 8.sp, style = CenteredLine)
                        }
                    }
                }

                // TENGAH: kaca skala frekuensi + jarum merah
                VintageDial(
                    stations = stations,
                    freq = shownF,
                    currentId = stationId,
                    playing = playing,
                    scanning = scanning,
                    dragging = tuneF != null,
                    onTune = vm::playStation,
                    modifier = Modifier.weight(0.85f).fillMaxWidth(),
                )

                // BAWAH: prev, play, next (+ SCAN dan SLEEP kecil di sisi)
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp, Alignment.CenterHorizontally),
                ) {
                    WaButton("SCAN", vm::toggleScan, active = scanning)
                    // stasiun sebelumnya = frekuensi lebih rendah, berikutnya = lebih tinggi
                    WaIconButton(Icons.Filled.SkipPrevious, "Stasiun sebelumnya", { vm.stepStation(-1) }, buttonSize = 28.dp, iconSize = 17.dp, accent = pal.c3)
                    val on = playing || connecting
                    WaIconButton(
                        if (on) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        if (on) "Jeda" else "Putar",
                        { if (on) vm.radioPause() else vm.radioPlay() },
                        buttonSize = 34.dp, iconSize = 22.dp, accent = pal.c3, active = on,
                    )
                    WaIconButton(Icons.Filled.SkipNext, "Stasiun berikutnya", { vm.stepStation(+1) }, buttonSize = 28.dp, iconSize = 17.dp, accent = pal.c3)
                    WaButton(if (sleepLeft > 0) "SLEEP ${sleepLeft}M" else "SLEEP", vm::cycleSleep, active = sleepLeft > 0)
                }
            }

            // ---------------- KANAN: knob TUNING
            RadioKnob(
                frac = (((shownF ?: RADIO_MIN_F) - RADIO_MIN_F) / (RADIO_MAX_F - RADIO_MIN_F)).coerceIn(0f, 1f),
                label = "TUNING",
                knobSize = knobSize,
                onTurn = { d ->
                    val base = tuneF ?: (freq ?: RADIO_MIN_F)
                    tuneF = (base + d * (RADIO_MAX_F - RADIO_MIN_F)).coerceIn(RADIO_MIN_F, RADIO_MAX_F)
                },
                onTurnEnd = {
                    val f = tuneF
                    tuneF = null
                    if (f != null) {
                        val near = stations.filter { it.freqValue != null }.minByOrNull { abs(it.freqValue!! - f) }
                        if (near != null && abs(near.freqValue!! - f) <= 1.2f && near.id != stationId) vm.playStation(near)
                    }
                },
            )
        }
    }
}

/**
 * Knob putar vintage (tepi bergerigi, tutup perak, penunjuk biru) dengan skala titik di sekelilingnya.
 * Putar dengan jari melingkar searah jarum jam = naik. [frac] 0..1 = posisi knob (sapuan 270 derajat).
 * [onTurn] menerima perubahan pecahan (-1..1) tiap gerakan; [onTap] opsional (mis. bisu).
 */
@Composable
private fun RadioKnob(
    frac: Float,
    label: String,
    knobSize: Dp,
    onTurn: (Float) -> Unit,
    modifier: Modifier = Modifier,
    onTurnEnd: () -> Unit = {},
    onTap: (() -> Unit)? = null,
) {
    val turn by rememberUpdatedState(onTurn)
    val turnEnd by rememberUpdatedState(onTurnEnd)
    val tap by rememberUpdatedState(onTap)
    val sweep = 270f * PI.toFloat() / 180f

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier
                .size(knobSize)
                .semantics { contentDescription = label }
                .pointerInput(Unit) { detectTapGestures(onTap = { tap?.invoke() }) }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = { turnEnd() },
                        onDragCancel = { turnEnd() },
                    ) { change, _ ->
                        change.consume()
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val a = change.previousPosition - c
                        val b = change.position - c
                        if (a.getDistance() > 4f && b.getDistance() > 4f) {
                            val cross = a.x * b.y - a.y * b.x
                            val dot = a.x * b.x + a.y * b.y
                            turn(atan2(cross, dot) / sweep)
                        }
                    }
                }
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val c = Offset(cx, cy)
            val r = size.minDimension / 2f
            val f = frac.coerceIn(0f, 1f)
            val knobDeg = -135f + f * 270f
            fun pt(deg: Float, rad: Float): Offset {
                val a = Math.toRadians((deg - 90f).toDouble())
                return Offset(cx + (rad * cos(a)).toFloat(), cy + (rad * sin(a)).toFloat())
            }

            // skala titik: menyala cyan sampai posisi knob
            for (i in 0..10) {
                val deg = -135f + i * 27f
                val lit = i / 10f <= f + 0.001f
                drawLine(
                    if (lit) RadioCyan else Color(0xFF3F5A9A),
                    pt(deg, r * 0.90f), pt(deg, r),
                    1.6.dp.toPx(), StrokeCap.Round,
                )
            }

            val rb = r * 0.80f
            // bayangan
            drawCircle(Color(0x66000000), rb + 1.5.dp.toPx(), c + Offset(0f, 1.5.dp.toPx()))
            // badan knob (logam biru tua) + gerigi yang ikut berputar
            drawCircle(Brush.radialGradient(listOf(Color(0xFF8C9BC0), Color(0xFF2A3A68)), c, rb), rb, c)
            val teeth = 28
            for (i in 0 until teeth) {
                val deg = knobDeg + i * (360f / teeth)
                drawLine(Color(0xCC16244A), pt(deg, rb * 0.86f), pt(deg, rb), 1.3.dp.toPx())
            }
            drawCircle(WA_BORDER, rb, c, style = Stroke(1.2.dp.toPx()))

            // tutup perak
            val rc = rb * 0.68f
            drawCircle(
                Brush.linearGradient(
                    listOf(Color(0xFFF1F4FA), Color(0xFFA9B3C9), Color(0xFF8590AB)),
                    start = Offset(cx - rc, cy - rc), end = Offset(cx + rc, cy + rc),
                ),
                rc, c,
            )
            drawCircle(Color(0x2216244A), rc * 0.72f, c, style = Stroke(0.8.dp.toPx()))
            drawCircle(Color(0x2216244A), rc * 0.45f, c, style = Stroke(0.8.dp.toPx()))
            drawCircle(WA_BORDER, rc, c, style = Stroke(1.dp.toPx()))

            // penunjuk
            drawLine(WA_INK, pt(knobDeg, rc * 0.22f), pt(knobDeg, rc * 0.92f), 2.4.dp.toPx(), StrokeCap.Round)
            drawCircle(RadioCyan, 1.6.dp.toPx(), pt(knobDeg, rc * 0.80f))
        }
        Text(
            label,
            color = RadioText,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            lineHeight = 9.sp,
            maxLines = 1,
            style = CenteredLine,
            modifier = Modifier.padding(top = 2.dp),
        )
    }
}

/**
 * Kaca skala radio vintage berwarna biru tua (huruf terang seperti pada radio asli): angka 88-108 MHz,
 * garis skala tiap 0,5 MHz, penanda tiap stasiun dan jarum merah yang bergeser halus.
 * Ketuk skala untuk menyetel ke stasiun terdekat (maks. 1,2 MHz dari titik ketukan).
 */
@Composable
private fun VintageDial(
    stations: List<RadioStation>,
    freq: Float?,
    currentId: Long?,
    playing: Boolean,
    scanning: Boolean,
    dragging: Boolean,
    onTune: (RadioStation) -> Unit,
    modifier: Modifier = Modifier,
) {
    val minF = RADIO_MIN_F
    val maxF = RADIO_MAX_F
    val needleF by animateFloatAsState(
        targetValue = freq ?: minF,
        animationSpec = tween(durationMillis = if (dragging) 0 else if (scanning) 450 else 700),
        label = "needle",
    )
    val glow by animateFloatAsState(if (playing || dragging) 1f else 0.55f, label = "glow")
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
            textAlign = android.graphics.Paint.Align.CENTER
        }
    }
    val shape = RoundedCornerShape(6.dp)
    val ink = RadioText

    Box(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF040A1E), Color(0xFF0A1A44))))
            .border(1.5.dp, Color(0xFF9AA4BA), shape)
            .pointerInput(stations) {
                detectTapGestures { pos ->
                    val padX = 12.dp.toPx()
                    val w = size.width - padX * 2
                    val f = minF + ((pos.x - padX) / w).coerceIn(0f, 1f) * (maxF - minF)
                    val near = stations.filter { it.freqValue != null }.minByOrNull { abs(it.freqValue!! - f) }
                    if (near != null && abs(near.freqValue!! - f) <= 1.2f) onTune(near)
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val padX = 12.dp.toPx()
            val scaleW = w - padX * 2
            fun xOf(f: Float) = padX + scaleW * ((f - minF) / (maxF - minF)).coerceIn(0f, 1f)

            // pantulan kaca di bagian atas
            drawRect(Color(0x22FFFFFF), topLeft = Offset.Zero, size = Size(w, h * 0.34f))

            // angka skala (88, 92, ... 108)
            paint.color = ink.toArgb()
            paint.textSize = 8.sp.toPx()
            val nc = drawContext.canvas.nativeCanvas
            for (m in 88..108 step 4) nc.drawText(m.toString(), xOf(m.toFloat()), h * 0.36f, paint)

            // garis dasar + garis skala tiap 0,5 MHz
            val baseY = h * 0.46f
            drawLine(ink, Offset(padX, baseY), Offset(w - padX, baseY), 1.dp.toPx())
            var i = 0
            while (true) {
                val f = minF + 0.5f * i
                if (f > maxF + 0.001f) break
                val tenth = (f * 10f).roundToInt()
                val whole = tenth % 10 == 0
                val major = whole && (tenth / 10) % 4 == 0
                val len = h * if (major) 0.26f else if (whole) 0.18f else 0.10f
                val x = xOf(f)
                drawLine(ink, Offset(x, baseY), Offset(x, baseY + len), (if (major) 1.4f else 0.9f).dp.toPx())
                i++
            }

            // penanda stasiun (titik) di bawah skala
            val markTop = baseY + h * 0.28f
            val markY = h * 0.82f
            for (st in stations) {
                val f = st.freqValue ?: continue
                val x = xOf(f)
                val cur = st.id == currentId
                val c = if (cur) RadioCyan else Color(0xFF6F8CC8)
                drawLine(c.copy(alpha = 0.7f), Offset(x, markTop), Offset(x, markY), 1.dp.toPx())
                drawCircle(c, radius = (if (cur) 3f else 2.2f).dp.toPx(), center = Offset(x, markY))
            }

            // jarum merah + cahayanya
            val nx = xOf(needleF)
            drawLine(Color(0xFFFF3B30).copy(alpha = 0.30f * glow), Offset(nx, 2.dp.toPx()), Offset(nx, h - 2.dp.toPx()), 6.dp.toPx())
            drawLine(Color(0xFFE5261C), Offset(nx, 2.dp.toPx()), Offset(nx, h - 2.dp.toPx()), 1.6.dp.toPx())
        }
    }
}

// ================================================================== DAFTAR STASIUN (jendela kanan)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RadioListWindow(
    vm: PlayerViewModel,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val titleH = rememberTitleBarHeight()
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val ui by vm.ui.collectAsState()
    val pal = Skin.p

    var editing by remember { mutableStateOf<RadioStation?>(null) }
    var adding by remember { mutableStateOf(false) }

    WaWindow(
        "STASIUN RADIO", modifier, fill = true,
        titleHeight = titleH,
        actions = {
            WaTitleButton(false, "Kecilkan ke mini player", titleH, onMinimize)
            WaTitleButton(true, "Tutup aplikasi", titleH, onClose)
        },
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().bevel(false, WA_LCD)) {
            if (stations.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Belum ada stasiun.\nTekan + STASIUN untuk menambah.",
                        color = WA_GREEN, fontSize = 11.sp, fontFamily = MONO, textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(stations, key = { it.id }) { st ->
                        val isCurrent = st.id == stationId
                        val live = isCurrent && ui.isPlaying
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(if (isCurrent) WA_SEL else Color.Transparent)
                                .clickable { vm.playStation(st) }
                                .padding(start = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                if (live) "▶" else " ",
                                color = if (isCurrent) Color.White else pal.c1,
                                fontSize = 11.sp, fontFamily = MONO,
                                modifier = Modifier.width(14.dp),
                            )
                            Text(
                                st.freq.ifBlank { "--.-" },
                                color = if (isCurrent) Color.White else pal.c1,
                                fontSize = 13.sp, fontFamily = MONO, fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(52.dp),
                            )
                            Text(
                                st.name,
                                color = if (isCurrent) Color.White else WA_GREEN,
                                fontSize = 13.sp, fontFamily = MONO,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            Box(
                                Modifier.size(38.dp).clickable { editing = st },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    Icons.Filled.Edit, "Edit stasiun",
                                    tint = if (isCurrent) Color.White else WA_GREEN_DIM,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "${stations.size} STASIUN  -  urut frekuensi  -  ketuk = putar",
                color = WA_INK, fontSize = 9.sp, fontFamily = MONO, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            WaButton("+ STASIUN", { adding = true })
        }
    }

    if (adding) {
        StationDialog(
            initial = null,
            onSave = { name, freq, url -> vm.addStation(name, freq, url); adding = false },
            onDelete = null,
            onDismiss = { adding = false },
        )
    }
    editing?.let { st ->
        StationDialog(
            initial = st,
            onSave = { name, freq, url -> vm.updateStation(st.id, name, freq, url); editing = null },
            onDelete = { vm.deleteStation(st.id); editing = null },
            onDismiss = { editing = null },
        )
    }
}

/** Rapikan alamat: tambahkan https:// kalau belum ada. Mengembalikan null kalau bukan alamat yang valid. */
private fun normalizeUrl(raw: String): String? {
    val t = raw.trim()
    if (t.isEmpty()) return null
    val full = if (t.startsWith("http://", true) || t.startsWith("https://", true)) t else "https://$t"
    val host = try { Uri.parse(full).host } catch (e: Exception) { null }
    return if (!host.isNullOrBlank() && host.contains('.')) full else null
}

@Composable
private fun StationDialog(
    initial: RadioStation?,
    onSave: (name: String, freq: String, url: String) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var freq by remember { mutableStateOf(initial?.freq ?: "") }
    var url by remember { mutableStateOf(initial?.url ?: "") }
    var problem by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val fieldStyle = TextStyle(color = Color.White, fontFamily = MONO, fontSize = 14.sp)

    fun trySave() {
        val cleanUrl = normalizeUrl(url)
        val f = freq.trim().replace(',', '.')
        val fNum = f.toFloatOrNull()
        when {
            name.isBlank() -> problem = "Nama stasiun belum diisi."
            cleanUrl == null -> problem = "Alamat URL tidak valid."
            f.isNotEmpty() && (fNum == null || fNum !in 76f..108f) -> problem = "Frekuensi FM harus 76 - 108 MHz (contoh 99.5)."
            else -> onSave(
                name.trim(),
                if (fNum != null) String.format(Locale.US, "%.1f", fNum) else "",
                cleanUrl.orEmpty(),
            )
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1B2F66),
        titleContentColor = Color.White,
        textContentColor = WA_GREEN,
        title = {
            Text(
                if (initial == null) "Tambah stasiun" else "Edit stasiun",
                fontFamily = MONO, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it.take(40); problem = null },
                        singleLine = true,
                        label = { Text("Nama stasiun") },
                        textStyle = fieldStyle,
                        modifier = Modifier.weight(1.6f),
                    )
                    OutlinedTextField(
                        value = freq,
                        onValueChange = { v -> freq = v.filter { it.isDigit() || it == '.' || it == ',' }.take(6); problem = null },
                        singleLine = true,
                        label = { Text("Frekuensi") },
                        placeholder = { Text("99.5") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = fieldStyle,
                        modifier = Modifier.weight(1f),
                    )
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; problem = null },
                    singleLine = true,
                    label = { Text("Alamat URL stream") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    textStyle = fieldStyle,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Frekuensi boleh dikosongkan. Alamat harus langsung ke stream audio (MP3/AAC), bukan halaman web.",
                    color = WA_GREEN_DIM, fontFamily = MONO, fontSize = 10.sp,
                )
                problem?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = Color(0xFFFF9E94), fontFamily = MONO, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { trySave() }) {
                Text("SIMPAN", color = Skin.p.c1, fontFamily = MONO, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = { if (confirmDelete) onDelete() else confirmDelete = true }) {
                        Text(
                            if (confirmDelete) "YAKIN HAPUS?" else "HAPUS",
                            color = Color(0xFFFF9E94), fontFamily = MONO, fontWeight = FontWeight.Bold,
                        )
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text("BATAL", color = WA_GREEN_DIM, fontFamily = MONO, fontWeight = FontWeight.Bold)
                }
            }
        },
    )
}
