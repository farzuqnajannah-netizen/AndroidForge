package com.kipasmini.edukasi;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Membungkus index.html (di assets) dalam WebView layar penuh.
 * Pengenal suara memakai SpeechRecognizer bawaan Android, dijembatani ke JavaScript
 * lewat objek AndroidSpeech, karena WebView tidak punya webkitSpeechRecognition.
 */
public class MainActivity extends Activity {

    private static final int REQ_AUDIO = 1;

    private WebView web;
    private SpeechRecognizer recognizer;
    private String pendingLang = "id-ID";
    private boolean destroyed = false;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#E8ECEF"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setSupportZoom(false);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidSpeech");
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Objek yang dilihat JavaScript sebagai window.AndroidSpeech */
    private class Bridge {
        @JavascriptInterface
        public boolean available() {
            return SpeechRecognizer.isRecognitionAvailable(MainActivity.this);
        }

        @JavascriptInterface
        public void start(final String lang) {
            runOnUiThread(() -> startListening(lang));
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(() -> releaseRecognizer());
        }
    }

    private void startListening(String lang) {
        pendingLang = lang;
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        listen(lang, true);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                listen(pendingLang, true);
            } else {
                send("error", "denied");
            }
        }
    }

    /** preferOffline: coba pakai paket suara offline dulu; jika tidak ada, ulangi tanpa syarat offline. */
    private void listen(final String lang, final boolean preferOffline) {
        if (destroyed) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            send("error", "unavailable");
            return;
        }
        releaseRecognizer();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { send("ready", ""); }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int eventType, Bundle params) { }

            @Override
            public void onError(final int error) {
                // 12 = bahasa tidak didukung, 13 = bahasa belum tersedia (paket offline belum diunduh)
                if (preferOffline && (error == 12 || error == 13)) {
                    main.post(() -> listen(lang, false));
                    return;
                }
                send("error", String.valueOf(error));
            }

            @Override public void onResults(Bundle results) { send("final", matches(results)); }
            @Override public void onPartialResults(Bundle partial) { send("partial", matches(partial)); }
        });

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        if (preferOffline) {
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        }
        recognizer.startListening(i);
    }

    private String matches(Bundle b) {
        JSONArray a = new JSONArray();
        if (b != null) {
            ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (l != null) {
                for (String s : l) a.put(s);
            }
        }
        return a.toString();
    }

    private void send(String type, String data) {
        if (destroyed) return;
        final String js = "window.__nativeSpeech&&window.__nativeSpeech("
                + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")";
        runOnUiThread(() -> {
            if (!destroyed) web.evaluateJavascript(js, null);
        });
    }

    private void releaseRecognizer() {
        if (recognizer != null) {
            try {
                recognizer.cancel();
                recognizer.destroy();
            } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    @Override
    protected void onPause() {
        releaseRecognizer();
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        releaseRecognizer();
        web.destroy();
        super.onDestroy();
    }
}
