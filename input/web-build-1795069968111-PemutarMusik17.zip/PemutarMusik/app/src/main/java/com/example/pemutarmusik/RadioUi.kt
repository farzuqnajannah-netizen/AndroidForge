package com.example.pemutarmusik

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import kotlin.math.roundToInt
import com.example.pemutarmusik.audio.AudioEngine
import java.util.Locale

// ================================================================== RADIO VINTAGE (isi jendela player)

/**
 * Isi jendela player saat mode RADIO, bergaya radio vintage:
 * kiri = layar LCD frekuensi digital + lampu + volume/mute; kanan = kaca skala frekuensi (jarum, penanda stasiun)
 * dan baris tombol (stasiun -/+, jeda, putar, henti, SCAN, SLEEP).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RadioBody(vm: PlayerViewModel, ui: PlayerUi) {
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val error by vm.radioError.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val pal = Skin.p
    val station = stations.firstOrNull { it.id == stationId }

    val stopped = ui.playbackState == Player.STATE_IDLE || ui.playbackState == Player.STATE_ENDED
    val connecting = !stopped && ui.playWhenReady && ui.playbackState == Player.STATE_BUFFERING
    val playing = ui.isPlaying
    val paused = !stopped && !playing && !connecting
    val muted = ui.volume <= 0.001f

    val freq = station?.freqValue
    val freqText = freq?.let { String.format(Locale.US, "%.1f", it) } ?: "--.-"
    // Judul lagu dari stream (ICY) kalau ada; kalau sama dengan nama stasiun, abaikan
    val onAir = if (station != null && ui.mediaId == "radio:${station.id}") ui.title?.takeIf { it != station.name } else null

    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        // KIRI: layar digital, lampu, volume + mute
        Column(Modifier.width(120.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Column(
                Modifier.fillMaxWidth().weight(1f).bevel(false, WA_LCD).padding(horizontal = 6.dp, vertical = 2.dp),
                verticalArrangement = Arrangement.SpaceEvenly,
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        freqText,
                        color = WA_GREEN,
                        fontSize = 20.sp,
                        fontFamily = MONO,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 22.sp,
                        style = CenteredLine,
                    )
                    Spacer(Modifier.width(3.dp))
                    Column(Modifier.padding(bottom = 1.dp)) {
                        Text("FM", color = pal.c1, fontSize = 8.sp, fontFamily = MONO, fontWeight = FontWeight.Bold, lineHeight = 9.sp, style = CenteredLine)
                        Text("MHz", color = WA_GREEN_DIM, fontSize = 7.sp, fontFamily = MONO, lineHeight = 8.sp, style = CenteredLine)
                    }
                }
                val label = when {
                    error != null -> "! $error   "
                    station == null -> "PILIH STASIUN  ***  "
                    onAir != null -> "${station.name} - $onAir  ***  "
                    else -> "${station.name}  ***  "
                }
                Text(
                    label,
                    color = if (error != null) Color(0xFFFF9E94) else pal.c1,
                    fontSize = 9.sp,
                    fontFamily = MONO,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE),
                )
                val (statusText, statusColor) = when {
                    error != null -> "ERROR" to Color(0xFFFF9E94)
                    scanning -> "SCAN..." to Color(0xFFFFD27A)
                    connecting -> "MENYAMBUNG" to Color(0xFFFFD27A)
                    playing -> "ON AIR" to pal.c2
                    paused -> "JEDA" to WA_GREEN_DIM
                    else -> "STOP" to WA_GREEN_DIM
                }
                Text(statusText, color = statusColor, fontSize = 8.sp, fontFamily = MONO, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                Lamp("LIVE", pal.c2, playing)
                Lamp("BUF", pal.c4, connecting)
                Lamp("SCAN", pal.c1, scanning)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                WaIconButton(
                    if (muted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp,
                    "Bisukan", vm::toggleMute,
                    buttonSize = 22.dp, iconSize = 13.dp, accent = pal.c3, active = muted,
                )
                Spacer(Modifier.width(4.dp))
                WaSlider(
                    value = ui.volume,
                    onValueChange = vm::setVolume,
                    range = 0f..1f,
                    modifier = Modifier.weight(1f).height(14.dp),
                )
            }
        }

        // KANAN: kaca skala frekuensi vintage + tombol
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            VintageDial(
                stations = stations,
                freq = freq,
                currentId = stationId,
                playing = playing,
                scanning = scanning,
                onTune = vm::playStation,
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                // stasiun sebelumnya = frekuensi lebih rendah, berikutnya = lebih tinggi
                WaIconButton(Icons.Filled.SkipPrevious, "Stasiun frekuensi lebih rendah", { vm.stepStation(-1) }, buttonSize = 26.dp, iconSize = 15.dp, accent = pal.c3)
                WaIconButton(Icons.Filled.Pause, "Jeda", vm::radioPause, buttonSize = 26.dp, iconSize = 15.dp, accent = pal.c3, active = paused)
                WaIconButton(Icons.Filled.PlayArrow, "Putar", vm::radioPlay, buttonSize = 32.dp, iconSize = 20.dp, accent = pal.c3, active = playing || connecting)
                WaIconButton(Icons.Filled.Stop, "Henti", vm::radioStop, buttonSize = 26.dp, iconSize = 15.dp, accent = pal.c3, active = stopped)
                WaIconButton(Icons.Filled.SkipNext, "Stasiun frekuensi lebih tinggi", { vm.stepStation(+1) }, buttonSize = 26.dp, iconSize = 15.dp, accent = pal.c3)
                Spacer(Modifier.weight(1f))
                WaButton("SCAN", vm::toggleScan, active = scanning)
                WaButton(if (sleepLeft > 0) "SLEEP ${sleepLeft}M" else "SLEEP", vm::cycleSleep, active = sleepLeft > 0)
            }
        }
    }
}

/**
 * Kaca skala radio vintage: latar krem/kuning gading, angka 88-108 MHz, garis skala tiap 0,5 MHz,
 * penanda tiap stasiun (urut frekuensi) dan jarum merah yang bergeser halus ke stasiun yang dipilih.
 * Ketuk skala untuk menyetel ke stasiun terdekat (maks. 1,2 MHz dari titik ketukan).
 */
@Composable
private fun VintageDial(
    stations: List<RadioStation>,
    freq: Float?,
    currentId: Long?,
    playing: Boolean,
    scanning: Boolean,
    onTune: (RadioStation) -> Unit,
    modifier: Modifier = Modifier,
) {
    val minF = 87.5f
    val maxF = 108f
    val needleF by animateFloatAsState(
        targetValue = freq ?: minF,
        animationSpec = tween(durationMillis = if (scanning) 450 else 700),
        label = "needle",
    )
    val glow by animateFloatAsState(if (playing) 1f else 0.55f, label = "glow")
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
            textAlign = android.graphics.Paint.Align.CENTER
        }
    }
    val shape = RoundedCornerShape(8.dp)
    val ink = Color(0xFF3B2A14)

    Box(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFF8EBC2), Color(0xFFEACB8C), Color(0xFFD7A95A))))
            .border(2.dp, ink, shape)
            .pointerInput(stations) {
                detectTapGestures { pos ->
                    val padX = 12.dp.toPx()
                    val w = size.width - padX * 2
                    val f = minF + ((pos.x - padX) / w).coerceIn(0f, 1f) * (maxF - minF)
                    val near = stations.filter { it.freqValue != null }.minByOrNull { abs(it.freqValue!! - f) }
                    if (near != null && abs(near.freqValue!! - f) <= 1.2f) onTune(near)
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val padX = 12.dp.toPx()
            val scaleW = w - padX * 2
            fun xOf(f: Float) = padX + scaleW * ((f - minF) / (maxF - minF)).coerceIn(0f, 1f)

            // pantulan kaca di bagian atas
            drawRect(Color(0x33FFFFFF), topLeft = Offset.Zero, size = Size(w, h * 0.36f))

            // angka skala (88, 92, ... 108)
            paint.color = ink.toArgb()
            paint.textSize = 9.sp.toPx()
            val nc = drawContext.canvas.nativeCanvas
            for (m in 88..108 step 4) nc.drawText(m.toString(), xOf(m.toFloat()), h * 0.30f, paint)

            // garis dasar + garis skala tiap 0,5 MHz
            val baseY = h * 0.40f
            drawLine(ink, Offset(padX, baseY), Offset(w - padX, baseY), 1.2.dp.toPx())
            var i = 0
            while (true) {
                val f = minF + 0.5f * i
                if (f > maxF + 0.001f) break
                val tenth = (f * 10f).roundToInt()
                val whole = tenth % 10 == 0
                val major = whole && (tenth / 10) % 4 == 0
                val len = h * if (major) 0.22f else if (whole) 0.16f else 0.09f
                val x = xOf(f)
                drawLine(ink, Offset(x, baseY), Offset(x, baseY + len), (if (major) 1.6f else 1f).dp.toPx())
                i++
            }

            // penanda stasiun
            val markTop = baseY + h * 0.22f
            val markY = h * 0.76f
            for (st in stations) {
                val f = st.freqValue ?: continue
                val x = xOf(f)
                val cur = st.id == currentId
                val c = if (cur) Color(0xFFD62B2B) else Color(0xFF7A4B1E)
                drawLine(c.copy(alpha = 0.7f), Offset(x, markTop), Offset(x, markY), 1.dp.toPx())
                drawCircle(c, radius = (if (cur) 3.5f else 2.5f).dp.toPx(), center = Offset(x, markY))
            }

            // nama stasiun terpilih di bawah skala
            val current = stations.firstOrNull { it.id == currentId }
            if (current != null) {
                paint.color = ink.toArgb()
                paint.textSize = 8.sp.toPx()
                val label = current.name.uppercase().take(18)
                val half = paint.measureText(label) / 2f
                val cx = (if (current.freqValue != null) xOf(current.freqValue!!) else w / 2f).coerceIn(half + 4.dp.toPx(), w - half - 4.dp.toPx())
                nc.drawText(label, cx, h - 4.dp.toPx(), paint)
            }

            // jarum merah + cahayanya
            val nx = xOf(needleF)
            drawLine(Color(0xFFFF3B30).copy(alpha = 0.30f * glow), Offset(nx, 3.dp.toPx()), Offset(nx, h - 3.dp.toPx()), 7.dp.toPx())
            drawLine(Color(0xFFE5261C), Offset(nx, 3.dp.toPx()), Offset(nx, h - 3.dp.toPx()), 1.8.dp.toPx())
            drawCircle(Color(0xFF8E1B14), radius = 3.dp.toPx(), center = Offset(nx, 4.dp.toPx()))
        }
    }
}

// ================================================================== DAFTAR STASIUN (jendela kanan)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RadioListWindow(
    vm: PlayerViewModel,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val titleH = rememberTitleBarHeight()
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val ui by vm.ui.collectAsState()
    val pal = Skin.p

    var editing by remember { mutableStateOf<RadioStation?>(null) }
    var adding by remember { mutableStateOf(false) }

    WaWindow(
        "STASIUN RADIO", modifier, fill = true,
        titleHeight = titleH,
        actions = {
            WaTitleButton(false, "Kecilkan ke mini player", titleH, onMinimize)
            WaTitleButton(true, "Tutup aplikasi", titleH, onClose)
        },
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().bevel(false, WA_LCD)) {
            if (stations.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Belum ada stasiun.\nTekan + STASIUN untuk menambah.",
                        color = WA_GREEN, fontSize = 11.sp, fontFamily = MONO, textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(stations, key = { it.id }) { st ->
                        val isCurrent = st.id == stationId
                        val live = isCurrent && ui.isPlaying
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(if (isCurrent) WA_SEL else Color.Transparent)
                                .clickable { vm.playStation(st) }
                                .padding(start = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                if (live) "▶" else " ",
                                color = if (isCurrent) Color.White else pal.c1,
                                fontSize = 11.sp, fontFamily = MONO,
                                modifier = Modifier.width(14.dp),
                            )
                            Text(
                                st.freq.ifBlank { "--.-" },
                                color = if (isCurrent) Color.White else pal.c1,
                                fontSize = 13.sp, fontFamily = MONO, fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(52.dp),
                            )
                            Text(
                                st.name,
                                color = if (isCurrent) Color.White else WA_GREEN,
                                fontSize = 13.sp, fontFamily = MONO,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            Box(
                                Modifier.size(38.dp).clickable { editing = st },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    Icons.Filled.Edit, "Edit stasiun",
                                    tint = if (isCurrent) Color.White else WA_GREEN_DIM,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "${stations.size} STASIUN  -  urut frekuensi  -  ketuk = putar",
                color = WA_INK, fontSize = 9.sp, fontFamily = MONO, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            WaButton("+ STASIUN", { adding = true })
        }
    }

    if (adding) {
        StationDialog(
            initial = null,
            onSave = { name, freq, url -> vm.addStation(name, freq, url); adding = false },
            onDelete = null,
            onDismiss = { adding = false },
        )
    }
    editing?.let { st ->
        StationDialog(
            initial = st,
            onSave = { name, freq, url -> vm.updateStation(st.id, name, freq, url); editing = null },
            onDelete = { vm.deleteStation(st.id); editing = null },
            onDismiss = { editing = null },
        )
    }
}

/** Rapikan alamat: tambahkan https:// kalau belum ada. Mengembalikan null kalau bukan alamat yang valid. */
private fun normalizeUrl(raw: String): String? {
    val t = raw.trim()
    if (t.isEmpty()) return null
    val full = if (t.startsWith("http://", true) || t.startsWith("https://", true)) t else "https://$t"
    val host = try { Uri.parse(full).host } catch (e: Exception) { null }
    return if (!host.isNullOrBlank() && host.contains('.')) full else null
}

@Composable
private fun StationDialog(
    initial: RadioStation?,
    onSave: (name: String, freq: String, url: String) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var freq by remember { mutableStateOf(initial?.freq ?: "") }
    var url by remember { mutableStateOf(initial?.url ?: "") }
    var problem by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val fieldStyle = TextStyle(color = Color.White, fontFamily = MONO, fontSize = 14.sp)

    fun trySave() {
        val cleanUrl = normalizeUrl(url)
        val f = freq.trim().replace(',', '.')
        val fNum = f.toFloatOrNull()
        when {
            name.isBlank() -> problem = "Nama stasiun belum diisi."
            cleanUrl == null -> problem = "Alamat URL tidak valid."
            f.isNotEmpty() && (fNum == null || fNum !in 76f..108f) -> problem = "Frekuensi FM harus 76 - 108 MHz (contoh 99.5)."
            else -> onSave(
                name.trim(),
                if (fNum != null) String.format(Locale.US, "%.1f", fNum) else "",
                cleanUrl.orEmpty(),
            )
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1B2F66),
        titleContentColor = Color.White,
        textContentColor = WA_GREEN,
        title = {
            Text(
                if (initial == null) "Tambah stasiun" else "Edit stasiun",
                fontFamily = MONO, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it.take(40); problem = null },
                        singleLine = true,
                        label = { Text("Nama stasiun") },
                        textStyle = fieldStyle,
                        modifier = Modifier.weight(1.6f),
                    )
                    OutlinedTextField(
                        value = freq,
                        onValueChange = { v -> freq = v.filter { it.isDigit() || it == '.' || it == ',' }.take(6); problem = null },
                        singleLine = true,
                        label = { Text("Frekuensi") },
                        placeholder = { Text("99.5") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = fieldStyle,
                        modifier = Modifier.weight(1f),
                    )
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; problem = null },
                    singleLine = true,
                    label = { Text("Alamat URL stream") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    textStyle = fieldStyle,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Frekuensi boleh dikosongkan. Alamat harus langsung ke stream audio (MP3/AAC), bukan halaman web.",
                    color = WA_GREEN_DIM, fontFamily = MONO, fontSize = 10.sp,
                )
                problem?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = Color(0xFFFF9E94), fontFamily = MONO, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { trySave() }) {
                Text("SIMPAN", color = Skin.p.c1, fontFamily = MONO, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = { if (confirmDelete) onDelete() else confirmDelete = true }) {
                        Text(
                            if (confirmDelete) "YAKIN HAPUS?" else "HAPUS",
                            color = Color(0xFFFF9E94), fontFamily = MONO, fontWeight = FontWeight.Bold,
                        )
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text("BATAL", color = WA_GREEN_DIM, fontFamily = MONO, fontWeight = FontWeight.Bold)
                }
            }
        },
    )
}
