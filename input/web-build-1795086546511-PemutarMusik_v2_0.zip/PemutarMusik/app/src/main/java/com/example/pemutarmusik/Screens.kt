package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(s / 60, s % 60)
}

@Composable
private fun rememberMeter(read: () -> Float): Float {
    var db by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            db = read()
            delay(100)
        }
    }
    return db
}

/** Lampu kecil berlabel: LED menyala/mati + teks. */
@Composable
fun Lamp(label: String, color: Color, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Led(color, on, diameter = 7.dp)
        Text(
            label,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            color = if (on) WA_INK else WA_LAMP_OFF,
        )
    }
}

/** Tombol ikon bulat kecil + LED di sampingnya (menyala = aktif). */
@Composable
private fun LedToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    ledColor: Color,
    on: Boolean,
    onClick: () -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        WaIconButton(icon, description, onClick, buttonSize = 26.dp, iconSize = 14.dp)
        Led(ledColor, on, diameter = 7.dp)
    }
}

// ================================================================== JENDELA UTAMA

/** Nomor versi aplikasi, mis. "v.1.8". Diambil dari versionName di app/build.gradle.kts, jadi cukup ubah di satu tempat. */
@Composable
private fun appVersionLabel(context: android.content.Context): String = remember {
    try {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        "v.${info.versionName}"
    } catch (e: Exception) {
        ""
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainWindow(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val s by AudioEngine.settings.collectAsState()
    val guardDb = rememberMeter { AudioEngine.processor.guardReductionDb }
    val limDb = rememberMeter { AudioEngine.processor.limiterReductionDb }
    val pal = Skin.p
    val mode by vm.mode.collectAsState()
    val titleH = rememberTitleBarHeight()
    val versionLabel = appVersionLabel(LocalContext.current)

    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
    val shown = drag ?: fraction

    // Jendela tetap (tanpa minimize), mengisi 1/3 tinggi kolom kiri.
    WaWindow(
        if (mode == AppMode.RADIO) "RADIO DIGITAL" else "MUSIC PLAYER", modifier = modifier, fill = true,
        contentPadding = 3.dp,
        titleHeight = titleH,
        actions = {
            ModeButtons(mode, vm::setMode, titleH)
            Text(
                "mod by aries $versionLabel",
                color = Color(0xFF7FEBFF),
                fontSize = 9.sp,
                fontFamily = MONO,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                lineHeight = 11.sp,
                style = CenteredLine,
                maxLines = 1,
                modifier = Modifier.padding(end = 8.dp),
            )
        },
    ) {
        if (mode == AppMode.RADIO) {
            RadioBody(vm, ui)
            return@WaWindow
        }
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // KIRI: layar LCD (waktu + spectrum), lampu status, bar seek
            Column(Modifier.weight(0.85f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(
                    Modifier.fillMaxWidth().weight(1f).bevel(false, WA_LCD).padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        formatTime((shown * ui.durationMs).toLong().takeIf { drag != null } ?: ui.positionMs),
                        color = WA_GREEN,
                        fontSize = 22.sp,
                        fontFamily = MONO,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterVertically),
                    )
                    SpectrumView(ui.isPlaying, Modifier.weight(1f).fillMaxHeight())
                }
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Lamp("GRD", pal.c1, guardDb > 0.5f)
                    Lamp("NSE", pal.c2, s.noiseFilter)
                    Lamp("EQ", pal.c3, s.enabled)
                    Lamp("LIM", pal.c4, limDb > 0.5f)
                }
                WaSlider(
                    value = shown,
                    onValueChange = { drag = it },
                    range = 0f..1f,
                    onDone = {
                        drag?.let { vm.seekTo((it * ui.durationMs).toLong()) }
                        drag = null
                    },
                    modifier = Modifier.fillMaxWidth().height(14.dp),
                )
            }

            // KANAN: judul berjalan, 5 tombol transport (di tengah), acak + ulang
            Column(Modifier.weight(1.3f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                Box(
                    Modifier.fillMaxWidth().height(20.dp).bevel(false, WA_LCD).padding(horizontal = 4.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    val label = if (ui.title != null) "${ui.artist} - ${ui.title}  ***  " else "MUSIC PLAYER  ***  "
                    Text(
                        label,
                        color = WA_GREEN,
                        fontSize = 11.sp,
                        fontFamily = MONO,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE),
                    )
                }

                // sebelumnya, jeda, PUTAR (tengah, lebih besar), henti, berikutnya.
                // Kelima tombol menyala biru tua OCEAN saat ditekan; tombol sesuai status tetap menyala.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
                ) {
                    WaIconButton(Icons.Filled.SkipPrevious, "Sebelumnya", vm::previous, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3)
                    WaIconButton(Icons.Filled.Pause, "Jeda", vm::pause, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3, active = ui.isPaused)
                    WaIconButton(Icons.Filled.PlayArrow, "Putar", vm::play, buttonSize = 36.dp, iconSize = 22.dp, accent = pal.c3, active = ui.isPlaying)
                    WaIconButton(Icons.Filled.Stop, "Henti", vm::stop, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3, active = ui.isStopped)
                    WaIconButton(Icons.Filled.SkipNext, "Berikutnya", vm::next, buttonSize = 28.dp, iconSize = 16.dp, accent = pal.c3)
                }

                // Volume ada di knob besar panel bawah; di sini tinggal acak + ulang, di tengah.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
                ) {
                    // Acak (shuffle): LED menyala = aktif
                    LedToggle(Icons.Filled.Shuffle, "Acak", pal.c2, ui.shuffle, vm::toggleShuffle)
                    // Ulang: mati -> semua (LED cyan) -> 1 lagu (LED kuning)
                    LedToggle(
                        icon = if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        description = when (ui.repeatMode) {
                            Player.REPEAT_MODE_ONE -> "Ulang 1 lagu"
                            Player.REPEAT_MODE_ALL -> "Ulang semua"
                            else -> "Ulang mati"
                        },
                        ledColor = if (ui.repeatMode == Player.REPEAT_MODE_ONE) pal.c4 else pal.c1,
                        on = ui.repeatMode != Player.REPEAT_MODE_OFF,
                        onClick = vm::toggleRepeat,
                    )
                }
            }
        }
    }
}

// ================================================================== EQUALIZER 10 BAND + PREAMP

private val FREQ_LABELS = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

@Composable
private fun EqColumn(
    label: String,
    value: Float,
    enabled: Boolean,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
        WaSlider(
            value = value,
            onValueChange = onChange,
            range = -EqAudioProcessor.MAX_GAIN_DB..EqAudioProcessor.MAX_GAIN_DB,
            vertical = true,
            centered = true,
            enabled = enabled,
            thumb = 10.dp,
            modifier = Modifier.width(24.dp).weight(1f),
        )
        Text(label, color = WA_TEXT, fontSize = 8.sp, lineHeight = 9.sp, fontFamily = MONO, maxLines = 1)
    }
}

@Composable
fun EqWindow(modifier: Modifier = Modifier) {
    val s by AudioEngine.settings.collectAsState()
    WaWindow("EQUALIZER 10 BAND", modifier = modifier, fill = true, contentPadding = 3.dp) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // kiri: ON/OFF equalizer + noise filter, lalu bass boost, stereo width, power amp
            Column(Modifier.width(146.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                Row(
                    Modifier.fillMaxWidth().height(22.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    WaButton(if (s.enabled) "ON" else "OFF", { AudioEngine.update { it.copy(enabled = !it.enabled) } }, Modifier.weight(1f), active = s.enabled)
                    Led(Skin.p.c3, s.enabled)
                    WaButton("NOISE", { AudioEngine.update { it.copy(noiseFilter = !it.noiseFilter) } }, Modifier.weight(1f), active = s.noiseFilter)
                    Led(Skin.p.c2, s.noiseFilter)
                }
                ParamRow("BASS BOOST") { m ->
                    WaSlider(s.bassBoost, { v -> AudioEngine.update { it.copy(bassBoost = v) } }, 0f..1f, m)
                }
                ParamRow("STEREO WIDTH") { m ->
                    WaSlider(s.width, { v -> AudioEngine.update { it.copy(width = if (kotlin.math.abs(v - 1f) < 0.05f) 1f else v) } }, 0f..2f, m, centered = true)
                }
                ParamRow("POWER AMP") { m ->
                    WaSlider(s.ampDb, { v -> AudioEngine.update { it.copy(ampDb = (v * 2f).roundToInt() / 2f) } }, 0f..12f, m)
                }
            }
            // kanan: 11 slider (PRE + 10 band) mengisi sisa lebar dan tinggi
            Row(Modifier.weight(1f).fillMaxHeight().bevel(false, Color(0xFFC2C9D9)).padding(vertical = 1.dp, horizontal = 2.dp)) {
                EqColumn(
                    "PRE", s.preampDb, true,
                    { v -> AudioEngine.update { it.copy(preampDb = (v * 2f).roundToInt() / 2f) } },
                    Modifier.weight(1f),
                )
                Spacer(Modifier.width(4.dp))
                for (i in 0 until EqAudioProcessor.BAND_COUNT) {
                    EqColumn(
                        FREQ_LABELS[i], s.gains[i], s.enabled,
                        { v ->
                            AudioEngine.update { st ->
                                st.copy(gains = st.gains.toMutableList().also { it[i] = (v * 2f).roundToInt() / 2f })
                            }
                        },
                        Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

// ================================================================== PARAMETER (dipakai panel equalizer)

@Composable
private fun ParamRow(label: String, content: @Composable (Modifier) -> Unit) {
    Row(Modifier.fillMaxWidth().height(22.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            color = WA_TEXT,
            fontSize = 7.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.width(54.dp),
        )
        content(Modifier.weight(1f).height(16.dp))
    }
}

// ================================================================== VU METER L/R + LED METER + KNOB VOLUME

/** Level linear (0..1) -> posisi 0..1 pada skala -36..0 dB. */
private fun levelToFrac(lin: Float): Float {
    if (lin <= 0.00002f) return 0f
    return ((20f * log10(lin) + 36f) / 36f).coerceIn(0f, 1f)
}

/**
 * Level kiri/kanan (0..1) yang sudah dihaluskan: naik cepat, turun pelan.
 * Level dikalikan volume pemutar supaya meter ikut bergerak saat knob volume diputar.
 */
@Composable
private fun rememberStereoLevels(playing: Boolean, volume: Float): Pair<Float, Float> {
    val playingNow by rememberUpdatedState(playing)
    val volumeNow by rememberUpdatedState(volume)
    var levels by remember { mutableStateOf(0f to 0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 33_000_000L) continue
            last = now
            val (oldL, oldR) = levels
            if (!playingNow && oldL <= 0.002f && oldR <= 0.002f) {
                if (oldL != 0f || oldR != 0f) levels = 0f to 0f
                continue
            }
            val pr = AudioEngine.processor
            val targetL = if (playingNow) levelToFrac(pr.levelL * volumeNow) else 0f
            val targetR = if (playingNow) levelToFrac(pr.levelR * volumeNow) else 0f
            val newL = oldL + (targetL - oldL) * (if (targetL > oldL) 0.6f else 0.12f)
            val newR = oldR + (targetR - oldR) * (if (targetR > oldR) 0.6f else 0.12f)
            levels = newL to newR
        }
    }
    return levels
}

/** VU meter jarum (analog): skala 0..1, zona merah di ujung kanan. [label] = "L" atau "R". */
@Composable
private fun VuMeter(label: String, frac: Float, modifier: Modifier = Modifier) {
    Box(modifier.bevel(false, Color(0xFF081634))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val maxDeg = 55f
            val pivot = Offset(w / 2f, h - 3.dp.toPx())
            val rs = min(h - 9.dp.toPx(), w * 0.5f / sin(Math.toRadians(maxDeg.toDouble())).toFloat() * 0.95f)
            fun pt(deg: Float, rad: Float): Offset {
                val a = Math.toRadians(deg.toDouble())
                return Offset(pivot.x + rad * sin(a).toFloat(), pivot.y - rad * cos(a).toFloat())
            }

            // busur skala + zona merah
            val arcTopLeft = Offset(pivot.x - rs, pivot.y - rs)
            val arcSize = Size(rs * 2f, rs * 2f)
            drawArc(
                Color(0xFF7F9BD6), -90f - maxDeg, maxDeg * 2f, false, arcTopLeft, arcSize,
                style = Stroke(1.dp.toPx()),
            )
            drawArc(
                Color(0xFFFF5A4D), -90f - maxDeg + maxDeg * 2f * 0.8f, maxDeg * 2f * 0.2f, false, arcTopLeft, arcSize,
                style = Stroke(2.5.dp.toPx()),
            )
            // garis skala
            for (i in 0..10) {
                val f = i / 10f
                val deg = -maxDeg + f * maxDeg * 2f
                val len = if (i % 5 == 0) 0.80f else 0.88f
                drawLine(
                    if (f >= 0.8f) Color(0xFFFF5A4D) else Color(0xFFD6E2FA),
                    pt(deg, rs * len), pt(deg, rs),
                    1.dp.toPx(),
                )
            }
            // jarum + poros
            val needleDeg = -maxDeg + frac.coerceIn(0f, 1f) * maxDeg * 2f
            drawLine(Color.White, pivot, pt(needleDeg, rs * 0.97f), 1.5.dp.toPx(), StrokeCap.Round)
            drawCircle(Color(0xFFA9B3C9), 3.dp.toPx(), pivot)
        }
        Text(
            label,
            color = Color(0xFF7FEBFF),
            fontSize = 10.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            lineHeight = 11.sp,
            style = CenteredLine,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 5.dp, bottom = 3.dp),
        )
        Text(
            "VU",
            color = Color(0xFF7F9BD6),
            fontSize = 7.sp,
            fontFamily = MONO,
            lineHeight = 8.sp,
            style = CenteredLine,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 5.dp, bottom = 3.dp),
        )
    }
}

/**
 * LED meter datar. Mulai dari tengah (dekat knob volume) lalu menyala ke luar:
 * [growLeft] = true -> ke kiri (kanal L), false -> ke kanan (kanal R). Jadi L dan R bergerak berlawanan.
 */
@Composable
private fun LedMeter(frac: Float, growLeft: Boolean, modifier: Modifier = Modifier) {
    val low = Skin.p.c2
    Canvas(modifier.bevel(false, WA_LCD)) {
        val segs = 18
        val gap = 1.5.dp.toPx()
        val segW = (size.width - gap * (segs + 1)) / segs
        val lit = (frac.coerceIn(0f, 1f) * segs + 0.5f).toInt()
        for (i in 0 until segs) {
            val x = if (growLeft) size.width - gap - (i + 1) * segW - i * gap else gap + i * (segW + gap)
            val on = i < lit
            val c = when {
                i < segs * 0.6f -> low
                i < segs * 0.85f -> Color(0xFFF0B800)
                else -> Color(0xFFE82010)
            }
            drawRect(if (on) c else Color(0xFF123066), Offset(x, 2.dp.toPx()), Size(segW, size.height - 4.dp.toPx()))
        }
    }
}

@Composable
fun VuWindow(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val (levelL, levelR) = rememberStereoLevels(ui.isPlaying, ui.volume)
    val muted = ui.volume <= 0.001f

    WaWindow("VU METER", modifier = modifier, fill = true, contentPadding = 3.dp) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            // tinggi knob = tinggi panel dikurangi tulisan label di bawahnya
            val knobSize = (maxHeight - 12.dp).coerceIn(34.dp, 84.dp)
            Row(
                Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // KIRI: VU meter L + LED meter L (menyala ke kiri)
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    VuMeter("L", levelL, Modifier.fillMaxWidth().weight(1f))
                    LedMeter(levelL, growLeft = true, modifier = Modifier.fillMaxWidth().height(12.dp))
                }
                // TENGAH: knob volume besar (putar = volume, ketuk = bisu)
                RadioKnob(
                    frac = ui.volume,
                    label = if (muted) "BISU" else "VOLUME",
                    knobSize = knobSize,
                    onTurn = { d -> vm.setVolume(vm.ui.value.volume + d) },
                    onTap = vm::toggleMute,
                )
                // KANAN: VU meter R + LED meter R (menyala ke kanan)
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    VuMeter("R", levelR, Modifier.fillMaxWidth().weight(1f))
                    LedMeter(levelR, growLeft = false, modifier = Modifier.fillMaxWidth().height(12.dp))
                }
            }
        }
    }
}
