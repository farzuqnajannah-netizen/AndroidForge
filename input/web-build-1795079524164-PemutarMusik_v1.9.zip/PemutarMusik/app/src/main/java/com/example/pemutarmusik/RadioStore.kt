package com.example.pemutarmusik

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Mode aplikasi: pemutar file MP3 atau radio streaming. */
enum class AppMode { MP3, RADIO }

/** Stasiun radio. [freq] = frekuensi FM dalam MHz (boleh kosong), mis. "99.5". [url] = alamat stream audio. */
data class RadioStation(val id: Long, val name: String, val freq: String, val url: String)

/** Frekuensi FM sebagai angka (MHz), null kalau belum diisi / tidak valid. */
val RadioStation.freqValue: Float? get() = freq.replace(',', '.').toFloatOrNull()

/** Urut dari frekuensi terkecil; stasiun tanpa frekuensi ditaruh paling bawah (urut nama). */
fun sortByFreq(list: List<RadioStation>): List<RadioStation> =
    list.sortedWith(
        compareBy<RadioStation>({ it.freqValue == null }, { it.freqValue ?: 0f }, { it.name.lowercase() })
    )

/** Penyimpanan stasiun radio + mode terakhir di SharedPreferences. */
object RadioStore {
    private const val PREFS = "radio"
    private const val KEY_STATIONS = "stations"
    private const val KEY_RADIO_MODE = "radio_mode"
    private const val KEY_LAST = "last_station"

    private const val KEY_SEED = "seed_version"
    private const val SEED_VERSION = 2

    /** Stasiun bawaan: [key] dipakai mencocokkan dengan stasiun yang sudah ada saat pembaruan. */
    private data class Seed(val key: String, val name: String, val freq: String, val url: String)

    /**
     * Stasiun bawaan dari aplikasi "Radio Online Tegal" (alamat stream asli dari aplikasi itu).
     * Frekuensi dari direktori radio Streema; Shahabat tidak punya frekuensi FM yang ditemukan (kosong).
     * Semuanya bisa diedit (nama, frekuensi, URL) lewat tombol pensil di daftar stasiun.
     */
    private val SEEDS = listOf(
        Seed("shahabat", "Shahabat", "", "http://streaming.girifm.com:8010/;stream.nsv?type=.mp3/;stream.mp3&autostart=1"),
        Seed("roshinta", "Roshinta FM", "100.7", "http://103.28.148.18:8722/;"),
        Seed("slawi", "Slawi FM", "99.3", "http://103.28.148.18/9032/;"),
        Seed("sebayu", "Sebayu FM", "94.0", "https://radio-streaming.tegalkota.go.id/stream.mp3;169.217/"),
        Seed("sananta", "Sananta FM", "105.8", "http://i.klikhost.com:8500/;"),
        Seed("radar", "Radar CBS FM", "104.4", "http://live.radarcbs.com:8000/radarcbs_stereo"),
        Seed("gama", "Gama FM", "90.0", "https://svara-stream.radioddns.net:8443/tegal_gamafm_stereo"),
        Seed("elshinta", "Elshinta", "99.9", "http://202.137.4.147:8040/"),
        Seed("anita", "Anita FM", "106.6", "http://103.28.148.18:9620/"),
    )

    /** Alamat bawaan versi lama; kalau stasiun masih memakainya (belum diedit pengguna), diganti ke alamat stream baru. */
    private val OLD_DEFAULT_URLS = setOf(
        "https://radio-streaming.tegalkota.go.id/stream/1/",
        "https://slawifm.id/",
        "https://streaming.sanantafm.com/",
        "https://stream-ssl.arenastreaming.com:8000/jakarta",
    )

    fun defaults(): List<RadioStation> = sortByFreq(
        SEEDS.mapIndexed { i, sd -> RadioStation(i + 1L, sd.name, sd.freq, sd.url) }
    )

    /** Tambahkan stasiun bawaan baru ke daftar lama tanpa menghapus/menimpa hasil edit pengguna. */
    private fun migrate(list: List<RadioStation>): List<RadioStation> {
        val out = list.toMutableList()
        var nextId = (list.maxOfOrNull { it.id } ?: 0L) + 1
        for (sd in SEEDS) {
            val i = out.indexOfFirst { it.name.contains(sd.key, ignoreCase = true) }
            if (i < 0) {
                out += RadioStation(nextId++, sd.name, sd.freq, sd.url)
            } else {
                val cur = out[i]
                if (cur.url in OLD_DEFAULT_URLS) out[i] = cur.copy(url = sd.url, freq = cur.freq.ifBlank { sd.freq })
            }
        }
        return out
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context): List<RadioStation> {
        val raw = prefs(context).getString(KEY_STATIONS, null) ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            val list = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                RadioStation(o.getLong("id"), o.getString("name"), o.optString("freq", ""), o.getString("url"))
            }
            if (prefs(context).getInt(KEY_SEED, 0) >= SEED_VERSION) {
                sortByFreq(list)
            } else {
                sortByFreq(migrate(list)).also { save(context, it) }
            }
        } catch (e: Exception) {
            defaults()
        }
    }

    fun save(context: Context, stations: List<RadioStation>) {
        val arr = JSONArray()
        for (s in stations) {
            arr.put(JSONObject().put("id", s.id).put("name", s.name).put("freq", s.freq).put("url", s.url))
        }
        prefs(context).edit().putString(KEY_STATIONS, arr.toString()).putInt(KEY_SEED, SEED_VERSION).apply()
    }

    fun isRadioMode(context: Context): Boolean = prefs(context).getBoolean(KEY_RADIO_MODE, false)

    fun setRadioMode(context: Context, radio: Boolean) {
        prefs(context).edit().putBoolean(KEY_RADIO_MODE, radio).apply()
    }

    /** Stasiun terakhir dipilih, null kalau belum ada. */
    fun lastStation(context: Context): Long? =
        prefs(context).getLong(KEY_LAST, -1L).takeIf { it >= 0 }

    fun setLastStation(context: Context, id: Long?) {
        prefs(context).edit().putLong(KEY_LAST, id ?: -1L).apply()
    }
}
