package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.SpectrumAnalyzer
import android.content.Context
import kotlin.math.max

// ------------------------------------------------------------------ skin "Ocean Blue" (logam perak + LCD biru)

val WA_DESK = Color(0xFF0A1530)          // latar aplikasi
val WA_SILVER_HI = Color(0xFFE6EAF2)     // perak terang (atas)
val WA_SILVER_LO = Color(0xFF9AA4BA)     // perak gelap (bawah)
val WA_PANEL = Color(0xFFB5BDCC)         // penanda panel perak (dipakai bevel)
val WA_BORDER = Color(0xFF16244A)        // garis tepi biru tua
val WA_HI = Color(0xFFF4F7FC)
val WA_LO = Color(0xFF16244A)
val WA_INK = Color(0xFF1B2A55)           // teks gelap di atas perak
val WA_TEXT = WA_INK
val WA_LCD = Color(0xFF173E86)           // layar LCD / playlist biru
val WA_LCD_DARK = Color(0xFF0F2C66)
val WA_GREEN = Color(0xFFEAF2FF)         // teks terang di layar biru (nama lama dipertahankan)
val WA_GREEN_DIM = Color(0xFF6F8CC8)     // teks redup di layar biru
val WA_LAMP_ON = Color(0xFF1F5BE0)       // lampu menyala di atas perak
val WA_LAMP_OFF = Color(0xFF7B879F)
val WA_BLUE = Color(0xFF2C5FC8)          // tombol aktif
val WA_GROOVE = Color(0xFF26314F)
val WA_SEL = Color(0xFF6F8FD0)           // baris playlist terpilih
val MONO = FontFamily.Monospace

// ------------------------------------------------------------------ variasi warna lampu LED

class LedPalette(
    val name: String,
    val c1: Color, val c2: Color, val c3: Color, val c4: Color,
    val specLow: Color, val specHigh: Color,
)

/** 3 pilihan warna lampu: OCEAN (biru/cyan), AURORA (hijau/kuning), SUNSET (oranye/pink/ungu). */
object Skin {
    // Skin permanen: OCEAN (pilihan ganti skin dihapus)
    val palettes = listOf(
        LedPalette("OCEAN", Color(0xFF35E0FF), Color(0xFF4DFF9A), Color(0xFF4D8DFF), Color(0xFFFFC24D), Color(0xFF5E9BFF), Color(0xFFFFFFFF)),
    )
    val p: LedPalette get() = palettes[0]

    @Suppress("UNUSED_PARAMETER")
    fun init(context: Context) {
        // tidak ada yang perlu dimuat: skin selalu OCEAN
    }
}

/** Lampu LED bulat dengan efek cahaya (glow) saat menyala. */
@Composable
fun Led(color: Color, on: Boolean, modifier: Modifier = Modifier, diameter: Dp = 9.dp) {
    Canvas(modifier.size(diameter + 6.dp)) {
        val c = center
        val r = diameter.toPx() / 2f
        if (on) {
            drawCircle(
                Brush.radialGradient(listOf(color.copy(alpha = 0.55f), Color.Transparent), c, r * 2.3f),
                radius = r * 2.3f,
                center = c,
            )
            drawCircle(
                Brush.radialGradient(listOf(Color.White, color, color.copy(alpha = 0.75f)), c - Offset(r * 0.25f, r * 0.25f), r * 1.2f),
                radius = r,
                center = c,
            )
        } else {
            drawCircle(
                Brush.radialGradient(listOf(color.copy(alpha = 0.35f), Color(0xFF152046)), c, r),
                radius = r,
                center = c,
            )
        }
        drawCircle(WA_BORDER, radius = r, center = c, style = Stroke(1.dp.toPx()))
    }
}

/** Panel logam (raised) atau cekung (inset), sudut membulat. */
fun Modifier.bevel(raised: Boolean = true, fill: Color = WA_PANEL, radius: Dp = 3.dp): Modifier = this.drawBehind {
    val r = CornerRadius(radius.toPx())
    if (raised && fill == WA_PANEL) {
        drawRoundRect(Brush.verticalGradient(listOf(WA_SILVER_HI, WA_SILVER_LO)), cornerRadius = r)
    } else {
        drawRoundRect(fill, cornerRadius = r)
    }
    val t = 1.dp.toPx()
    drawRoundRect(
        color = if (raised) WA_BORDER else Color(0x66FFFFFF),
        topLeft = Offset(t / 2, t / 2),
        size = Size(size.width - t, size.height - t),
        cornerRadius = r,
        style = Stroke(t),
    )
}

// ------------------------------------------------------------------ jendela

@Composable
fun WaWindow(
    title: String,
    modifier: Modifier = Modifier,
    fill: Boolean = false,
    contentPadding: Dp = 5.dp,
    actions: (@Composable androidx.compose.foundation.layout.RowScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .bevel(true, WA_PANEL, 8.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(17.dp)
                .background(Brush.verticalGradient(listOf(Color(0xFF3F61A8), Color(0xFF1A2A5E))))
                .padding(start = 4.dp, end = if (actions != null) 0.dp else 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Stripes(Modifier.weight(1f))
            Text(
                title,
                color = Color(0xFFC9D3EA),
                fontSize = 10.sp,
                fontFamily = MONO,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(horizontal = 7.dp),
            )
            Stripes(Modifier.weight(1f))
            actions?.invoke(this)
        }
        val inner = if (fill) Modifier.weight(1f) else Modifier
        Column(inner.padding(contentPadding), content = content)
    }
}

/** Tombol kecil di baris judul jendela (minimize "–" / tutup "×"). Area sentuh selebar 30dp setinggi baris judul. */
@Composable
fun WaTitleButton(label: String, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .width(30.dp)
            .fillMaxHeight()
            .semantics { contentDescription = description }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(width = 22.dp, height = 13.dp)
                .background(Brush.verticalGradient(listOf(WA_SILVER_HI, WA_SILVER_LO)), RoundedCornerShape(3.dp))
                .border(1.dp, WA_BORDER, RoundedCornerShape(3.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text(label, color = WA_INK, fontSize = 10.sp, fontFamily = MONO, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Stripes(modifier: Modifier) {
    Canvas(modifier.height(11.dp)) {
        for (y in listOf(2.dp, 5.dp, 8.dp)) {
            val py = y.toPx()
            drawLine(Color(0x66C9D3EA), Offset(0f, py), Offset(size.width, py), strokeWidth = 1.dp.toPx())
        }
    }
}

// ------------------------------------------------------------------ tombol

/** Tombol pil: biru + teks putih saat aktif, perak + teks biru tua saat tidak. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WaButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    onLongClick: (() -> Unit)? = null,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val lit = active || pressed
    Box(
        modifier
            .height(22.dp)
            .bevel(!lit, if (pressed) Skin.p.c3 else if (active) WA_BLUE else WA_PANEL, 11.dp)
            .combinedClickable(interactionSource = source, indication = null, onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontSize = 9.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            color = if (lit) Color.White else WA_INK,
        )
    }
}

/** Tombol transport bulat perak dengan ikon hitam. */
@Composable
fun WaIconButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    buttonSize: Dp = 34.dp,
    iconSize: Dp = 18.dp,
    accent: Color = Skin.p.c3,
    active: Boolean = false,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val c = accent
    val lit = pressed || active
    val fill = if (lit) listOf(lerp(c, Color.White, 0.35f), c) else listOf(WA_SILVER_HI, WA_SILVER_LO)
    Box(
        modifier
            .size(buttonSize)
            .background(Brush.verticalGradient(fill), CircleShape)
            .border(1.5.dp, WA_BORDER, CircleShape)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = description,
            tint = if (lit) Color.White else Color(0xFF0B1330),
            modifier = Modifier.size(iconSize),
        )
    }
}

// ------------------------------------------------------------------ slider

/**
 * Slider gaya perak: alur gelap, gagang perak membulat.
 * centered = true: isi warna dari titik tengah (dipakai untuk EQ +/- dB).
 */
@Composable
fun WaSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    vertical: Boolean = false,
    centered: Boolean = false,
    enabled: Boolean = true,
    onDone: () -> Unit = {},
    thumb: Dp = 14.dp,
) {
    val change by rememberUpdatedState(onValueChange)
    val done by rememberUpdatedState(onDone)

    Canvas(
        modifier.pointerInput(enabled, vertical, range) {
            if (!enabled) return@pointerInput
            val pad = thumb.toPx() / 2f
            fun update(p: Offset) {
                val len = (if (vertical) size.height else size.width).toFloat()
                val pos = if (vertical) p.y else p.x
                var frac = ((pos - pad) / max(len - 2 * pad, 1f)).coerceIn(0f, 1f)
                if (vertical) frac = 1f - frac
                change(range.start + frac * (range.endInclusive - range.start))
            }
            awaitEachGesture {
                val down = awaitFirstDown()
                update(down.position)
                down.consume()
                drag(down.id) {
                    update(it.position)
                    it.consume()
                }
                done()
            }
        }
    ) {
        val pad = thumb.toPx() / 2f
        val grooveW = 5.dp.toPx()
        val frac = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
        val len = if (vertical) size.height else size.width
        val cross = if (vertical) size.width else size.height
        val track = len - 2 * pad
        val pos = pad + (if (vertical) (1f - frac) else frac) * track
        val centerPos = pad + track / 2f
        val gTop = (cross - grooveW) / 2f
        val rad = CornerRadius(grooveW / 2f)

        // alur gelap
        if (vertical) drawRoundRect(WA_GROOVE, Offset(gTop, pad), Size(grooveW, track), rad)
        else drawRoundRect(WA_GROOVE, Offset(pad, gTop), Size(track, grooveW), rad)

        // isi warna (biru; mendekati ujung berubah kuning/merah sebagai peringatan clipping)
        val a = if (centered) centerPos else (if (vertical) pad + track else pad)
        val lo = minOf(a, pos)
        val hi = maxOf(a, pos)
        val dev = if (centered) kotlin.math.abs(frac - 0.5f) * 2f else frac * 0.6f
        var fillColor = if (!enabled) Color(0xFF3A4766) else Skin.p.c3
        if (enabled && dev > 0.6f) fillColor = lerp(fillColor, Color(0xFFFFB020), ((dev - 0.6f) * 2.5f).coerceIn(0f, 1f))
        if (enabled && dev > 0.85f) fillColor = lerp(fillColor, Color(0xFFFF4020), ((dev - 0.85f) * 6.6f).coerceIn(0f, 1f))
        if (vertical) drawRoundRect(fillColor, Offset(gTop, lo), Size(grooveW, hi - lo), rad)
        else drawRoundRect(fillColor, Offset(lo, gTop), Size(hi - lo, grooveW), rad)

        // garis tengah
        if (centered) {
            val tick = Color(0x99FFFFFF)
            if (vertical) drawLine(tick, Offset(0f, centerPos), Offset(size.width, centerPos), 1.dp.toPx())
            else drawLine(tick, Offset(centerPos, 0f), Offset(centerPos, size.height), 1.dp.toPx())
        }

        // gagang perak membulat
        val tw = thumb.toPx()
        val topLeft = if (vertical) Offset(1.dp.toPx(), pos - tw / 2f) else Offset(pos - tw / 2f, 1.dp.toPx())
        val sz = if (vertical) Size(size.width - 2.dp.toPx(), tw) else Size(tw, size.height - 2.dp.toPx())
        val corner = CornerRadius(4.dp.toPx())
        val body = if (enabled) listOf(Color(0xFFF1F4FA), Color(0xFFA9B3C9)) else listOf(Color(0xFF8D97AB), Color(0xFF677189))
        drawRoundRect(Brush.verticalGradient(body, startY = topLeft.y, endY = topLeft.y + sz.height), topLeft, sz, corner)
        drawRoundRect(WA_BORDER, topLeft, sz, corner, style = Stroke(1.dp.toPx()))
        if (vertical) {
            drawLine(Color(0xFF55607E), Offset(topLeft.x + 3.dp.toPx(), pos), Offset(topLeft.x + sz.width - 3.dp.toPx(), pos), 1.dp.toPx())
        } else {
            drawLine(Color(0xFF55607E), Offset(pos, topLeft.y + 3.dp.toPx()), Offset(pos, topLeft.y + sz.height - 3.dp.toPx()), 1.dp.toPx())
        }
    }
}

// ------------------------------------------------------------------ spectrum analyzer

@Composable
fun SpectrumView(playing: Boolean, modifier: Modifier = Modifier) {
    val analyzer = remember { SpectrumAnalyzer(AudioEngine.processor) }
    val bars0 = SpectrumAnalyzer.BARS
    var bars by remember { mutableStateOf(FloatArray(bars0)) }
    val peaks = remember { FloatArray(bars0) }
    val playingNow by rememberUpdatedState(playing)

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 30_000_000L) continue
            last = now
            val old = bars
            val idle = !playingNow && old.all { it <= 0f } && peaks.all { it <= 0f }
            if (idle) continue
            val fresh = if (playingNow) analyzer.compute() else FloatArray(bars0)
            val next = FloatArray(bars0) { i -> max(fresh[i], old[i] - 0.07f) }
            for (i in 0 until bars0) peaks[i] = max(next[i], max(peaks[i] - 0.015f, 0f))
            bars = next
        }
    }

    Canvas(modifier) {
        val b = bars
        val n = b.size
        val gap = 1.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        val segs = 14
        val segH = size.height / segs
        for (i in 0 until n) {
            val x = i * (w + gap)
            val lit = (b[i] * segs).toInt()
            for (s in 0 until lit) {
                val t = s / (segs - 1f)
                val color = lerp(Skin.p.specLow, Skin.p.specHigh, t)
                val y = size.height - (s + 1) * segH
                drawRect(color, Offset(x, y + 0.5f), Size(w, segH - 1f))
            }
            val pk = (peaks[i] * segs).toInt().coerceIn(0, segs - 1)
            if (peaks[i] > 0.02f) {
                val y = size.height - (pk + 1) * segH
                drawRect(Skin.p.specHigh, Offset(x, y + 0.5f), Size(w, segH - 1f))
            }
        }
    }
}
