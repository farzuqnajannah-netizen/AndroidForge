# Kipas Gantung Mini – Proyek Android (Gradle)

Versi saat ini: lihat `version.properties` (lihat nilai terbaru di file itu).

## Cara membuat update (tanpa uninstal)
1. Ubah game di `app/src/main/assets/index.html`.
2. Naikkan `versionCode` di `version.properties` (1 -> 2 -> 3 ...) dan ubah `versionName` (1.0 -> 1.1 ...).
3. Build ulang, lalu instal APK baru di atas yang lama.

Syarat agar update bisa menimpa:
- `applicationId` tetap `com.kipasgantung.mini`
- `versionCode` lebih besar dari yang terpasang
- file kunci `app/kipas-release.keystore` TETAP SAMA (simpan cadangannya!)

Build: `gradle assembleDebug` atau `gradle assembleRelease` (minSdk 24, AGP 8.5.2, Gradle 8.9+, JDK 17).
