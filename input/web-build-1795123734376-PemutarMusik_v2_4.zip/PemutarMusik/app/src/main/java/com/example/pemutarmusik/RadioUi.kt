package com.example.pemutarmusik

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import kotlin.math.roundToInt
import com.example.pemutarmusik.audio.AudioEngine
import java.util.Locale
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.focus.onFocusEvent
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

// ================================================================== RADIO VINTAGE (isi jendela player)

private const val RADIO_MIN_F = 87.5f
private const val RADIO_MAX_F = 108f
private val RadioText: Color get() = Skin.t.radioText      // teks terang di atas biru tua
private val RadioTextDim: Color get() = Skin.t.radioTextDim   // teks redup
private val RadioCyan: Color get() = Skin.p.c1      // skala / penanda aktif

/**
 * Isi jendela player saat mode RADIO, bergaya radio vintage (badan biru, trim perak):
 *  - (volume: knob besar di panel VU METER bawah)
 *  - kiri  : layar DIGITAL (nama stasiun + frekuensi + grafik meter saat live) dan tombol prev / play / next
 *  - kanan : tombol TUNING = pindah ke frekuensi (stasiun) berikutnya
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RadioBody(vm: PlayerViewModel, ui: PlayerUi) {
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val error by vm.radioError.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val pal = Skin.p
    val station = stations.firstOrNull { it.id == stationId }

    val stopped = ui.playbackState == Player.STATE_IDLE || ui.playbackState == Player.STATE_ENDED
    val connecting = !stopped && ui.playWhenReady && ui.playbackState == Player.STATE_BUFFERING
    val playing = ui.isPlaying
    val paused = !stopped && !playing && !connecting

    val freq = station?.freqValue
    val freqText = freq?.let { String.format(Locale.US, "%.1f", it) } ?: "--.-"
    // Judul lagu dari stream (ICY) kalau ada; kalau sama dengan nama stasiun, abaikan
    val onAir = if (station != null && ui.mediaId == "radio:${station.id}") ui.title?.takeIf { it != station.name } else null

    // Posisi knob TUNING mengikuti frekuensi stasiun yang sedang dipilih (bergeser halus)
    val tuneFrac by animateFloatAsState(
        targetValue = (((freq ?: RADIO_MIN_F) - RADIO_MIN_F) / (RADIO_MAX_F - RADIO_MIN_F)).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "tune",
    )

    val bodyShape = RoundedCornerShape(10.dp)
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .clip(bodyShape)
            .background(Brush.verticalGradient(Skin.t.radioBody))
            .border(1.5.dp, Skin.t.radioBodyEdge, bodyShape)
    ) {
        val knobSize = (maxHeight - 8.dp - 11.dp).coerceIn(34.dp, 70.dp)

        Row(
            Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // ---------------- TENGAH: layar digital + tombol
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                val dispShape = RoundedCornerShape(5.dp)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(dispShape)
                        .background(Brush.verticalGradient(Skin.t.radioDisp))
                        .border(1.dp, Skin.t.radioDispEdge, dispShape)
                ) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 3.dp)) {
                        // BARIS ATAS: nama stasiun (berjalan) + frekuensi digital
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            val label = when {
                                error != null -> "! $error   "
                                station == null -> "PILIH STASIUN  ***  "
                                onAir != null -> "${station.name} - $onAir  ***  "
                                else -> "${station.name}  ***  "
                            }
                            Text(
                                label,
                                color = if (error != null) Color(0xFFFF9E94) else Color.White,
                                fontSize = 12.sp,
                                fontFamily = MONO,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 14.sp,
                                maxLines = 1,
                                softWrap = false,
                                style = CenteredLine,
                                modifier = Modifier.weight(1f).basicMarquee(iterations = Int.MAX_VALUE),
                            )
                            Spacer(Modifier.width(6.dp))
                            // angka digital: "88.8" redup di belakang = efek segmen LCD
                            Box(contentAlignment = Alignment.CenterEnd) {
                                Text("888.8", color = RadioCyan.copy(alpha = 0.10f), fontSize = 21.sp, fontFamily = MONO, fontWeight = FontWeight.Bold, lineHeight = 22.sp, maxLines = 1, style = CenteredLine)
                                Text(freqText, color = RadioCyan, fontSize = 21.sp, fontFamily = MONO, fontWeight = FontWeight.Bold, lineHeight = 22.sp, maxLines = 1, style = CenteredLine)
                            }
                            Spacer(Modifier.width(3.dp))
                            Column(verticalArrangement = Arrangement.Center) {
                                Text("FM", color = Color.White, fontSize = 8.sp, fontFamily = MONO, fontWeight = FontWeight.Bold, lineHeight = 9.sp, style = CenteredLine)
                                Text("MHz", color = RadioTextDim, fontSize = 7.sp, fontFamily = MONO, lineHeight = 8.sp, style = CenteredLine)
                            }
                        }
                        Spacer(Modifier.height(2.dp))
                        // BARIS BAWAH: status + grafik meter (muncul saat live)
                        Row(Modifier.fillMaxWidth().weight(1f), verticalAlignment = Alignment.Bottom) {
                            val (statusText, statusColor) = when {
                                error != null -> "ERROR" to Color(0xFFFF9E94)
                                scanning -> "SCAN..." to RadioCyan
                                connecting -> "MENYAMBUNG" to RadioCyan
                                playing -> "ON AIR" to pal.c2
                                paused -> "JEDA" to RadioTextDim
                                else -> "STOP" to RadioTextDim
                            }
                            Text(
                                statusText,
                                color = statusColor,
                                fontSize = 8.sp,
                                fontFamily = MONO,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 9.sp,
                                maxLines = 1,
                                style = CenteredLine,
                                modifier = Modifier.width(58.dp),
                            )
                            SpectrumView(playing, Modifier.weight(1f).fillMaxHeight())
                        }
                    }
                }

                // BAWAH: prev, play, next (+ SCAN dan SLEEP kecil di sisi)
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp, Alignment.CenterHorizontally),
                ) {
                    WaButton("SCAN", vm::toggleScan, active = scanning)
                    // stasiun sebelumnya = frekuensi lebih rendah, berikutnya = lebih tinggi
                    WaIconButton(Icons.Filled.SkipPrevious, "Stasiun sebelumnya", { vm.stepStation(-1) }, buttonSize = 28.dp, iconSize = 17.dp, accent = pal.c3)
                    val on = playing || connecting
                    WaIconButton(
                        if (on) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        if (on) "Jeda" else "Putar",
                        { if (on) vm.radioPause() else vm.radioPlay() },
                        buttonSize = 34.dp, iconSize = 22.dp, accent = pal.c3, active = on,
                    )
                    WaIconButton(Icons.Filled.SkipNext, "Stasiun berikutnya", { vm.stepStation(+1) }, buttonSize = 28.dp, iconSize = 17.dp, accent = pal.c3)
                    WaButton(if (sleepLeft > 0) "SLEEP ${sleepLeft}M" else "SLEEP", vm::cycleSleep, active = sleepLeft > 0)
                }
            }

            // ---------------- KANAN: tombol TUNING = frekuensi (stasiun) berikutnya, ketuk saja
            RadioKnob(
                frac = tuneFrac,
                label = "TUNING",
                knobSize = knobSize,
                onTap = { vm.stepStation(+1) },
            )
        }
    }
}

/**
 * Knob putar 3D (badan logam biru bergerigi, tutup perak berkilau, penunjuk biru) dengan skala titik bercahaya.
 * Putar dengan jari melingkar searah jarum jam = naik. [frac] 0..1 = posisi knob (sapuan 270 derajat).
 * [onTurn] (opsional) menerima perubahan pecahan (-1..1) tiap gerakan; kalau null knob tidak bisa diputar.
 * [onTap] opsional (mis. bisu, atau pindah ke stasiun berikutnya).
 * [labelInside] = true: tulisan ditaruh di celah bawah knob (tidak memakan tinggi), supaya knob bisa sebesar mungkin.
 */
@Composable
internal fun RadioKnob(
    frac: Float,
    label: String,
    knobSize: Dp,
    modifier: Modifier = Modifier,
    onTurn: ((Float) -> Unit)? = null,
    onTurnEnd: () -> Unit = {},
    onTap: (() -> Unit)? = null,
    labelInside: Boolean = false,
    showLabel: Boolean = true,
    tickLit: Color = RadioCyan,
    tickOff: Color = Skin.t.knobTickOff,
    accent: Color = RadioCyan,
    capVu: Boolean = false,
) {
    val turn by rememberUpdatedState(onTurn)
    val turnEnd by rememberUpdatedState(onTurnEnd)
    val tap by rememberUpdatedState(onTap)
    val sweep = 270f * PI.toFloat() / 180f

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(knobSize), contentAlignment = Alignment.BottomCenter) {
        Canvas(
            Modifier
                .fillMaxSize()
                .semantics { contentDescription = label }
                .pointerInput(Unit) { detectTapGestures(onTap = { tap?.invoke() }) }
                .then(if (onTurn == null) Modifier else Modifier.pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = { turnEnd() },
                        onDragCancel = { turnEnd() },
                    ) { change, _ ->
                        change.consume()
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val a = change.previousPosition - c
                        val b = change.position - c
                        if (a.getDistance() > 4f && b.getDistance() > 4f) {
                            val cross = a.x * b.y - a.y * b.x
                            val dot = a.x * b.x + a.y * b.y
                            turn?.invoke(atan2(cross, dot) / sweep)
                        }
                    }
                })
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val c = Offset(cx, cy)
            val r = size.minDimension / 2f
            val f = frac.coerceIn(0f, 1f)
            val knobDeg = -135f + f * 270f
            fun pt(deg: Float, rad: Float): Offset {
                val a = Math.toRadians((deg - 90f).toDouble())
                return Offset(cx + (rad * cos(a)).toFloat(), cy + (rad * sin(a)).toFloat())
            }
            val dp1 = 1.dp.toPx()

            // skala titik bercahaya: menyala cyan sampai posisi knob (21 garis, tiap 2 garis = garis panjang)
            for (i in 0..20) {
                val deg = -135f + i * 13.5f
                val lit = i / 20f <= f + 0.001f
                val major = i % 2 == 0
                val inner = if (major) 0.86f else 0.90f
                if (lit) {
                    drawLine(tickLit.copy(alpha = 0.30f), pt(deg, r * inner), pt(deg, r * 0.99f), 4.dp.toPx(), StrokeCap.Round)
                }
                drawLine(
                    if (lit) tickLit else tickOff,
                    pt(deg, r * inner), pt(deg, r * 0.98f),
                    if (major) 1.8.dp.toPx() else 1.2.dp.toPx(), StrokeCap.Round,
                )
            }

            val rb = r * 0.80f
            // bayangan jatuh (lembut + inti)
            drawCircle(
                Brush.radialGradient(listOf(Color(0x99000000), Color(0x00000000)), c + Offset(0f, rb * 0.10f), rb * 1.28f),
                rb * 1.28f, c + Offset(0f, rb * 0.10f),
            )
            drawCircle(Color(0x88000000), rb + 0.5.dp.toPx(), c + Offset(0f, rb * 0.05f))

            // badan knob: logam biru (sapuan kerucut) + gelap ke tepi
            drawCircle(
                Brush.sweepGradient(
                    Skin.t.knobBody,
                    c,
                ),
                rb, c,
            )
            drawCircle(Brush.radialGradient(listOf(Color(0x00000000), Color(0x77000000)), c, rb), rb, c)
            // gerigi yang ikut berputar (garis gelap + pantulan terang)
            val teeth = 36
            for (i in 0 until teeth) {
                val deg = knobDeg + i * (360f / teeth)
                drawLine(Color(0xCC111C3F), pt(deg, rb * 0.87f), pt(deg, rb * 0.99f), 1.3.dp.toPx())
                drawLine(Color(0x44FFFFFF), pt(deg + 3f, rb * 0.87f), pt(deg + 3f, rb * 0.99f), 0.8.dp.toPx())
            }
            // tepi: terang di atas, gelap di bawah
            drawCircle(
                Brush.verticalGradient(listOf(Color(0xCCFFFFFF), Color(0x22FFFFFF), Color(0xCC060C20)), cy - rb, cy + rb),
                rb, c, style = Stroke(1.6.dp.toPx()),
            )
            drawCircle(WA_BORDER, rb + 0.6.dp.toPx(), c, style = Stroke(1.dp.toPx()))

            // tutup perak (cekung/dish) + bayangan di sekelilingnya
            val rc = rb * 0.70f
            drawCircle(Color(0x88000000), rc + 1.2.dp.toPx(), c + Offset(0f, dp1))
            drawCircle(
                Brush.sweepGradient(
                    if (capVu) Skin.t.knobCapVu else Skin.t.knobCap,
                    c,
                ),
                rc, c,
            )
            // alur halus melingkar (efek logam bubut)
            for (k in listOf(0.86f, 0.72f, 0.58f, 0.44f)) {
                drawCircle(Color(0x2216244A), rc * k, c, style = Stroke(0.7.dp.toPx()))
            }
            // kilap cahaya dari kiri atas
            drawCircle(
                Brush.radialGradient(
                    listOf(if (capVu || Skin.t.dark) Color(0x66FFFFFF) else Color(0xAAFFFFFF), Color(0x00FFFFFF)),
                    c + Offset(-rc * 0.34f, -rc * 0.40f), rc * 0.95f,
                ),
                rc, c,
            )
            drawCircle(WA_BORDER, rc, c, style = Stroke(1.dp.toPx()))
            drawCircle(Color(0x99FFFFFF), rc - 1.2.dp.toPx(), c, style = Stroke(0.8.dp.toPx()))

            // penunjuk: garis gelap beralur + titik cyan bercahaya di ujung
            drawLine(Color(if (capVu || Skin.t.dark) 0x55000000 else 0x55FFFFFF), pt(knobDeg, rc * 0.22f) + Offset(0f, dp1 * 0.8f), pt(knobDeg, rc * 0.92f) + Offset(0f, dp1 * 0.8f), 2.6.dp.toPx(), StrokeCap.Round)
            drawLine(if (capVu) Skin.t.knobPointerVu else Skin.t.knobPointer, pt(knobDeg, rc * 0.22f), pt(knobDeg, rc * 0.92f), 2.6.dp.toPx(), StrokeCap.Round)
            val tip = pt(knobDeg, rc * 0.80f)
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.7f), Color.Transparent), tip, 5.dp.toPx()), 5.dp.toPx(), tip)
            drawCircle(accent, 1.8.dp.toPx(), tip)
        }
        if (showLabel && labelInside) {
            Text(
                label,
                color = RadioText,
                fontSize = 7.sp,
                fontFamily = MONO,
                fontWeight = FontWeight.Bold,
                lineHeight = 8.sp,
                maxLines = 1,
                style = CenteredLine,
            )
        }
        }
        if (showLabel && !labelInside) {
            Text(
                label,
                color = RadioText,
                fontSize = 7.sp,
                fontFamily = MONO,
                fontWeight = FontWeight.Bold,
                lineHeight = 9.sp,
                maxLines = 1,
                style = CenteredLine,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
    }
}

// ================================================================== DAFTAR STASIUN (jendela kanan)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RadioListWindow(
    vm: PlayerViewModel,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val titleH = rememberTitleBarHeight()
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val ui by vm.ui.collectAsState()
    val pal = Skin.p

    var editing by remember { mutableStateOf<RadioStation?>(null) }
    var adding by remember { mutableStateOf(false) }

    WaWindow(
        "STASIUN RADIO", modifier, fill = true,
        titleHeight = titleH,
        actions = {
            SkinButton(titleH)
            WaTitleButton(false, "Kecilkan ke mini player", titleH, onMinimize)
            WaTitleButton(true, "Tutup aplikasi", titleH, onClose)
        },
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().bevel(false, WA_LCD)) {
            if (stations.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Belum ada stasiun.\nTekan + STASIUN untuk menambah.",
                        color = WA_GREEN, fontSize = 11.sp, fontFamily = MONO, textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(stations, key = { it.id }) { st ->
                        val isCurrent = st.id == stationId
                        val live = isCurrent && ui.isPlaying
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(if (isCurrent) WA_SEL else Color.Transparent)
                                .clickable { vm.playStation(st) }
                                .padding(start = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                if (live) "▶" else " ",
                                color = if (isCurrent) Color.White else pal.c1,
                                fontSize = 11.sp, fontFamily = MONO,
                                modifier = Modifier.width(14.dp),
                            )
                            Text(
                                st.freq.ifBlank { "--.-" },
                                color = if (isCurrent) Color.White else pal.c1,
                                fontSize = 13.sp, fontFamily = MONO, fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(52.dp),
                            )
                            Text(
                                st.name,
                                color = if (isCurrent) Color.White else WA_GREEN,
                                fontSize = 13.sp, fontFamily = MONO,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            Box(
                                Modifier.size(38.dp).clickable { editing = st },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    Icons.Filled.Edit, "Edit stasiun",
                                    tint = if (isCurrent) Color.White else WA_GREEN_DIM,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "${stations.size} STASIUN  -  urut frekuensi  -  ketuk = putar",
                color = WA_INK, fontSize = 9.sp, fontFamily = MONO, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            WaButton("+ STASIUN", { adding = true })
        }
    }

    if (adding) {
        StationDialog(
            initial = null,
            onSave = { name, freq, url -> vm.addStation(name, freq, url); adding = false },
            onDelete = null,
            onDismiss = { adding = false },
        )
    }
    editing?.let { st ->
        StationDialog(
            initial = st,
            onSave = { name, freq, url -> vm.updateStation(st.id, name, freq, url); editing = null },
            onDelete = { vm.deleteStation(st.id); editing = null },
            onDismiss = { editing = null },
        )
    }
}

/** Rapikan alamat: tambahkan https:// kalau belum ada. Mengembalikan null kalau bukan alamat yang valid. */
private fun normalizeUrl(raw: String): String? {
    val t = raw.trim()
    if (t.isEmpty()) return null
    val full = if (t.startsWith("http://", true) || t.startsWith("https://", true)) t else "https://$t"
    val host = try { Uri.parse(full).host } catch (e: Exception) { null }
    return if (!host.isNullOrBlank() && host.contains('.')) full else null
}

/** Kolom isian besar: huruf besar, teks panjang turun ke baris bawah (tidak terpotong), dan otomatis digulir supaya tidak tertutup keyboard. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BigField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String? = null,
    minLines: Int = 1,
    maxLines: Int = 4,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next,
    onDone: () -> Unit = {},
) {
    val bring = remember { BringIntoViewRequester() }
    val scope = rememberCoroutineScope()
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = false,
        minLines = minLines,
        maxLines = maxLines,
        label = { Text(label, fontSize = 13.sp) },
        placeholder = placeholder?.let { { Text(it, fontSize = 18.sp) } },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction, autoCorrectEnabled = false),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        textStyle = TextStyle(color = Color.White, fontFamily = MONO, fontSize = 18.sp, lineHeight = 24.sp),
        modifier = modifier
            .bringIntoViewRequester(bring)
            .onFocusEvent { st ->
                if (st.isFocused) scope.launch { delay(300); bring.bringIntoView() }
            },
    )
}

@Composable
private fun StationDialog(
    initial: RadioStation?,
    onSave: (name: String, freq: String, url: String) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var freq by remember { mutableStateOf(initial?.freq ?: "") }
    var url by remember { mutableStateOf(initial?.url ?: "") }
    var problem by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    fun trySave() {
        val cleanUrl = normalizeUrl(url)
        val f = freq.trim().replace(',', '.')
        val fNum = f.toFloatOrNull()
        when {
            name.isBlank() -> problem = "Nama stasiun belum diisi."
            cleanUrl == null -> problem = "Alamat URL tidak valid."
            f.isNotEmpty() && (fNum == null || fNum !in 76f..108f) -> problem = "Frekuensi FM harus 76 - 108 MHz (contoh 99.5)."
            else -> onSave(
                name.trim(),
                if (fNum != null) String.format(Locale.US, "%.1f", fNum) else "",
                cleanUrl.orEmpty(),
            )
        }
    }

    // Layar penuh + imePadding: panel ikut naik di atas keyboard, tombol SIMPAN/BATAL ada di bagian atas
    // sehingga tidak pernah tertutup keyboard, dan isi digulir ke kolom yang sedang diisi.
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        val panel = RoundedCornerShape(12.dp)
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xB3000000))
                .systemBarsPadding()
                .imePadding()
                .padding(8.dp),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp)
                    .clip(panel)
                    .background(Skin.t.dialogBg)
                    .border(1.5.dp, Skin.t.dialogEdge, panel)
            ) {
                // ---- bar atas: judul + tombol (selalu terlihat)
                Row(
                    Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        if (initial == null) "TAMBAH STASIUN" else "EDIT STASIUN",
                        color = Color.White, fontFamily = MONO, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                    )
                    if (onDelete != null) {
                        TextButton(onClick = { if (confirmDelete) onDelete() else confirmDelete = true }) {
                            Text(
                                if (confirmDelete) "YAKIN?" else "HAPUS",
                                color = Color(0xFFFF9E94), fontFamily = MONO, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                    TextButton(onClick = onDismiss) {
                        Text("BATAL", color = WA_GREEN_DIM, fontFamily = MONO, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = { trySave() }) {
                        Text("SIMPAN", color = Skin.p.c1, fontFamily = MONO, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Skin.t.dialogLine))

                // ---- isian (digulir kalau ruang sempit)
                Column(
                    Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    BigField(
                        value = name,
                        onChange = { name = it.replace("\n", "").take(40); problem = null },
                        label = "Nama stasiun",
                        minLines = 1, maxLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    BigField(
                        value = freq,
                        onChange = { v -> freq = v.filter { it.isDigit() || it == '.' || it == ',' }.take(6); problem = null },
                        label = "Frekuensi (MHz)",
                        placeholder = "99.5",
                        keyboardType = KeyboardType.Decimal,
                        modifier = Modifier.fillMaxWidth(0.6f),
                    )
                    BigField(
                        value = url,
                        onChange = { url = it.replace("\n", "").replace(" ", ""); problem = null },
                        label = "Alamat URL stream",
                        minLines = 3, maxLines = 8,
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Done,
                        onDone = { trySave() },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "Frekuensi boleh dikosongkan. Alamat harus langsung ke stream audio (MP3/AAC), bukan halaman web. " +
                            "Kalau stasiun mati atau pindah alamat, ganti URL-nya di sini.",
                        color = WA_GREEN_DIM, fontFamily = MONO, fontSize = 11.sp, lineHeight = 15.sp,
                    )
                    problem?.let {
                        Text(it, color = Color(0xFFFF9E94), fontFamily = MONO, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
