# Kipas Gantung Mini: proyek Android (siap build)

Ini proyek Android Gradle lengkap (bukan Capacitor), jadi pembuat APK cloud seperti AndroidForge bisa langsung menjalankan:

    gradle assembleDebug      (APK uji)
    gradle assembleRelease    (APK rilis, sudah bertanda tangan kunci debug sehingga bisa dipasang)
    gradle bundleDebug        (AAB)

Hasil APK ada di `app/build/outputs/apk/debug/app-debug.apk` atau `app/build/outputs/apk/release/app-release.apk`.

## Build sendiri di Android Studio
1. Buka folder `kipas-apk` dengan **File > Open**, tunggu Gradle sync.
2. Menu **Build > Build APK(s)**.

## Isi penting
- `app/src/main/assets/index.html` : aplikasi (offline penuh, font tertanam)
- `app/src/main/java/com/kipasmini/edukasi/MainActivity.java` : WebView + jembatan pengenal suara Android
- `app/src/main/AndroidManifest.xml` : izin mikrofon
- Persyaratan: Gradle 8.7 atau lebih baru, JDK 17, Android SDK platform 34

## Catatan
- Saat tombol Baca Bismillah ditekan pertama kali, Android meminta izin mikrofon. Pilih Izinkan.
- Pengenal suara offline: unduh paket bahasa Indonesia (dan Arab) di pengaturan layanan suara Google HP. Jika belum diunduh, aplikasi memakai pengenalan online.
- Jika pengenal suara tidak tersedia, tombol bantuan orang tua tetap tampil.
- Suara contoh memakai suara sintetis bawaan HP.
