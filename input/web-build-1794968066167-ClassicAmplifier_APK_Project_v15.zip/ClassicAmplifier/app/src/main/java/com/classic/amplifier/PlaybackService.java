package com.classic.amplifier;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Layanan latar depan (media playback): menjaga proses aplikasi tetap berprioritas tinggi
 * dan CPU/Wi-Fi tetap aktif saat musik diputar di belakang layar atau aplikasi lain dibuka,
 * sehingga suara tidak putus-putus, kresek, atau pecah.
 */
public class PlaybackService extends Service {
    static final int NTF_ID = 77;
    static volatile PlaybackService instance;
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    @SuppressWarnings("deprecation")
    public int onStartCommand(Intent i, int flags, int startId) {
        Notification n = null;
        boolean playing = true, radio = false;
        if (i != null) {
            n = i.getParcelableExtra("n");
            playing = i.getBooleanExtra("playing", true);
            radio = i.getBooleanExtra("radio", false);
        }
        update(n, playing, radio);
        return START_NOT_STICKY;
    }

    void update(Notification n, boolean playing, boolean radio) {
        if (n != null) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(NTF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
                } else {
                    startForeground(NTF_ID, n);
                }
            } catch (Exception ignored) {
            }
        }
        setLocks(playing, radio);
    }

    @SuppressWarnings("deprecation")
    private void setLocks(boolean playing, boolean radio) {
        try {
            if (playing) {
                if (wake == null) {
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ClassicAmplifier:play");
                    wake.setReferenceCounted(false);
                }
                if (!wake.isHeld()) wake.acquire(6 * 60 * 60 * 1000L);
                if (radio) {
                    if (wifi == null) {
                        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                        wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "ClassicAmplifier:radio");
                        wifi.setReferenceCounted(false);
                    }
                    if (!wifi.isHeld()) wifi.acquire();
                } else if (wifi != null && wifi.isHeld()) {
                    wifi.release();
                }
            } else {
                releaseLocks();
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseLocks() {
        try {
            if (wake != null && wake.isHeld()) wake.release();
            if (wifi != null && wifi.isHeld()) wifi.release();
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDestroy() {
        releaseLocks();
        instance = null;
        super.onDestroy();
    }
}
