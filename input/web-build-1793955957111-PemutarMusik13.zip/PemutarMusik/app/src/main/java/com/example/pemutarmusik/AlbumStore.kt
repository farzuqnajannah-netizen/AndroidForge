package com.example.pemutarmusik

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Album = playlist buatan pengguna dengan urutan lagu sendiri. */
data class Album(val id: Long, val name: String, val songIds: List<Long>)

/** Penyimpanan album di SharedPreferences (format JSON). */
object AlbumStore {
    private const val PREFS = "albums"
    private const val KEY = "data"

    fun load(context: Context): List<Album> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val ids = o.getJSONArray("ids")
                Album(o.getLong("id"), o.getString("name"), List(ids.length()) { ids.getLong(it) })
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(context: Context, albums: List<Album>) {
        val arr = JSONArray()
        for (a in albums) {
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("name", a.name)
                    .put("ids", JSONArray(a.songIds))
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
