package com.example.pemutarmusik.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

/** Spectrum 19 bar ala Winamp. Dipanggil dari thread UI (~30x per detik). */
class SpectrumAnalyzer(private val processor: EqAudioProcessor) {

    companion object {
        const val BARS = 19
        private const val LOW_HZ = 45.0
        private const val HIGH_HZ = 14000.0
    }

    private val n = EqAudioProcessor.SPECTRUM_SIZE
    private val buf = FloatArray(n)
    private val window = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
    private val ratio = (HIGH_HZ / LOW_HZ).pow(1.0 / (BARS - 1))
    private val freqs = DoubleArray(BARS) { LOW_HZ * ratio.pow(it.toDouble()) }

    /** Hasil 0..1 per bar. */
    fun compute(): FloatArray {
        processor.snapshot(buf)
        for (i in 0 until n) buf[i] *= window[i]
        val sr = processor.sampleRateHz
        val out = FloatArray(BARS)
        for (b in 0 until BARS) {
            var best = 0.0
            // 3 titik per bar supaya energi di antara pusat bar tidak terlewat
            for (k in -1..1) {
                val f = freqs[b] * ratio.pow(k * 0.3)
                if (f >= sr * 0.45) continue
                val coeff = 2.0 * cos(2.0 * PI * f / sr)
                var s1 = 0.0
                var s2 = 0.0
                for (i in 0 until n) {
                    val s = buf[i] + coeff * s1 - s2
                    s2 = s1
                    s1 = s
                }
                val power = s1 * s1 + s2 * s2 - coeff * s1 * s2
                if (power > best) best = power
            }
            val amp = 4.0 * sqrt(max(best, 0.0)) / n
            val db = 20.0 * log10(amp + 1e-9) + b * 0.8   // sedikit tilt supaya treble terlihat
            out[b] = ((db + 72.0) / 52.0).toFloat().coerceIn(0f, 1f)
        }
        return out
    }
}
