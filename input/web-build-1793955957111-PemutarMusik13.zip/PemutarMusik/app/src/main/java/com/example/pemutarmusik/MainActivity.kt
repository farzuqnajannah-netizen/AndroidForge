package com.example.pemutarmusik

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.view.WindowManager
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pemutarmusik.audio.AudioEngine

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(applicationContext)
        Skin.init(applicationContext)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { PlayerApp() }
        }
        enterFullScreen()
    }

    /** Layar penuh: status bar (notifikasi) dan tombol navigasi disembunyikan; geser dari tepi untuk menampilkannya sebentar. */
    private fun enterFullScreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterFullScreen()
    }

    override fun onResume() {
        super.onResume()
        // Kembali ke aplikasi = mini player melayang ditutup (seperti restore di Winamp)
        stopService(Intent(this, FloatingPlayerService::class.java))
    }
}

/** Minimize ala Winamp: app turun ke belakang, mini player melayang tampil di depan. */
private fun minimizeToFloating(context: Context) {
    if (!Settings.canDrawOverlays(context)) {
        Toast.makeText(
            context,
            "Aktifkan \"Tampil di atas aplikasi lain\" untuk MP3, lalu tekan minimize lagi.",
            Toast.LENGTH_LONG,
        ).show()
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
        )
        return
    }
    context.startService(Intent(context, FloatingPlayerService::class.java))
    (context as? Activity)?.moveTaskToBack(true)
}

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED

private fun requestedPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 33 -> arrayOf(audioPermission(), Manifest.permission.POST_NOTIFICATIONS)
    // Android 9 ke bawah: butuh izin tulis untuk menghapus file lagu
    Build.VERSION.SDK_INT <= 28 -> arrayOf(audioPermission(), Manifest.permission.WRITE_EXTERNAL_STORAGE)
    else -> arrayOf(audioPermission())
}

@Composable
fun PlayerApp(vm: PlayerViewModel = viewModel()) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission(context)
    }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(requestedPermissions())
    }
    LaunchedEffect(granted) {
        if (granted) vm.loadSongs()
    }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        vm.onDeleteResult(res.resultCode == Activity.RESULT_OK)
    }
    val onDeleteSong: (Song) -> Unit = { song ->
        when (val outcome = vm.requestDelete(song)) {
            is DeleteOutcome.NeedsUser -> deleteLauncher.launch(IntentSenderRequest.Builder(outcome.sender).build())
            DeleteOutcome.Done -> Toast.makeText(context, "Lagu dihapus", Toast.LENGTH_SHORT).show()
            DeleteOutcome.Failed -> Toast.makeText(context, "Gagal menghapus lagu", Toast.LENGTH_SHORT).show()
        }
    }

    // Landscape: sisi kiri sedikit lebih lebar (6 : 5) dari playlist.
    // Kiri: player, equalizer, DSP bertumpuk dengan tinggi sama (1/3 masing-masing), permanen tanpa minimize.
    // Kanan: playlist (permanen). Minimize "–" dan tutup "×" ada di pojok kanan atas.
    Row(
        Modifier
            .fillMaxSize()
            .background(WA_DESK)
            .displayCutoutPadding()
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Column(
            Modifier.weight(1.2f).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            MainWindow(vm, Modifier.weight(1f))
            EqWindow(Modifier.weight(1f))
            DspWindow(Modifier.weight(1f))
        }
        PlaylistWindow(
            vm = vm,
            granted = granted,
            onRequestPermission = { launcher.launch(requestedPermissions()) },
            onDeleteSong = onDeleteSong,
            onMinimize = { minimizeToFloating(context) },
            onClose = { closeApp(context, vm) },
            modifier = Modifier.weight(1f).fillMaxHeight().imePadding(),
        )
    }
}

/** Tutup: hentikan lagu, tutup mini player dan service pemutar, lalu keluar dari aplikasi. */
private fun closeApp(context: Context, vm: PlayerViewModel) {
    vm.stop()
    context.stopService(Intent(context, FloatingPlayerService::class.java))
    context.stopService(Intent(context, PlaybackService::class.java))
    (context as? Activity)?.finishAndRemoveTask()
}
