package com.example.ytsimpel

import android.app.Activity
import android.app.Dialog
import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.LayerDrawable
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.util.Rational
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var full: FrameLayout
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private val base = "https://appassets.androidplatform.net"

    inner class MicBridge {
        @JavascriptInterface
        fun start() = runOnUiThread {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Ucapkan kata pencarian")
            }
            try { startActivityForResult(i, 1) }
            catch (e: Exception) { Toast.makeText(this@MainActivity, "Pengenal suara tidak tersedia", Toast.LENGTH_SHORT).show() }
        }
    }

    inner class ShareBridge {
        @JavascriptInterface
        fun share(title: String, url: String) = runOnUiThread { showShare(title, url) }
    }

    private var dsp: DynamicsProcessing? = null
    private var legacyEq: Equalizer? = null
    private val eqFreqs = floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)

    private fun releaseEq() {
        try { dsp?.release() } catch (e: Throwable) {}
        try { legacyEq?.release() } catch (e: Throwable) {}
        dsp = null; legacyEq = null
    }

    private fun applyEq(enabled: Boolean, csv: String): String {
        val g = csv.split(",").mapNotNull { it.trim().toFloatOrNull() }
        if (g.size != 10) return "error"
        if (!enabled) { releaseEq(); return "off" }
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val d = dsp ?: run {
                    val cfg = DynamicsProcessing.Config.Builder(
                        DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                        2, true, 10, false, 0, false, 0, false
                    ).build()
                    DynamicsProcessing(0, 0, cfg).also { dsp = it }
                }
                for (ch in 0 until 2) for (i in 0 until 10) {
                    d.setPreEqBandByChannelIndex(ch, i, DynamicsProcessing.EqBand(true, eqFreqs[i], g[i]))
                }
                d.setEnabled(true)
                return "dsp"
            } catch (e: Throwable) {
                try { dsp?.release() } catch (x: Throwable) {}
                dsp = null
            }
        }
        try {
            val eqz = legacyEq ?: Equalizer(0, 0).also { legacyEq = it }
            val r = eqz.bandLevelRange
            for (b in 0 until eqz.numberOfBands.toInt()) {
                val cf = eqz.getCenterFreq(b.toShort()) / 1000f
                var best = 0
                var bd = Double.MAX_VALUE
                for (i in 0 until 10) {
                    val dd = Math.abs(Math.log((cf / eqFreqs[i]).toDouble()))
                    if (dd < bd) { bd = dd; best = i }
                }
                val mb = (g[best] * 100).toInt().coerceIn(r[0].toInt(), r[1].toInt())
                eqz.setBandLevel(b.toShort(), mb.toShort())
            }
            eqz.setEnabled(true)
            return "eq"
        } catch (e: Throwable) {
            releaseEq()
            return "error"
        }
    }

    inner class EqBridge {
        @JavascriptInterface
        fun apply(enabled: Boolean, csv: String): String = applyEq(enabled, csv)
    }

    private var isDark = false

    private fun applyBars() {
        val bg = if (isDark) Color.parseColor("#0F0F0F") else Color.WHITE
        window.statusBarColor = bg
        window.navigationBarColor = bg
        findViewById<View>(R.id.root).setBackgroundColor(bg)
        window.decorView.systemUiVisibility = if (isDark) 0 else (0x2000 or 0x10)
    }

    inner class ThemeBridge {
        @JavascriptInterface
        fun set(dark: Boolean) = runOnUiThread {
            isDark = dark
            if (customView == null) applyBars()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showShare(title: String, url: String) {
        val tc = if (isDark) Color.WHITE else Color.BLACK
        val probe = Intent(Intent.ACTION_SEND).apply { type = "text/plain" }
        val apps = packageManager.queryIntentActivities(probe, 0)
            .filter { it.activityInfo.packageName != packageName }
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val bg = GradientDrawable().apply {
            setColor(if (isDark) Color.parseColor("#212121") else Color.WHITE)
            val r = dp(16).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(16), dp(16), dp(8), dp(20))
        }
        root.addView(TextView(this).apply {
            text = "Bagikan"; textSize = 18f
            setTypeface(null, Typeface.BOLD); setTextColor(tc)
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(16), 0, 0)
        }

        fun item(icon: Drawable, label: String, action: () -> Unit) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT)
                setOnClickListener { d.dismiss(); action() }
            }
            box.addView(ImageView(this).apply {
                setImageDrawable(icon)
                layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
            })
            box.addView(TextView(this).apply {
                text = label; textSize = 11f; maxLines = 2; gravity = Gravity.CENTER
                setTextColor(tc); setPadding(dp(2), dp(6), dp(2), 0)
            })
            row.addView(box)
        }

        val circle = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(if (isDark) "#3A3A3A" else "#EEEEEE"))
        }
        val copyIcon = LayerDrawable(arrayOf(circle, InsetDrawable(getDrawable(R.drawable.ic_copy)!!.mutate().also { it.setTint(tc) }, dp(14))))
        item(copyIcon, "Salin link") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("link", url))
            Toast.makeText(this, "Link disalin", Toast.LENGTH_SHORT).show()
        }
        for (ri in apps) {
            item(ri.loadIcon(packageManager), ri.loadLabel(packageManager).toString()) {
                try {
                    startActivity(Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, url)
                        putExtra(Intent.EXTRA_SUBJECT, title)
                        setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                    })
                } catch (e: Exception) {
                    Toast.makeText(this, "Tidak bisa membuka aplikasi", Toast.LENGTH_SHORT).show()
                }
            }
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        })
        d.setContentView(root)
        d.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
        d.show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.web)
        web.overScrollMode = View.OVER_SCROLL_NEVER
        full = findViewById(R.id.full)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
        }
        web.addJavascriptInterface(MicBridge(), "AndroidMic")
        web.addJavascriptInterface(ShareBridge(), "AndroidShare")
        web.addJavascriptInterface(ThemeBridge(), "AndroidTheme")
        web.addJavascriptInterface(EqBridge(), "AndroidEq")
        web.addJavascriptInterface(PipBridge(), "AndroidPip")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean =
                r.url.host != "appassets.androidplatform.net"
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                customView = view; customCb = cb
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                full.addView(view); full.visibility = View.VISIBLE
                window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
            }
            override fun onHideCustomView() {
                full.removeAllViews(); full.visibility = View.GONE
                customCb?.onCustomViewHidden(); customView = null
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                applyBars()
            }
        }
        if (savedInstanceState == null) web.loadUrl("$base/assets/index.html")
        else web.restoreState(savedInstanceState)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK) {
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
                web.evaluateJavascript("window.onVoice(" + JSONObject.quote(it) + ")", null)
            }
        }
    }

    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); web.saveState(out) }

    private var bg = false
    private var canPip = false

    private var vidRect: FloatArray? = null
    private var vidOn = false
    private var gTrack = false
    private var gFired = false
    private var gX = 0f
    private var gY = 0f

    inner class PipBridge {
        @JavascriptInterface
        fun set(on: Boolean) { canPip = on }

        @JavascriptInterface
        fun rect(l: Double, t: Double, r: Double, b: Double, on: Boolean) {
            vidRect = floatArrayOf(l.toFloat(), t.toFloat(), r.toFloat(), b.toFloat())
            vidOn = on
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        try {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gTrack = false; gFired = false
                    val rc = vidRect
                    if (vidOn && rc != null && customView == null && !inPip()) {
                        val loc = IntArray(2)
                        web.getLocationOnScreen(loc)
                        val d = resources.displayMetrics.density
                        val l = loc[0] + rc[0] * d
                        val tp = loc[1] + rc[1] * d
                        val r = loc[0] + rc[2] * d
                        val b = loc[1] + rc[3] * d
                        if (ev.rawX >= l && ev.rawX <= r && ev.rawY >= tp && ev.rawY <= b) {
                            gTrack = true; gX = ev.rawX; gY = ev.rawY
                        }
                    }
                }
                MotionEvent.ACTION_MOVE -> if (gTrack && !gFired) {
                    val dy = ev.rawY - gY
                    val dx = Math.abs(ev.rawX - gX)
                    if (dy > dp(72) && dx < dp(70)) {
                        gFired = true
                        web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        web.evaluateJavascript("window.toMini&&window.toMini()", null)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> gTrack = false
            }
        } catch (e: Throwable) {}
        return super.dispatchTouchEvent(ev)
    }

    private fun inPip(): Boolean = Build.VERSION.SDK_INT >= 26 && isInPictureInPictureMode

    private fun pauseNow() {
        web.evaluateJavascript("window.appPause&&window.appPause()", null)
        web.onPause()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (canPip && customView == null && Build.VERSION.SDK_INT >= 26) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            } catch (e: Throwable) {}
        }
    }

    override fun onPictureInPictureModeChanged(isInPip: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPip, newConfig)
        web.evaluateJavascript("window.pipMode&&window.pipMode(" + isInPip + ")", null)
        if (!isInPip) web.postDelayed({ if (bg) pauseNow() }, 400)
    }

    override fun onPause() {
        bg = true
        web.postDelayed({ if (bg && !inPip()) pauseNow() }, 350)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        bg = false
        web.onResume()
    }

    override fun onDestroy() { releaseEq(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (customView != null) { web.webChromeClient?.onHideCustomView(); return }
        web.evaluateJavascript("(window.appBack&&window.appBack())?'1':'0'") {
            if (it == null || !it.contains("1")) finish()
        }
    }
}
